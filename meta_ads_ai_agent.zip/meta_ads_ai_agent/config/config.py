"""
Configuration module for Meta Ads AI Agent
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / 'app'
DATA_DIR = BASE_DIR / 'data'
CONFIG_DIR = BASE_DIR / 'config'

# Input/Output directories
INPUT_DIR = DATA_DIR / 'input'
OUTPUT_DIR = DATA_DIR / 'output'
TEMPLATE_DIR = CONFIG_DIR / 'templates'

# Ensure directories exist
for directory in [INPUT_DIR, OUTPUT_DIR, TEMPLATE_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# API Configuration
class APIConfig:
    # Meta API
    META_APP_ID = os.getenv('META_APP_ID', '')
    META_APP_SECRET = os.getenv('META_APP_SECRET', '')
    META_ACCESS_TOKEN = os.getenv('META_ACCESS_TOKEN', '')
    META_ACCOUNT_ID = os.getenv('META_ACCOUNT_ID', '')
    META_API_VERSION = os.getenv('META_API_VERSION', 'v23.0')
    
    # OpenAI API
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4')
    
    # Airtable
    AIRTABLE_API_KEY = os.getenv('AIRTABLE_API_KEY', '')
    AIRTABLE_BASE_ID = os.getenv('AIRTABLE_BASE_ID', '')
    
    # Google Sheets
    GOOGLE_CREDENTIALS_FILE = os.getenv('GOOGLE_CREDENTIALS_FILE', '')
    GOOGLE_SHEET_ID = os.getenv('GOOGLE_SHEET_ID', '')

# Application Configuration
class AppConfig:
    DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key')
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', '5000'))
    
    # Database
    DATABASE_URI = os.getenv('DATABASE_URI', f'sqlite:///{BASE_DIR}/data/meta_ads_ai.db')
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', f'{BASE_DIR}/logs/app.log')

# Content Generation Configuration
class ContentConfig:
    # Character limits
    PRIMARY_TEXT_LIMIT = 125
    HEADLINE_LIMIT = 40
    DESCRIPTION_LIMIT = 30
    
    # Generation settings
    DEFAULT_VARIATIONS = 3
    MAX_VARIATIONS = 10
    
    # Templates
    HEADLINE_TEMPLATES_FILE = TEMPLATE_DIR / 'headline_templates.json'
    PRIMARY_TEXT_TEMPLATES_FILE = TEMPLATE_DIR / 'primary_text_templates.json'

# Export configurations
config = {
    'api': APIConfig,
    'app': AppConfig,
    'content': ContentConfig,
    'base_dir': BASE_DIR,
    'app_dir': APP_DIR,
    'data_dir': DATA_DIR,
    'config_dir': CONFIG_DIR,
    'input_dir': INPUT_DIR,
    'output_dir': OUTPUT_DIR,
    'template_dir': TEMPLATE_DIR
}

