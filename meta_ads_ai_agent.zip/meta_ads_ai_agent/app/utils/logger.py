"""
Logging utilities
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sys

from config.config import config

# Create logs directory if it doesn't exist
logs_dir = Path(config['base_dir']) / 'logs'
logs_dir.mkdir(exist_ok=True)

# Configure logging
log_level = getattr(logging, config['app'].LOG_LEVEL.upper(), logging.INFO)
log_file = config['app'].LOG_FILE

# Create formatter
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Create console handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
console_handler.setLevel(log_level)

# Create file handler
file_handler = RotatingFileHandler(
    log_file,
    maxBytes=10485760,  # 10MB
    backupCount=10
)
file_handler.setFormatter(formatter)
file_handler.setLevel(log_level)


def get_logger(name):
    """Get a logger with the specified name"""
    logger = logging.getLogger(name)
    logger.setLevel(log_level)
    
    # Add handlers if they haven't been added yet
    if not logger.handlers:
        logger.addHandler(console_handler)
        logger.addHandler(file_handler)
    
    return logger

