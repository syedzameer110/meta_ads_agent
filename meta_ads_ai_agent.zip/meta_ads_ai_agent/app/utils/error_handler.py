"""
Error handling utilities
"""

import traceback
from flask import jsonify
from typing import Dict, Any

from app.utils.logger import get_logger

logger = get_logger(__name__)

class AppError(Exception):
    """Custom application error"""
    
    def __init__(self, message: str, status_code: int = 400, details: Dict[str, Any] = None):
        """Initialize the error
        
        Args:
            message: Error message
            status_code: HTTP status code
            details: Additional error details
        """
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary
        
        Returns:
            Dictionary representation of the error
        """
        error_dict = {
            "error": self.message,
            "status_code": self.status_code
        }
        
        if self.details:
            error_dict["details"] = self.details
        
        return error_dict

def api_error_handler(error: Exception) -> tuple:
    """Handle API errors
    
    Args:
        error: Exception to handle
        
    Returns:
        Tuple of (response, status_code)
    """
    if isinstance(error, AppError):
        logger.error(f"AppError: {error.message}")
        return jsonify(error.to_dict()), error.status_code
    
    # Handle other exceptions
    logger.error(f"Unhandled exception: {str(error)}")
    logger.error(traceback.format_exc())
    
    return jsonify({
        "error": "An unexpected error occurred",
        "details": str(error),
        "status_code": 500
    }), 500

