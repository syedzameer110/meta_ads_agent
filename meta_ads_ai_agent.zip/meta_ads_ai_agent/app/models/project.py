"""
Project Models
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid


@dataclass
class ProjectTarget:
    """Target audience information"""
    age_min: Optional[int] = None
    age_max: Optional[int] = None
    genders: List[str] = field(default_factory=list)
    locations: List[Dict[str, Any]] = field(default_factory=list)
    interests: List[str] = field(default_factory=list)
    behaviors: List[str] = field(default_factory=list)
    custom_audiences: List[str] = field(default_factory=list)
    excluded_audiences: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "age_min": self.age_min,
            "age_max": self.age_max,
            "genders": self.genders,
            "locations": self.locations,
            "interests": self.interests,
            "behaviors": self.behaviors,
            "custom_audiences": self.custom_audiences,
            "excluded_audiences": self.excluded_audiences
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProjectTarget':
        """Create ProjectTarget from dictionary"""
        return cls(
            age_min=data.get("age_min"),
            age_max=data.get("age_max"),
            genders=data.get("genders", []),
            locations=data.get("locations", []),
            interests=data.get("interests", []),
            behaviors=data.get("behaviors", []),
            custom_audiences=data.get("custom_audiences", []),
            excluded_audiences=data.get("excluded_audiences", [])
        )


@dataclass
class ProjectProduct:
    """Product information"""
    name: str
    description: str
    features: List[str] = field(default_factory=list)
    benefits: List[str] = field(default_factory=list)
    price: Optional[float] = None
    currency: str = "USD"
    image_urls: List[str] = field(default_factory=list)
    landing_page_url: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "name": self.name,
            "description": self.description,
            "features": self.features,
            "benefits": self.benefits,
            "price": self.price,
            "currency": self.currency,
            "image_urls": self.image_urls,
            "landing_page_url": self.landing_page_url
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProjectProduct':
        """Create ProjectProduct from dictionary"""
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            features=data.get("features", []),
            benefits=data.get("benefits", []),
            price=data.get("price"),
            currency=data.get("currency", "USD"),
            image_urls=data.get("image_urls", []),
            landing_page_url=data.get("landing_page_url")
        )


@dataclass
class ProjectCampaign:
    """Campaign information"""
    name: str
    objective: str
    budget_type: str = "daily"  # daily or lifetime
    budget_amount: float = 0.0
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    bid_strategy: str = "lowest_cost"
    optimization_goal: str = "LINK_CLICKS"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {
            "name": self.name,
            "objective": self.objective,
            "budget_type": self.budget_type,
            "budget_amount": self.budget_amount,
            "bid_strategy": self.bid_strategy,
            "optimization_goal": self.optimization_goal
        }
        
        if self.start_date:
            result["start_date"] = self.start_date.isoformat()
            
        if self.end_date:
            result["end_date"] = self.end_date.isoformat()
            
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProjectCampaign':
        """Create ProjectCampaign from dictionary"""
        start_date = None
        if "start_date" in data:
            try:
                start_date = datetime.fromisoformat(data["start_date"])
            except (ValueError, TypeError):
                pass
        
        end_date = None
        if "end_date" in data:
            try:
                end_date = datetime.fromisoformat(data["end_date"])
            except (ValueError, TypeError):
                pass
        
        return cls(
            name=data.get("name", ""),
            objective=data.get("objective", ""),
            budget_type=data.get("budget_type", "daily"),
            budget_amount=data.get("budget_amount", 0.0),
            start_date=start_date,
            end_date=end_date,
            bid_strategy=data.get("bid_strategy", "lowest_cost"),
            optimization_goal=data.get("optimization_goal", "LINK_CLICKS")
        )


@dataclass
class Project:
    """Main project model"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    product: ProjectProduct = field(default_factory=ProjectProduct)
    target: ProjectTarget = field(default_factory=ProjectTarget)
    campaign: ProjectCampaign = field(default_factory=ProjectCampaign)
    tone_of_voice: List[str] = field(default_factory=list)
    messaging_strategy: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "product": self.product.to_dict(),
            "target": self.target.to_dict(),
            "campaign": self.campaign.to_dict(),
            "tone_of_voice": self.tone_of_voice,
            "messaging_strategy": self.messaging_strategy,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Project':
        """Create Project from dictionary"""
        created_at = datetime.now()
        if "created_at" in data:
            try:
                created_at = datetime.fromisoformat(data["created_at"])
            except (ValueError, TypeError):
                pass
        
        updated_at = datetime.now()
        if "updated_at" in data:
            try:
                updated_at = datetime.fromisoformat(data["updated_at"])
            except (ValueError, TypeError):
                pass
        
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            product=ProjectProduct.from_dict(data.get("product", {})),
            target=ProjectTarget.from_dict(data.get("target", {})),
            campaign=ProjectCampaign.from_dict(data.get("campaign", {})),
            tone_of_voice=data.get("tone_of_voice", []),
            messaging_strategy=data.get("messaging_strategy", ""),
            created_at=created_at,
            updated_at=updated_at,
            metadata=data.get("metadata", {})
        )

