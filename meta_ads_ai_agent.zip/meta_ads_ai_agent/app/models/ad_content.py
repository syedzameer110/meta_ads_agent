"""
Ad Content Models
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class AdHeadline:
    """Model for ad headline content"""
    text: str
    character_count: int = field(init=False)
    
    def __post_init__(self):
        self.character_count = len(self.text)
    
    def is_valid(self, max_length: int = 40) -> bool:
        """Check if headline is within character limit"""
        return self.character_count <= max_length


@dataclass
class AdPrimaryText:
    """Model for ad primary text content"""
    text: str
    character_count: int = field(init=False)
    
    def __post_init__(self):
        self.character_count = len(self.text)
    
    def is_valid(self, max_length: int = 125) -> bool:
        """Check if primary text is within character limit"""
        return self.character_count <= max_length


@dataclass
class AdDescription:
    """Model for ad description content"""
    text: str
    character_count: int = field(init=False)
    
    def __post_init__(self):
        self.character_count = len(self.text)
    
    def is_valid(self, max_length: int = 30) -> bool:
        """Check if description is within character limit"""
        return self.character_count <= max_length


@dataclass
class AdContent:
    """Complete ad content model"""
    headline: AdHeadline
    primary_text: AdPrimaryText
    description: Optional[AdDescription] = None
    call_to_action: Optional[str] = None
    url: Optional[str] = None
    image_url: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API use"""
        result = {
            "headline": self.headline.text,
            "primary_text": self.primary_text.text,
            "created_at": self.created_at.isoformat(),
        }
        
        if self.description:
            result["description"] = self.description.text
            
        if self.call_to_action:
            result["call_to_action"] = self.call_to_action
            
        if self.url:
            result["url"] = self.url
            
        if self.image_url:
            result["image_url"] = self.image_url
            
        if self.metadata:
            result["metadata"] = self.metadata
            
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AdContent':
        """Create AdContent from dictionary"""
        headline = AdHeadline(text=data.get("headline", ""))
        primary_text = AdPrimaryText(text=data.get("primary_text", ""))
        
        description = None
        if "description" in data:
            description = AdDescription(text=data["description"])
        
        created_at = datetime.now()
        if "created_at" in data:
            try:
                created_at = datetime.fromisoformat(data["created_at"])
            except (ValueError, TypeError):
                pass
        
        return cls(
            headline=headline,
            primary_text=primary_text,
            description=description,
            call_to_action=data.get("call_to_action"),
            url=data.get("url"),
            image_url=data.get("image_url"),
            metadata=data.get("metadata", {}),
            created_at=created_at
        )


@dataclass
class AdVariations:
    """Collection of ad content variations"""
    headlines: List[AdHeadline] = field(default_factory=list)
    primary_texts: List[AdPrimaryText] = field(default_factory=list)
    descriptions: List[AdDescription] = field(default_factory=list)
    
    def generate_combinations(self) -> List[AdContent]:
        """Generate all possible combinations of headlines, primary texts, and descriptions"""
        combinations = []
        
        # Ensure we have at least one headline and primary text
        if not self.headlines or not self.primary_texts:
            return combinations
        
        # Generate combinations
        for headline in self.headlines:
            for primary_text in self.primary_texts:
                if self.descriptions:
                    for description in self.descriptions:
                        combinations.append(AdContent(
                            headline=headline,
                            primary_text=primary_text,
                            description=description
                        ))
                else:
                    combinations.append(AdContent(
                        headline=headline,
                        primary_text=primary_text
                    ))
        
        return combinations

