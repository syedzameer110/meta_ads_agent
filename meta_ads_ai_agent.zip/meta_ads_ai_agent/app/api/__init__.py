"""
API package for Meta Ads AI Agent
"""

from flask import Blueprint

api_bp = Blueprint('api', __name__, url_prefix='/api')

# Import routes after creating the blueprint to avoid circular imports
from app.api import ad_content, meta_ads, integrations

# Register blueprints
from app.api.ad_content import ad_content_bp
from app.api.meta_ads import meta_ads_bp
from app.api.integrations import integrations_bp

api_bp.register_blueprint(ad_content_bp)
api_bp.register_blueprint(meta_ads_bp)
api_bp.register_blueprint(integrations_bp)
