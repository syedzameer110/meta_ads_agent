"""
API endpoints for integrations with external tools
"""

import os
import json
from flask import Blueprint, request, jsonify

from app.services.integration_service import IntegrationService
from app.utils.logger import get_logger
from app.utils.error_handler import api_error_handler, AppError
from config.config import config

logger = get_logger(__name__)

# Create blueprint
integrations_bp = Blueprint('integrations', __name__, url_prefix='/integrations')

# Initialize service
def get_integration_service():
    """Get Integration service instance"""
    return IntegrationService()

# Error handler
@integrations_bp.errorhandler(AppError)
def handle_app_error(error):
    """Handle application errors"""
    return api_error_handler(error)

# Google Sheets endpoints
@integrations_bp.route('/google-sheets/read', methods=['POST'])
def read_google_sheets():
    """Read data from Google Sheets"""
    try:
        data = request.get_json()
        
        # Required parameters
        credentials = data.get('credentials')
        spreadsheet_key = data.get('spreadsheet_key')
        
        # Optional parameters
        worksheet_name = data.get('worksheet_name')
        range_name = data.get('range_name')
        
        # Validate required parameters
        if not credentials or not spreadsheet_key:
            raise AppError("Missing required parameters")
        
        # Read from Google Sheets
        integration_service = get_integration_service()
        result = integration_service.read_google_sheets(
            credentials=credentials,
            spreadsheet_key=spreadsheet_key,
            worksheet_name=worksheet_name,
            range_name=range_name
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error reading from Google Sheets: {str(e)}")
        return jsonify({"error": str(e)}), 500

@integrations_bp.route('/google-sheets/write', methods=['POST'])
def write_google_sheets():
    """Write data to Google Sheets"""
    try:
        data = request.get_json()
        
        # Required parameters
        credentials = data.get('credentials')
        spreadsheet_key = data.get('spreadsheet_key')
        data_to_write = data.get('data')
        
        # Optional parameters
        worksheet_name = data.get('worksheet_name')
        range_name = data.get('range_name')
        
        # Validate required parameters
        if not credentials or not spreadsheet_key or not data_to_write:
            raise AppError("Missing required parameters")
        
        # Write to Google Sheets
        integration_service = get_integration_service()
        result = integration_service.write_google_sheets(
            credentials=credentials,
            spreadsheet_key=spreadsheet_key,
            data=data_to_write,
            worksheet_name=worksheet_name,
            range_name=range_name
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error writing to Google Sheets: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Airtable endpoints
@integrations_bp.route('/airtable/read', methods=['POST'])
def read_airtable():
    """Read data from Airtable"""
    try:
        data = request.get_json()
        
        # Required parameters
        api_key = data.get('api_key')
        base_id = data.get('base_id')
        table_name = data.get('table_name')
        
        # Optional parameters
        formula = data.get('formula')
        max_records = data.get('max_records')
        
        # Validate required parameters
        if not api_key or not base_id or not table_name:
            raise AppError("Missing required parameters")
        
        # Read from Airtable
        integration_service = get_integration_service()
        result = integration_service.read_airtable(
            api_key=api_key,
            base_id=base_id,
            table_name=table_name,
            formula=formula,
            max_records=max_records
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error reading from Airtable: {str(e)}")
        return jsonify({"error": str(e)}), 500

@integrations_bp.route('/airtable/write', methods=['POST'])
def write_airtable():
    """Write data to Airtable"""
    try:
        data = request.get_json()
        
        # Required parameters
        api_key = data.get('api_key')
        base_id = data.get('base_id')
        table_name = data.get('table_name')
        data_to_write = data.get('data')
        
        # Validate required parameters
        if not api_key or not base_id or not table_name or not data_to_write:
            raise AppError("Missing required parameters")
        
        # Write to Airtable
        integration_service = get_integration_service()
        result = integration_service.write_airtable(
            api_key=api_key,
            base_id=base_id,
            table_name=table_name,
            data=data_to_write
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error writing to Airtable: {str(e)}")
        return jsonify({"error": str(e)}), 500

# n8n endpoints
@integrations_bp.route('/n8n/webhook', methods=['POST'])
def trigger_n8n_webhook():
    """Trigger an n8n webhook"""
    try:
        data = request.get_json()
        
        # Required parameters
        webhook_url = data.get('webhook_url')
        webhook_data = data.get('data')
        
        # Validate required parameters
        if not webhook_url or not webhook_data:
            raise AppError("Missing required parameters")
        
        # Trigger n8n webhook
        integration_service = get_integration_service()
        result = integration_service.trigger_n8n_webhook(
            webhook_url=webhook_url,
            data=webhook_data
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error triggering n8n webhook: {str(e)}")
        return jsonify({"error": str(e)}), 500

# CSV import/export endpoints
@integrations_bp.route('/csv/import', methods=['POST'])
def import_csv():
    """Import data from CSV file"""
    try:
        # Check if the post request has the file part
        if 'file' not in request.files:
            raise AppError("No file part")
        
        file = request.files['file']
        
        # If user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            raise AppError("No selected file")
        
        # Check if the file is a CSV
        if not file.filename.endswith('.csv'):
            raise AppError("File must be a CSV")
        
        # Import CSV
        integration_service = get_integration_service()
        result = integration_service.import_csv(file)
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error importing CSV: {str(e)}")
        return jsonify({"error": str(e)}), 500

@integrations_bp.route('/csv/export', methods=['POST'])
def export_csv():
    """Export data to CSV file"""
    try:
        data = request.get_json()
        
        # Required parameters
        export_data = data.get('data')
        filename = data.get('filename', 'export.csv')
        
        # Validate required parameters
        if not export_data:
            raise AppError("Missing data parameter")
        
        # Export CSV
        integration_service = get_integration_service()
        result = integration_service.export_csv(export_data, filename)
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error exporting CSV: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Bulk operations endpoints
@integrations_bp.route('/bulk/process', methods=['POST'])
def process_bulk_data():
    """Process bulk data for ad creation"""
    try:
        data = request.get_json()
        
        # Required parameters
        source_type = data.get('source_type')  # csv, google_sheets, airtable
        source_data = data.get('source_data')
        operation = data.get('operation')  # generate_content, create_ads
        
        # Optional parameters
        options = data.get('options', {})
        
        # Validate required parameters
        if not source_type or not source_data or not operation:
            raise AppError("Missing required parameters")
        
        # Process bulk data
        integration_service = get_integration_service()
        result = integration_service.process_bulk_data(
            source_type=source_type,
            source_data=source_data,
            operation=operation,
            options=options
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error processing bulk data: {str(e)}")
        return jsonify({"error": str(e)}), 500

