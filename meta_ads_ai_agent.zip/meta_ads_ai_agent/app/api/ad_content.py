"""
API endpoints for ad content generation
"""

import os
import json
from flask import Blueprint, request, jsonify

from app.services.openai_service import OpenAIService
from app.utils.logger import get_logger
from app.utils.error_handler import api_error_handler, AppError
from config.config import config

logger = get_logger(__name__)

# Create blueprint
ad_content_bp = Blueprint('ad_content', __name__, url_prefix='/ad-content')

# Initialize service
def get_openai_service():
    """Get OpenAI service instance"""
    api_key = request.headers.get('X-OpenAI-API-Key') or config['api'].OPENAI_API_KEY
    return OpenAIService(api_key=api_key)

# Error handler
@ad_content_bp.errorhandler(AppError)
def handle_app_error(error):
    """Handle application errors"""
    return api_error_handler(error)

# Ad content generation endpoints
@ad_content_bp.route('/generate', methods=['POST'])
def generate_ad_content():
    """Generate ad content using OpenAI"""
    try:
        data = request.get_json()
        
        # Required parameters
        project_data = data.get('project_data')
        content_type = data.get('content_type', 'all')  # headline, primary_text, description, all
        
        # Optional parameters
        tone = data.get('tone', 'persuasive')
        platform = data.get('platform', 'facebook')
        num_variations = data.get('num_variations', 3)
        
        # Validate required parameters
        if not project_data:
            raise AppError("Missing project_data parameter")
        
        # Generate ad content
        openai_service = get_openai_service()
        
        if content_type == 'headline':
            result = openai_service.generate_headlines(
                project_data=project_data,
                tone=tone,
                platform=platform,
                num_variations=num_variations
            )
        elif content_type == 'primary_text':
            result = openai_service.generate_primary_text(
                project_data=project_data,
                tone=tone,
                platform=platform,
                num_variations=num_variations
            )
        elif content_type == 'description':
            result = openai_service.generate_descriptions(
                project_data=project_data,
                tone=tone,
                platform=platform,
                num_variations=num_variations
            )
        else:  # all
            result = openai_service.generate_ad_content(
                project_data=project_data,
                tone=tone,
                platform=platform,
                num_variations=num_variations
            )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error generating ad content: {str(e)}")
        return jsonify({"error": str(e)}), 500

@ad_content_bp.route('/tones', methods=['GET'])
def get_tones():
    """Get available tones for ad content generation"""
    tones = [
        {"id": "persuasive", "name": "Persuasive", "description": "Convincing and compelling tone to drive action"},
        {"id": "witty", "name": "Witty", "description": "Clever and humorous tone to engage and entertain"},
        {"id": "professional", "name": "Professional", "description": "Formal and business-like tone for corporate audiences"},
        {"id": "friendly", "name": "Friendly", "description": "Warm and approachable tone to build rapport"},
        {"id": "urgent", "name": "Urgent", "description": "Creates a sense of urgency and FOMO (fear of missing out)"}
    ]
    
    return jsonify({"tones": tones})

@ad_content_bp.route('/platforms', methods=['GET'])
def get_platforms():
    """Get available platforms for ad content generation"""
    platforms = [
        {
            "id": "facebook", 
            "name": "Facebook", 
            "specs": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            }
        },
        {
            "id": "instagram", 
            "name": "Instagram", 
            "specs": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            }
        },
        {
            "id": "meta", 
            "name": "Meta (General)", 
            "specs": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            }
        }
    ]
    
    return jsonify({"platforms": platforms})

@ad_content_bp.route('/optimize', methods=['POST'])
def optimize_ad_content():
    """Optimize ad content based on Meta best practices"""
    try:
        data = request.get_json()
        
        # Required parameters
        content = data.get('content')
        content_type = data.get('content_type')  # headline, primary_text, description
        
        # Optional parameters
        platform = data.get('platform', 'facebook')
        
        # Validate required parameters
        if not content or not content_type:
            raise AppError("Missing required parameters")
        
        # Optimize ad content
        openai_service = get_openai_service()
        result = openai_service.optimize_ad_content(
            content=content,
            content_type=content_type,
            platform=platform
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error optimizing ad content: {str(e)}")
        return jsonify({"error": str(e)}), 500

