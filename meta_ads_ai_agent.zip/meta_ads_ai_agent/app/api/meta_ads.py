"""
API endpoints for Meta Ads Marketing API integration
"""

import os
import json
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename

from app.services.meta_ads_service import MetaAdsService
from app.services.meta_auth import MetaAuthService
from app.utils.logger import get_logger
from app.utils.error_handler import api_error_handler, AppError
from config.config import config

logger = get_logger(__name__)

# Create blueprint
meta_ads_bp = Blueprint('meta_ads', __name__, url_prefix='/api/meta-ads')

# Initialize services
def get_meta_ads_service():
    """Get Meta Ads service instance"""
    access_token = request.headers.get('X-Meta-Access-Token') or config['api'].META_ACCESS_TOKEN
    return MetaAdsService(access_token=access_token)

def get_meta_auth_service():
    """Get Meta Auth service instance"""
    access_token = request.headers.get('X-Meta-Access-Token') or config['api'].META_ACCESS_TOKEN
    return MetaAuthService(access_token=access_token)

# Error handler
@meta_ads_bp.errorhandler(AppError)
def handle_app_error(error):
    """Handle application errors"""
    return api_error_handler(error)

# Authentication endpoints
@meta_ads_bp.route('/auth/validate-token', methods=['GET'])
def validate_token():
    """Validate Meta Ads API access token"""
    try:
        auth_service = get_meta_auth_service()
        result = auth_service.validate_token()
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/auth/user-accounts', methods=['GET'])
def get_user_accounts():
    """Get user accounts"""
    try:
        auth_service = get_meta_auth_service()
        result = auth_service.get_user_accounts()
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/auth/ad-accounts', methods=['GET'])
def get_ad_accounts():
    """Get ad accounts"""
    try:
        auth_service = get_meta_auth_service()
        result = auth_service.get_ad_accounts()
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/auth/pages', methods=['GET'])
def get_pages():
    """Get Facebook pages"""
    try:
        auth_service = get_meta_auth_service()
        result = auth_service.get_pages()
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/auth/permissions', methods=['GET'])
def get_permissions():
    """Get permissions for the current access token"""
    try:
        auth_service = get_meta_auth_service()
        result = auth_service.get_permissions()
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/auth/check-permissions', methods=['POST'])
def check_permissions():
    """Check if the current access token has the required permissions"""
    try:
        data = request.get_json()
        required_permissions = data.get('required_permissions', [])
        
        auth_service = get_meta_auth_service()
        result = auth_service.check_required_permissions(required_permissions)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Ad Creative endpoints
@meta_ads_bp.route('/creatives/create', methods=['POST'])
def create_ad_creative():
    """Create an ad creative"""
    try:
        data = request.get_json()
        
        # Required parameters
        account_id = data.get('account_id')
        page_id = data.get('page_id')
        image_hash = data.get('image_hash')
        headline = data.get('headline')
        primary_text = data.get('primary_text')
        link = data.get('link')
        
        # Optional parameters
        name = data.get('name')
        description = data.get('description')
        call_to_action_type = data.get('call_to_action_type', 'LEARN_MORE')
        use_text_generation = data.get('use_text_generation', False)
        
        # Validate required parameters
        if not all([account_id, page_id, image_hash, headline, primary_text, link]):
            raise AppError("Missing required parameters")
        
        # Create ad creative
        ads_service = get_meta_ads_service()
        result = ads_service.create_ad_creative(
            account_id=account_id,
            page_id=page_id,
            image_hash=image_hash,
            headline=headline,
            primary_text=primary_text,
            link=link,
            name=name,
            description=description,
            call_to_action_type=call_to_action_type,
            use_text_generation=use_text_generation
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/creatives/<creative_id>', methods=['GET'])
def get_ad_creative(creative_id):
    """Get an ad creative"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.get_ad_creative(account_id=None, creative_id=creative_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/accounts/<account_id>/creatives', methods=['GET'])
def list_ad_creatives(account_id):
    """List ad creatives for an account"""
    try:
        limit = request.args.get('limit', 100, type=int)
        
        ads_service = get_meta_ads_service()
        result = ads_service.list_ad_creatives(account_id=account_id, limit=limit)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Ad endpoints
@meta_ads_bp.route('/ads/create', methods=['POST'])
def create_ad():
    """Create an ad"""
    try:
        data = request.get_json()
        
        # Required parameters
        account_id = data.get('account_id')
        adset_id = data.get('adset_id')
        
        # Optional parameters
        creative_id = data.get('creative_id')
        creative_data = data.get('creative_data')
        name = data.get('name')
        status = data.get('status', 'PAUSED')
        tracking_specs = data.get('tracking_specs')
        
        # Validate required parameters
        if not all([account_id, adset_id]):
            raise AppError("Missing required parameters")
        
        if not creative_id and not creative_data:
            raise AppError("Either creative_id or creative_data must be provided")
        
        # Create ad
        ads_service = get_meta_ads_service()
        result = ads_service.create_ad(
            account_id=account_id,
            adset_id=adset_id,
            creative_id=creative_id,
            creative_data=creative_data,
            name=name,
            status=status,
            tracking_specs=tracking_specs
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/ads/<ad_id>', methods=['GET'])
def get_ad(ad_id):
    """Get an ad"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.get_ad(ad_id=ad_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/ads/<ad_id>', methods=['PUT'])
def update_ad(ad_id):
    """Update an ad"""
    try:
        data = request.get_json()
        
        ads_service = get_meta_ads_service()
        result = ads_service.update_ad(ad_id=ad_id, data=data)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/ads/<ad_id>', methods=['DELETE'])
def delete_ad(ad_id):
    """Delete an ad"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.delete_ad(ad_id=ad_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/accounts/<account_id>/ads', methods=['GET'])
def list_ads(account_id):
    """List ads for an account"""
    try:
        limit = request.args.get('limit', 100, type=int)
        status = request.args.get('status')
        
        ads_service = get_meta_ads_service()
        result = ads_service.list_ads(account_id=account_id, limit=limit, status=status)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/ads/bulk-create', methods=['POST'])
def create_bulk_ads():
    """Create multiple ads in bulk"""
    try:
        data = request.get_json()
        
        # Required parameters
        account_id = data.get('account_id')
        adset_id = data.get('adset_id')
        creatives = data.get('creatives')
        
        # Optional parameters
        status = data.get('status', 'PAUSED')
        
        # Validate required parameters
        if not all([account_id, adset_id, creatives]):
            raise AppError("Missing required parameters")
        
        if not isinstance(creatives, list) or len(creatives) == 0:
            raise AppError("Creatives must be a non-empty list")
        
        # Create ads in bulk
        ads_service = get_meta_ads_service()
        result = ads_service.create_bulk_ads(
            account_id=account_id,
            adset_id=adset_id,
            creatives=creatives,
            status=status
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Ad Preview endpoints
@meta_ads_bp.route('/accounts/<account_id>/ad-preview', methods=['GET'])
def get_ad_preview(account_id):
    """Get a preview of an ad"""
    try:
        creative_id = request.args.get('creative_id')
        ad_format = request.args.get('ad_format', 'DESKTOP_FEED_STANDARD')
        
        if not creative_id:
            raise AppError("Missing creative_id parameter")
        
        ads_service = get_meta_ads_service()
        result = ads_service.get_ad_preview(
            account_id=account_id,
            creative_id=creative_id,
            ad_format=ad_format
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Image endpoints
@meta_ads_bp.route('/accounts/<account_id>/images/upload', methods=['POST'])
def upload_image(account_id):
    """Upload an image to be used in ads"""
    try:
        # Check if the post request has the file part
        if 'file' not in request.files:
            raise AppError("No file part")
        
        file = request.files['file']
        
        # If user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            raise AppError("No selected file")
        
        # Save the file temporarily
        filename = secure_filename(file.filename)
        temp_path = os.path.join(current_app.instance_path, filename)
        os.makedirs(os.path.dirname(temp_path), exist_ok=True)
        file.save(temp_path)
        
        # Upload the image to Meta Ads
        ads_service = get_meta_ads_service()
        result = ads_service.upload_image(account_id=account_id, image_path=temp_path)
        
        # Remove the temporary file
        os.remove(temp_path)
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@meta_ads_bp.route('/images/<image_hash>', methods=['GET'])
def get_image(image_hash):
    """Get an image"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.get_image(image_hash=image_hash)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/accounts/<account_id>/images', methods=['GET'])
def list_images(account_id):
    """List images for an account"""
    try:
        limit = request.args.get('limit', 100, type=int)
        
        ads_service = get_meta_ads_service()
        result = ads_service.list_images(account_id=account_id, limit=limit)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Campaign endpoints
@meta_ads_bp.route('/campaigns/create', methods=['POST'])
def create_campaign():
    """Create a campaign"""
    try:
        data = request.get_json()
        
        # Required parameters
        account_id = data.get('account_id')
        name = data.get('name')
        objective = data.get('objective')
        
        # Optional parameters
        status = data.get('status', 'PAUSED')
        special_ad_categories = data.get('special_ad_categories')
        spend_cap = data.get('spend_cap')
        
        # Validate required parameters
        if not all([account_id, name, objective]):
            raise AppError("Missing required parameters")
        
        # Create campaign
        ads_service = get_meta_ads_service()
        result = ads_service.create_campaign(
            account_id=account_id,
            name=name,
            objective=objective,
            status=status,
            special_ad_categories=special_ad_categories,
            spend_cap=spend_cap
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/campaigns/<campaign_id>', methods=['GET'])
def get_campaign(campaign_id):
    """Get a campaign"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.get_campaign(campaign_id=campaign_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/campaigns/<campaign_id>', methods=['PUT'])
def update_campaign(campaign_id):
    """Update a campaign"""
    try:
        data = request.get_json()
        
        ads_service = get_meta_ads_service()
        result = ads_service.update_campaign(campaign_id=campaign_id, data=data)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/campaigns/<campaign_id>', methods=['DELETE'])
def delete_campaign(campaign_id):
    """Delete a campaign"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.delete_campaign(campaign_id=campaign_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/accounts/<account_id>/campaigns', methods=['GET'])
def list_campaigns(account_id):
    """List campaigns for an account"""
    try:
        limit = request.args.get('limit', 100, type=int)
        status = request.args.get('status')
        
        ads_service = get_meta_ads_service()
        result = ads_service.list_campaigns(account_id=account_id, limit=limit, status=status)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Ad Set endpoints
@meta_ads_bp.route('/adsets/create', methods=['POST'])
def create_adset():
    """Create an ad set"""
    try:
        data = request.get_json()
        
        # Required parameters
        account_id = data.get('account_id')
        campaign_id = data.get('campaign_id')
        name = data.get('name')
        optimization_goal = data.get('optimization_goal')
        billing_event = data.get('billing_event')
        bid_amount = data.get('bid_amount')
        daily_budget = data.get('daily_budget')
        targeting = data.get('targeting')
        
        # Optional parameters
        status = data.get('status', 'PAUSED')
        start_time = data.get('start_time')
        end_time = data.get('end_time')
        
        # Validate required parameters
        if not all([account_id, campaign_id, name, optimization_goal, billing_event, bid_amount, daily_budget, targeting]):
            raise AppError("Missing required parameters")
        
        # Create ad set
        ads_service = get_meta_ads_service()
        result = ads_service.create_adset(
            account_id=account_id,
            campaign_id=campaign_id,
            name=name,
            optimization_goal=optimization_goal,
            billing_event=billing_event,
            bid_amount=bid_amount,
            daily_budget=daily_budget,
            targeting=targeting,
            status=status,
            start_time=start_time,
            end_time=end_time
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/adsets/<adset_id>', methods=['GET'])
def get_adset(adset_id):
    """Get an ad set"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.get_adset(adset_id=adset_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/adsets/<adset_id>', methods=['PUT'])
def update_adset(adset_id):
    """Update an ad set"""
    try:
        data = request.get_json()
        
        ads_service = get_meta_ads_service()
        result = ads_service.update_adset(adset_id=adset_id, data=data)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/adsets/<adset_id>', methods=['DELETE'])
def delete_adset(adset_id):
    """Delete an ad set"""
    try:
        ads_service = get_meta_ads_service()
        result = ads_service.delete_adset(adset_id=adset_id)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/accounts/<account_id>/adsets', methods=['GET'])
def list_adsets(account_id):
    """List ad sets for an account"""
    try:
        limit = request.args.get('limit', 100, type=int)
        status = request.args.get('status')
        
        ads_service = get_meta_ads_service()
        result = ads_service.list_adsets(account_id=account_id, limit=limit, status=status)
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Insights endpoints
@meta_ads_bp.route('/accounts/<account_id>/insights', methods=['GET'])
def get_insights(account_id):
    """Get insights for an account"""
    try:
        # Get parameters
        level = request.args.get('level', 'account')
        date_preset = request.args.get('date_preset', 'last_30d')
        time_range_since = request.args.get('time_range_since')
        time_range_until = request.args.get('time_range_until')
        limit = request.args.get('limit', 100, type=int)
        
        # Get fields
        fields_str = request.args.get('fields')
        fields = fields_str.split(',') if fields_str else None
        
        # Get breakdowns
        breakdowns_str = request.args.get('breakdowns')
        breakdowns = breakdowns_str.split(',') if breakdowns_str else None
        
        # Prepare time range if provided
        time_range = None
        if time_range_since and time_range_until:
            time_range = {
                "since": time_range_since,
                "until": time_range_until
            }
        
        # Get insights
        ads_service = get_meta_ads_service()
        result = ads_service.get_insights(
            account_id=account_id,
            level=level,
            fields=fields,
            date_preset=date_preset,
            time_range=time_range,
            breakdowns=breakdowns,
            limit=limit
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

@meta_ads_bp.route('/ads/<ad_id>/insights', methods=['GET'])
def get_ad_insights(ad_id):
    """Get insights for a specific ad"""
    try:
        # Get parameters
        date_preset = request.args.get('date_preset', 'last_30d')
        time_range_since = request.args.get('time_range_since')
        time_range_until = request.args.get('time_range_until')
        
        # Get fields
        fields_str = request.args.get('fields')
        fields = fields_str.split(',') if fields_str else None
        
        # Get breakdowns
        breakdowns_str = request.args.get('breakdowns')
        breakdowns = breakdowns_str.split(',') if breakdowns_str else None
        
        # Prepare time range if provided
        time_range = None
        if time_range_since and time_range_until:
            time_range = {
                "since": time_range_since,
                "until": time_range_until
            }
        
        # Get ad insights
        ads_service = get_meta_ads_service()
        result = ads_service.get_ad_insights(
            ad_id=ad_id,
            fields=fields,
            date_preset=date_preset,
            time_range=time_range,
            breakdowns=breakdowns
        )
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

# Batch operations
@meta_ads_bp.route('/batch', methods=['POST'])
def batch_request():
    """Make a batch request to the Meta Ads API"""
    try:
        data = request.get_json()
        batch_requests = data.get('batch_requests')
        
        if not batch_requests:
            raise AppError("Missing batch_requests parameter")
        
        ads_service = get_meta_ads_service()
        result = ads_service.batch_request(batch_requests=batch_requests)
        
        return jsonify(result)
    except AppError as e:
        return jsonify({"error": str(e)}), 400

