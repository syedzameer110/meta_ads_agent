/**
 * Meta Ads AI Agent - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tabs
    initTabs();
    
    // Initialize forms
    initForms();
    
    // Initialize ad preview
    initAdPreview();
});

/**
 * Initialize tab functionality
 */
function initTabs() {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs and contents
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            const contentId = tab.getAttribute('data-tab');
            document.getElementById(contentId).classList.add('active');
        });
    });
}

/**
 * Initialize form submissions
 */
function initForms() {
    // Ad Content Generation Form
    const adContentForm = document.getElementById('ad-content-form');
    if (adContentForm) {
        adContentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading indicator
            showLoading('ad-content-results');
            
            // Get form data
            const formData = {
                product_info: {
                    name: document.getElementById('product-name').value,
                    description: document.getElementById('product-description').value,
                    target_audience: document.getElementById('target-audience').value,
                    unique_selling_points: document.getElementById('unique-selling-points').value.split('\n').filter(usp => usp.trim() !== ''),
                    call_to_action: document.getElementById('call-to-action').value
                },
                tone: document.getElementById('tone').value,
                platform: document.getElementById('platform').value,
                num_variations: parseInt(document.getElementById('num-variations').value)
            };
            
            // Send API request
            fetch('/api/ad-content/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading indicator
                hideLoading('ad-content-results');
                
                // Display results
                displayAdContentResults(data.variations);
            })
            .catch(error => {
                // Hide loading indicator
                hideLoading('ad-content-results');
                
                // Show error
                showError('Error generating ad content: ' + error.message);
            });
        });
    }
    
    // Meta Ads Creation Form
    const metaAdsForm = document.getElementById('meta-ads-form');
    if (metaAdsForm) {
        metaAdsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading indicator
            showLoading('meta-ads-results');
            
            // Get form data
            const formData = new FormData(metaAdsForm);
            
            // Send API request
            fetch('/api/meta-ads/create-ad', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading indicator
                hideLoading('meta-ads-results');
                
                // Display results
                if (data.error) {
                    showError('Error creating ad: ' + data.error);
                } else {
                    showSuccess('Ad created successfully!');
                    document.getElementById('meta-ads-results').innerHTML = 
                        `<div class="card">
                            <div class="card-header">
                                <h3>Ad Created</h3>
                            </div>
                            <div class="card-body">
                                <p>Ad ID: ${data.id}</p>
                                <p>Status: ${data.status}</p>
                            </div>
                        </div>`;
                }
            })
            .catch(error => {
                // Hide loading indicator
                hideLoading('meta-ads-results');
                
                // Show error
                showError('Error creating ad: ' + error.message);
            });
        });
    }
    
    // Integration Form
    const integrationForm = document.getElementById('integration-form');
    if (integrationForm) {
        integrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading indicator
            showLoading('integration-results');
            
            // Get form data
            const formData = new FormData(integrationForm);
            const integrationData = {};
            formData.forEach((value, key) => {
                integrationData[key] = value;
            });
            
            // Send API request based on integration type
            const integrationType = document.getElementById('integration-type').value;
            let endpoint = '';
            
            switch (integrationType) {
                case 'google-sheets':
                    endpoint = '/api/integrations/google-sheets/write';
                    break;
                case 'airtable':
                    endpoint = '/api/integrations/airtable/write';
                    break;
                case 'n8n':
                    endpoint = '/api/integrations/n8n/webhook';
                    break;
                default:
                    showError('Invalid integration type');
                    hideLoading('integration-results');
                    return;
            }
            
            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(integrationData)
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading indicator
                hideLoading('integration-results');
                
                // Display results
                if (data.error) {
                    showError('Error with integration: ' + data.error);
                } else {
                    showSuccess('Integration successful!');
                    document.getElementById('integration-results').innerHTML = 
                        `<div class="card">
                            <div class="card-header">
                                <h3>Integration Result</h3>
                            </div>
                            <div class="card-body">
                                <pre>${JSON.stringify(data, null, 2)}</pre>
                            </div>
                        </div>`;
                }
            })
            .catch(error => {
                // Hide loading indicator
                hideLoading('integration-results');
                
                // Show error
                showError('Error with integration: ' + error.message);
            });
        });
    }
}

/**
 * Initialize ad preview functionality
 */
function initAdPreview() {
    // Update ad preview when headline or primary text changes
    const headlineInput = document.getElementById('headline');
    const primaryTextInput = document.getElementById('primary-text');
    const imageInput = document.getElementById('ad-image');
    
    if (headlineInput) {
        headlineInput.addEventListener('input', updateAdPreview);
    }
    
    if (primaryTextInput) {
        primaryTextInput.addEventListener('input', updateAdPreview);
    }
    
    if (imageInput) {
        imageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('ad-preview-image').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }
}

/**
 * Update the ad preview with current values
 */
function updateAdPreview() {
    const headline = document.getElementById('headline').value || 'Your Headline Here';
    const primaryText = document.getElementById('primary-text').value || 'Your primary text will appear here. Make it engaging and compelling!';
    const ctaText = document.getElementById('call-to-action').value || 'Learn More';
    
    document.getElementById('ad-preview-headline').textContent = headline;
    document.getElementById('ad-preview-text').textContent = primaryText;
    document.getElementById('ad-preview-cta').textContent = ctaText;
}

/**
 * Display ad content generation results
 */
function displayAdContentResults(variations) {
    const resultsContainer = document.getElementById('ad-content-results');
    resultsContainer.innerHTML = '';
    
    if (!variations || variations.length === 0) {
        resultsContainer.innerHTML = '<div class="alert alert-warning">No variations generated</div>';
        return;
    }
    
    // Create results header
    const header = document.createElement('div');
    header.className = 'card-header';
    header.innerHTML = '<h2>Generated Ad Content</h2>';
    resultsContainer.appendChild(header);
    
    // Create variations container
    const variationsContainer = document.createElement('div');
    variationsContainer.className = 'variations-container';
    
    // Add each variation
    variations.forEach((variation, index) => {
        const variationCard = document.createElement('div');
        variationCard.className = 'card';
        variationCard.innerHTML = `
            <div class="card-header">
                <h3>Variation ${index + 1}</h3>
                <button class="btn btn-outline use-variation" data-variation="${index}">Use This</button>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label>Headline:</label>
                    <div class="content-box">${variation.headline}</div>
                </div>
                <div class="form-group">
                    <label>Primary Text:</label>
                    <div class="content-box">${variation.primary_text}</div>
                </div>
            </div>
        `;
        variationsContainer.appendChild(variationCard);
    });
    
    resultsContainer.appendChild(variationsContainer);
    
    // Add event listeners to "Use This" buttons
    document.querySelectorAll('.use-variation').forEach(button => {
        button.addEventListener('click', function() {
            const variationIndex = parseInt(this.getAttribute('data-variation'));
            const variation = variations[variationIndex];
            
            // Fill in the form fields
            document.getElementById('headline').value = variation.headline;
            document.getElementById('primary-text').value = variation.primary_text;
            
            // Update the preview
            updateAdPreview();
            
            // Scroll to the form
            document.getElementById('meta-ads-form').scrollIntoView({ behavior: 'smooth' });
        });
    });
}

/**
 * Show loading indicator
 */
function showLoading(containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = `
        <div class="loading">
            <div class="loading-spinner"></div>
            <p>Loading...</p>
        </div>
    `;
}

/**
 * Hide loading indicator
 */
function hideLoading(containerId) {
    const container = document.getElementById(containerId);
    container.querySelector('.loading')?.remove();
}

/**
 * Show success message
 */
function showSuccess(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-success';
    alertContainer.textContent = message;
    
    document.querySelector('.main-content').prepend(alertContainer);
    
    // Remove after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

/**
 * Show error message
 */
function showError(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-error';
    alertContainer.textContent = message;
    
    document.querySelector('.main-content').prepend(alertContainer);
    
    // Remove after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

