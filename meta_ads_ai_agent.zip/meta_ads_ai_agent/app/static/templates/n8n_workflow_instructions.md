# Meta Ads Automation with n8n

This document provides instructions for setting up and using the Meta Ads automation workflow in n8n.

## Overview

The workflow automates the process of creating Meta ads from data stored in Google Sheets. It performs the following steps:

1. Reads ad data from a Google Sheet
2. Filters valid rows
3. Uploads images to Meta
4. Creates ads using the Meta Ads API
5. Logs results back to a Google Sheet

## Prerequisites

Before using this workflow, you need:

1. An n8n instance (self-hosted or cloud)
2. A Meta Business account with access to the Ads Manager
3. A Meta App with the necessary permissions
4. A Google account with access to Google Sheets
5. The following API credentials:
   - Meta Graph API access token
   - Google Sheets OAuth2 credentials

## Setup Instructions

### 1. Import the Workflow

1. Download the `n8n_meta_ads_workflow.json` file
2. In your n8n instance, go to "Workflows"
3. Click "Import from File" and select the downloaded JSON file
4. The workflow will be imported with placeholder values that need to be updated

### 2. Configure Google Sheets Credentials

1. In n8n, go to "Credentials" and create a new "Google Sheets OAuth2 API" credential
2. Follow the prompts to authenticate with your Google account
3. In the workflow, update the Google Sheets nodes to use your new credential

### 3. Configure Meta API Credentials

1. In n8n, go to "Credentials" and create a new "Facebook Graph API" credential
2. Enter your Meta access token
3. In the workflow, update the Meta nodes to use your new credential
4. Replace `YOUR_AD_ACCOUNT_ID` with your actual Ad Account ID in the HTTP Request nodes

### 4. Set Up Google Sheets

1. Create a new Google Sheet for ad data with the following columns:
   - campaign_name
   - adset_name
   - ad_name
   - headline
   - primary_text
   - description
   - link
   - image_url
   - page_id
   - call_to_action
   - status
   - adset_id (required for ad creation)

2. Create another Google Sheet for results with the following columns:
   - ad_name
   - status
   - created_at
   - ad_id
   - result
   - error

3. Update the Google Sheets nodes in the workflow with your sheet IDs

### 5. Test the Workflow

1. Add test data to your Google Sheet
2. Run the workflow manually to verify it works
3. Check the results in your results Google Sheet
4. Verify the ads were created in Meta Ads Manager

### 6. Schedule the Workflow

1. Configure the Schedule Trigger node with your desired schedule
2. Activate the workflow

## Customization

You can customize the workflow to fit your specific needs:

- Add more fields to the Google Sheet and update the "Set Ad Data" node
- Modify the ad creation parameters in the "Create Ad" node
- Add error handling and notification nodes
- Extend the workflow to create campaigns and ad sets

## Troubleshooting

If you encounter issues:

1. Check the execution logs in n8n
2. Verify your API credentials are valid
3. Ensure your Meta access token has the necessary permissions
4. Check that your Google Sheet has the correct format and data

## Additional Resources

- [n8n Documentation](https://docs.n8n.io/)
- [Meta Marketing API Documentation](https://developers.facebook.com/docs/marketing-apis/)
- [Google Sheets API Documentation](https://developers.google.com/sheets/api/)

