"""
Web routes for Meta Ads AI Agent
"""

import os
import sys
import platform
import flask
import openai

from flask import render_template, request, jsonify, redirect, url_for
from app.utils.logger import get_logger
from config.config import config

logger = get_logger(__name__)

def register_routes(app):
    """Register web routes with the Flask application"""
    
    @app.route('/')
    def index():
        """Home page"""
        return render_template('index.html')
    
    @app.route('/ad-content')
    def ad_content():
        """Ad content generation page"""
        return render_template('ad_content.html')
    
    @app.route('/meta-ads')
    def meta_ads():
        """Meta ads creation page"""
        return render_template('meta_ads.html')
    
    @app.route('/integrations')
    def integrations():
        """Integrations page"""
        return render_template('integrations.html')
    
    @app.route('/settings')
    def settings():
        """Settings page"""
        # Get system information
        python_version = platform.python_version()
        flask_version = flask.__version__
        openai_version = openai.__version__
        
        # Get current settings
        meta_access_token = config['api'].META_ACCESS_TOKEN or ''
        openai_api_key = config['api'].OPENAI_API_KEY or ''
        airtable_api_key = config['api'].AIRTABLE_API_KEY or ''
        
        # Get preferences
        default_platform = config['preferences'].DEFAULT_PLATFORM
        default_tone = config['preferences'].DEFAULT_TONE
        default_num_variations = config['preferences'].DEFAULT_NUM_VARIATIONS
        use_text_generation = config['preferences'].USE_TEXT_GENERATION
        
        return render_template(
            'settings.html',
            python_version=python_version,
            flask_version=flask_version,
            openai_version=openai_version,
            meta_access_token=meta_access_token,
            openai_api_key=openai_api_key,
            airtable_api_key=airtable_api_key,
            default_platform=default_platform,
            default_tone=default_tone,
            default_num_variations=default_num_variations,
            use_text_generation=use_text_generation
        )
    
    @app.route('/settings/api-keys', methods=['POST'])
    def update_api_keys():
        """Update API keys"""
        try:
            # Get form data
            meta_access_token = request.form.get('meta_access_token')
            openai_api_key = request.form.get('openai_api_key')
            airtable_api_key = request.form.get('airtable_api_key')
            
            # Update environment variables
            if meta_access_token:
                os.environ['META_ACCESS_TOKEN'] = meta_access_token
            
            if openai_api_key:
                os.environ['OPENAI_API_KEY'] = openai_api_key
            
            if airtable_api_key:
                os.environ['AIRTABLE_API_KEY'] = airtable_api_key
            
            # Handle Google credentials file
            google_credentials_file = request.files.get('google_credentials_file')
            if google_credentials_file:
                # Save the file
                credentials_path = os.path.join(app.instance_path, 'google_credentials.json')
                os.makedirs(os.path.dirname(credentials_path), exist_ok=True)
                google_credentials_file.save(credentials_path)
                
                # Update environment variable
                os.environ['GOOGLE_CREDENTIALS_FILE'] = credentials_path
            
            # Update config
            config['api'].META_ACCESS_TOKEN = meta_access_token
            config['api'].OPENAI_API_KEY = openai_api_key
            config['api'].AIRTABLE_API_KEY = airtable_api_key
            
            return jsonify({"status": "success", "message": "API keys updated successfully"})
        
        except Exception as e:
            logger.error(f"Error updating API keys: {str(e)}")
            return jsonify({"status": "error", "message": f"Error updating API keys: {str(e)}"}), 500
    
    @app.route('/settings/preferences', methods=['POST'])
    def update_preferences():
        """Update preferences"""
        try:
            # Get form data
            default_platform = request.form.get('default_platform')
            default_tone = request.form.get('default_tone')
            default_num_variations = request.form.get('default_num_variations')
            use_text_generation = 'use_text_generation' in request.form
            
            # Update config
            config['preferences'].DEFAULT_PLATFORM = default_platform
            config['preferences'].DEFAULT_TONE = default_tone
            config['preferences'].DEFAULT_NUM_VARIATIONS = int(default_num_variations)
            config['preferences'].USE_TEXT_GENERATION = use_text_generation
            
            return jsonify({"status": "success", "message": "Preferences updated successfully"})
        
        except Exception as e:
            logger.error(f"Error updating preferences: {str(e)}")
            return jsonify({"status": "error", "message": f"Error updating preferences: {str(e)}"}), 500

