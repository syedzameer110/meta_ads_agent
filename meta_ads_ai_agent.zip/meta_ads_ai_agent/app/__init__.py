"""
Meta Ads AI Agent - Main Application Package
"""

__version__ = '0.1.0'

