"""
Meta Ads Service for interacting with Meta Ads Marketing API
"""

import os
import json
import requests
from typing import Dict, List, Any, Optional

from app.utils.logger import get_logger
from app.utils.error_handler import AppError
from app.services.meta_auth import MetaAuthService

logger = get_logger(__name__)

class MetaAdsService:
    """Service for interacting with Meta Ads Marketing API"""
    
    def __init__(self, access_token: str = None, api_version: str = "v23.0"):
        """Initialize the Meta Ads service
        
        Args:
            access_token: Meta Ads API access token. If None, will try to get from environment variable.
            api_version: Meta Ads API version
        """
        self.auth_service = MetaAuthService(access_token, api_version)
        self.access_token = self.auth_service.access_token
        self.api_version = self.auth_service.api_version
        self.base_url = self.auth_service.base_url
    
    # Ad Creative Management
    
    def create_ad_creative(
        self, 
        account_id: str, 
        page_id: str, 
        image_hash: str, 
        headline: str, 
        primary_text: str, 
        link: str,
        name: str = None,
        description: str = None,
        call_to_action_type: str = "LEARN_MORE",
        use_text_generation: bool = False
    ) -> Dict[str, Any]:
        """Create an ad creative
        
        Args:
            account_id: Ad account ID
            page_id: Facebook page ID
            image_hash: Hash of the uploaded image
            headline: Ad headline
            primary_text: Ad primary text
            link: URL to direct users to
            name: Name of the creative
            description: Ad description
            call_to_action_type: Call to action type
            use_text_generation: Whether to use Meta's text generation feature
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot create ad creative.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adcreatives"
        
        # Prepare the link_data
        link_data = {
            "image_hash": image_hash,
            "link": link,
            "message": primary_text,
            "headline": headline,
            "call_to_action": {
                "type": call_to_action_type
            }
        }
        
        # Add description if provided
        if description:
            link_data["description"] = description
        
        # Prepare the object_story_spec
        object_story_spec = {
            "page_id": page_id,
            "link_data": link_data
        }
        
        # Prepare the payload
        payload = {
            "name": name or f"Creative for {headline[:20]}...",
            "object_story_spec": json.dumps(object_story_spec),
            "access_token": self.access_token
        }
        
        # Add text generation if requested
        if use_text_generation:
            degrees_of_freedom_spec = {
                "creative_features_spec": {
                    "text_generation": {
                        "enroll_status": "OPT_IN"
                    }
                }
            }
            payload["degrees_of_freedom_spec"] = json.dumps(degrees_of_freedom_spec)
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating ad creative: {str(e)}")
            raise AppError(f"Error creating ad creative: {str(e)}")
    
    def get_ad_creative(self, account_id: str, creative_id: str) -> Dict[str, Any]:
        """Get an ad creative
        
        Args:
            account_id: Ad account ID
            creative_id: Creative ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad creative.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{creative_id}"
        
        params = {
            "fields": "id,name,object_story_spec,thumbnail_url,image_url,asset_feed_spec,object_type",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad creative: {str(e)}")
            raise AppError(f"Error getting ad creative: {str(e)}")
    
    def list_ad_creatives(self, account_id: str, limit: int = 100) -> Dict[str, Any]:
        """List ad creatives for an account
        
        Args:
            account_id: Ad account ID
            limit: Maximum number of creatives to return
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot list ad creatives.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adcreatives"
        
        params = {
            "fields": "id,name,object_story_spec,thumbnail_url,image_url",
            "limit": limit,
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing ad creatives: {str(e)}")
            raise AppError(f"Error listing ad creatives: {str(e)}")
    
    # Ad Management
    
    def create_ad(
        self, 
        account_id: str, 
        adset_id: str, 
        creative_id: str = None,
        creative_data: Dict[str, Any] = None,
        name: str = None,
        status: str = "PAUSED",
        tracking_specs: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Create an ad
        
        Args:
            account_id: Ad account ID
            adset_id: Ad set ID
            creative_id: ID of an existing creative
            creative_data: Data for creating a new creative inline
            name: Name of the ad
            status: Status of the ad (ACTIVE, PAUSED)
            tracking_specs: Tracking specifications
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot create ad.")
            raise AppError("API token not provided")
        
        if not creative_id and not creative_data:
            logger.error("Either creative_id or creative_data must be provided.")
            raise AppError("Either creative_id or creative_data must be provided")
        
        url = f"{self.base_url}/act_{account_id}/ads"
        
        # Prepare the payload
        payload = {
            "adset_id": adset_id,
            "status": status,
            "access_token": self.access_token
        }
        
        # Add name if provided
        if name:
            payload["name"] = name
        
        # Add creative information
        if creative_id:
            payload["creative"] = json.dumps({"creative_id": creative_id})
        elif creative_data:
            payload["creative"] = json.dumps(creative_data)
        
        # Add tracking specifications if provided
        if tracking_specs:
            payload["tracking_specs"] = json.dumps(tracking_specs)
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating ad: {str(e)}")
            raise AppError(f"Error creating ad: {str(e)}")
    
    def get_ad(self, ad_id: str) -> Dict[str, Any]:
        """Get an ad
        
        Args:
            ad_id: Ad ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{ad_id}"
        
        params = {
            "fields": "id,name,adset_id,campaign_id,creative,status,created_time,updated_time",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad: {str(e)}")
            raise AppError(f"Error getting ad: {str(e)}")
    
    def update_ad(self, ad_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an ad
        
        Args:
            ad_id: Ad ID
            data: Data to update
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot update ad.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{ad_id}"
        
        # Add access token to data
        data["access_token"] = self.access_token
        
        try:
            response = requests.post(url, data=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error updating ad: {str(e)}")
            raise AppError(f"Error updating ad: {str(e)}")
    
    def delete_ad(self, ad_id: str) -> Dict[str, Any]:
        """Delete an ad
        
        Args:
            ad_id: Ad ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot delete ad.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{ad_id}"
        
        params = {
            "access_token": self.access_token
        }
        
        try:
            response = requests.delete(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error deleting ad: {str(e)}")
            raise AppError(f"Error deleting ad: {str(e)}")
    
    def list_ads(self, account_id: str, limit: int = 100, status: str = None) -> Dict[str, Any]:
        """List ads for an account
        
        Args:
            account_id: Ad account ID
            limit: Maximum number of ads to return
            status: Filter by status (ACTIVE, PAUSED, ARCHIVED, etc.)
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot list ads.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/ads"
        
        params = {
            "fields": "id,name,adset_id,campaign_id,creative,status,created_time,updated_time",
            "limit": limit,
            "access_token": self.access_token
        }
        
        if status:
            params["filtering"] = json.dumps([{"field": "status", "operator": "EQUAL", "value": status}])
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing ads: {str(e)}")
            raise AppError(f"Error listing ads: {str(e)}")
    
    def create_bulk_ads(
        self, 
        account_id: str, 
        adset_id: str, 
        creatives: List[Dict[str, Any]],
        status: str = "PAUSED"
    ) -> List[Dict[str, Any]]:
        """Create multiple ads in bulk
        
        Args:
            account_id: Ad account ID
            adset_id: Ad set ID
            creatives: List of creative data
            status: Status of the ads (ACTIVE, PAUSED)
            
        Returns:
            List of responses from the API
        """
        results = []
        
        for creative_data in creatives:
            try:
                result = self.create_ad(
                    account_id=account_id,
                    adset_id=adset_id,
                    creative_data=creative_data,
                    status=status
                )
                results.append(result)
            except AppError as e:
                logger.error(f"Error creating ad with creative: {str(e)}")
                results.append({"error": str(e)})
        
        return results
    
    # Ad Preview
    
    def get_ad_preview(self, account_id: str, creative_id: str, ad_format: str = "DESKTOP_FEED_STANDARD") -> Dict[str, Any]:
        """Get a preview of an ad
        
        Args:
            account_id: Ad account ID
            creative_id: Creative ID
            ad_format: Format of the ad preview
            
        Returns:
            Response from the API containing the preview URL
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad preview.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/generatepreviews"
        
        params = {
            "creative": json.dumps({"creative_id": creative_id}),
            "ad_format": ad_format,
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad preview: {str(e)}")
            raise AppError(f"Error getting ad preview: {str(e)}")
    
    # Image Management
    
    def upload_image(self, account_id: str, image_path: str) -> Dict[str, Any]:
        """Upload an image to be used in ads
        
        Args:
            account_id: Ad account ID
            image_path: Path to the image file
            
        Returns:
            Response from the API containing the image hash
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot upload image.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adimages"
        
        try:
            with open(image_path, 'rb') as image_file:
                files = {'file': image_file}
                payload = {'access_token': self.access_token}
                response = requests.post(url, data=payload, files=files)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            logger.error(f"Error uploading image: {str(e)}")
            raise AppError(f"Error uploading image: {str(e)}")
    
    def get_image(self, image_hash: str) -> Dict[str, Any]:
        """Get an image
        
        Args:
            image_hash: Image hash
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get image.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/adimage"
        
        params = {
            "hash": image_hash,
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting image: {str(e)}")
            raise AppError(f"Error getting image: {str(e)}")
    
    def list_images(self, account_id: str, limit: int = 100) -> Dict[str, Any]:
        """List images for an account
        
        Args:
            account_id: Ad account ID
            limit: Maximum number of images to return
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot list images.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adimages"
        
        params = {
            "fields": "id,hash,url,width,height,name,status",
            "limit": limit,
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing images: {str(e)}")
            raise AppError(f"Error listing images: {str(e)}")
    
    # Campaign Management
    
    def create_campaign(
        self, 
        account_id: str, 
        name: str, 
        objective: str,
        status: str = "PAUSED",
        special_ad_categories: List[str] = None,
        spend_cap: int = None
    ) -> Dict[str, Any]:
        """Create a campaign
        
        Args:
            account_id: Ad account ID
            name: Campaign name
            objective: Campaign objective
            status: Campaign status (ACTIVE, PAUSED)
            special_ad_categories: Special ad categories
            spend_cap: Spend cap in cents
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot create campaign.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/campaigns"
        
        # Prepare the payload
        payload = {
            "name": name,
            "objective": objective,
            "status": status,
            "access_token": self.access_token
        }
        
        # Add special ad categories if provided
        if special_ad_categories:
            payload["special_ad_categories"] = json.dumps(special_ad_categories)
        
        # Add spend cap if provided
        if spend_cap:
            payload["spend_cap"] = spend_cap
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating campaign: {str(e)}")
            raise AppError(f"Error creating campaign: {str(e)}")
    
    def get_campaign(self, campaign_id: str) -> Dict[str, Any]:
        """Get a campaign
        
        Args:
            campaign_id: Campaign ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get campaign.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{campaign_id}"
        
        params = {
            "fields": "id,name,objective,status,special_ad_categories,spend_cap,created_time,updated_time",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting campaign: {str(e)}")
            raise AppError(f"Error getting campaign: {str(e)}")
    
    def update_campaign(self, campaign_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update a campaign
        
        Args:
            campaign_id: Campaign ID
            data: Data to update
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot update campaign.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{campaign_id}"
        
        # Add access token to data
        data["access_token"] = self.access_token
        
        try:
            response = requests.post(url, data=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error updating campaign: {str(e)}")
            raise AppError(f"Error updating campaign: {str(e)}")
    
    def delete_campaign(self, campaign_id: str) -> Dict[str, Any]:
        """Delete a campaign
        
        Args:
            campaign_id: Campaign ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot delete campaign.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{campaign_id}"
        
        params = {
            "access_token": self.access_token
        }
        
        try:
            response = requests.delete(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error deleting campaign: {str(e)}")
            raise AppError(f"Error deleting campaign: {str(e)}")
    
    def list_campaigns(self, account_id: str, limit: int = 100, status: str = None) -> Dict[str, Any]:
        """List campaigns for an account
        
        Args:
            account_id: Ad account ID
            limit: Maximum number of campaigns to return
            status: Filter by status (ACTIVE, PAUSED, ARCHIVED, etc.)
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot list campaigns.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/campaigns"
        
        params = {
            "fields": "id,name,objective,status,special_ad_categories,spend_cap,created_time,updated_time",
            "limit": limit,
            "access_token": self.access_token
        }
        
        if status:
            params["filtering"] = json.dumps([{"field": "status", "operator": "EQUAL", "value": status}])
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing campaigns: {str(e)}")
            raise AppError(f"Error listing campaigns: {str(e)}")
    
    # Ad Set Management
    
    def create_adset(
        self, 
        account_id: str, 
        campaign_id: str,
        name: str,
        optimization_goal: str,
        billing_event: str,
        bid_amount: int,
        daily_budget: int,
        targeting: Dict[str, Any],
        status: str = "PAUSED",
        start_time: str = None,
        end_time: str = None
    ) -> Dict[str, Any]:
        """Create an ad set
        
        Args:
            account_id: Ad account ID
            campaign_id: Campaign ID
            name: Ad set name
            optimization_goal: Optimization goal
            billing_event: Billing event
            bid_amount: Bid amount in cents
            daily_budget: Daily budget in cents
            targeting: Targeting specifications
            status: Ad set status (ACTIVE, PAUSED)
            start_time: Start time in ISO 8601 format
            end_time: End time in ISO 8601 format
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot create ad set.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adsets"
        
        # Prepare the payload
        payload = {
            "campaign_id": campaign_id,
            "name": name,
            "optimization_goal": optimization_goal,
            "billing_event": billing_event,
            "bid_amount": bid_amount,
            "daily_budget": daily_budget,
            "targeting": json.dumps(targeting),
            "status": status,
            "access_token": self.access_token
        }
        
        # Add start time if provided
        if start_time:
            payload["start_time"] = start_time
        
        # Add end time if provided
        if end_time:
            payload["end_time"] = end_time
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating ad set: {str(e)}")
            raise AppError(f"Error creating ad set: {str(e)}")
    
    def get_adset(self, adset_id: str) -> Dict[str, Any]:
        """Get an ad set
        
        Args:
            adset_id: Ad set ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad set.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{adset_id}"
        
        params = {
            "fields": "id,name,campaign_id,optimization_goal,billing_event,bid_amount,daily_budget,targeting,status,start_time,end_time,created_time,updated_time",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad set: {str(e)}")
            raise AppError(f"Error getting ad set: {str(e)}")
    
    def update_adset(self, adset_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an ad set
        
        Args:
            adset_id: Ad set ID
            data: Data to update
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot update ad set.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{adset_id}"
        
        # Add access token to data
        data["access_token"] = self.access_token
        
        try:
            response = requests.post(url, data=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error updating ad set: {str(e)}")
            raise AppError(f"Error updating ad set: {str(e)}")
    
    def delete_adset(self, adset_id: str) -> Dict[str, Any]:
        """Delete an ad set
        
        Args:
            adset_id: Ad set ID
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot delete ad set.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{adset_id}"
        
        params = {
            "access_token": self.access_token
        }
        
        try:
            response = requests.delete(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error deleting ad set: {str(e)}")
            raise AppError(f"Error deleting ad set: {str(e)}")
    
    def list_adsets(self, account_id: str, limit: int = 100, status: str = None) -> Dict[str, Any]:
        """List ad sets for an account
        
        Args:
            account_id: Ad account ID
            limit: Maximum number of ad sets to return
            status: Filter by status (ACTIVE, PAUSED, ARCHIVED, etc.)
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot list ad sets.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/adsets"
        
        params = {
            "fields": "id,name,campaign_id,optimization_goal,billing_event,bid_amount,daily_budget,status,start_time,end_time,created_time,updated_time",
            "limit": limit,
            "access_token": self.access_token
        }
        
        if status:
            params["filtering"] = json.dumps([{"field": "status", "operator": "EQUAL", "value": status}])
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error listing ad sets: {str(e)}")
            raise AppError(f"Error listing ad sets: {str(e)}")
    
    # Insights and Reporting
    
    def get_insights(
        self, 
        account_id: str, 
        level: str = "account",
        fields: List[str] = None,
        date_preset: str = "last_30d",
        time_range: Dict[str, str] = None,
        filtering: List[Dict[str, Any]] = None,
        breakdowns: List[str] = None,
        limit: int = 100
    ) -> Dict[str, Any]:
        """Get insights for an account, campaign, ad set, or ad
        
        Args:
            account_id: Ad account ID
            level: Level of insights (account, campaign, adset, ad)
            fields: Fields to include in the insights
            date_preset: Date preset (today, yesterday, last_3d, last_7d, last_30d, last_90d, this_month, last_month, this_quarter, lifetime)
            time_range: Custom time range with since and until dates in YYYY-MM-DD format
            filtering: Filtering specifications
            breakdowns: Breakdown specifications
            limit: Maximum number of insights to return
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get insights.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/act_{account_id}/insights"
        
        # Default fields if not provided
        if not fields:
            fields = [
                "account_id",
                "account_name",
                "campaign_id",
                "campaign_name",
                "adset_id",
                "adset_name",
                "ad_id",
                "ad_name",
                "impressions",
                "clicks",
                "ctr",
                "spend",
                "actions",
                "cost_per_action_type"
            ]
        
        params = {
            "level": level,
            "fields": ",".join(fields),
            "limit": limit,
            "access_token": self.access_token
        }
        
        # Add date preset or time range
        if time_range:
            params["time_range"] = json.dumps(time_range)
        else:
            params["date_preset"] = date_preset
        
        # Add filtering if provided
        if filtering:
            params["filtering"] = json.dumps(filtering)
        
        # Add breakdowns if provided
        if breakdowns:
            params["breakdowns"] = ",".join(breakdowns)
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting insights: {str(e)}")
            raise AppError(f"Error getting insights: {str(e)}")
    
    def get_ad_insights(
        self, 
        ad_id: str,
        fields: List[str] = None,
        date_preset: str = "last_30d",
        time_range: Dict[str, str] = None,
        breakdowns: List[str] = None
    ) -> Dict[str, Any]:
        """Get insights for a specific ad
        
        Args:
            ad_id: Ad ID
            fields: Fields to include in the insights
            date_preset: Date preset (today, yesterday, last_3d, last_7d, last_30d, last_90d, this_month, last_month, this_quarter, lifetime)
            time_range: Custom time range with since and until dates in YYYY-MM-DD format
            breakdowns: Breakdown specifications
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad insights.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{ad_id}/insights"
        
        # Default fields if not provided
        if not fields:
            fields = [
                "impressions",
                "clicks",
                "ctr",
                "spend",
                "actions",
                "cost_per_action_type"
            ]
        
        params = {
            "fields": ",".join(fields),
            "access_token": self.access_token
        }
        
        # Add date preset or time range
        if time_range:
            params["time_range"] = json.dumps(time_range)
        else:
            params["date_preset"] = date_preset
        
        # Add breakdowns if provided
        if breakdowns:
            params["breakdowns"] = ",".join(breakdowns)
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad insights: {str(e)}")
            raise AppError(f"Error getting ad insights: {str(e)}")
    
    # Batch Operations
    
    def batch_request(self, batch_requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make a batch request to the Meta Ads API
        
        Args:
            batch_requests: List of batch request specifications
            
        Returns:
            List of responses from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot make batch request.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/"
        
        payload = {
            "batch": json.dumps(batch_requests),
            "access_token": self.access_token
        }
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error making batch request: {str(e)}")
            raise AppError(f"Error making batch request: {str(e)}")
    
    def create_batch_ads(
        self, 
        account_id: str, 
        adset_id: str, 
        ads_data: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Create multiple ads in a single batch request
        
        Args:
            account_id: Ad account ID
            adset_id: Ad set ID
            ads_data: List of ad data
            
        Returns:
            List of responses from the API
        """
        batch_requests = []
        
        for i, ad_data in enumerate(ads_data):
            # Prepare the ad data
            ad_data["adset_id"] = adset_id
            
            # Create the batch request
            batch_request = {
                "method": "POST",
                "relative_url": f"act_{account_id}/ads",
                "body": "&".join([f"{key}={value}" for key, value in ad_data.items()]),
                "name": f"ad_{i}"
            }
            
            batch_requests.append(batch_request)
        
        # Make the batch request
        return self.batch_request(batch_requests)

