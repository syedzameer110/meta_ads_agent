"""
OpenAI Service for generating ad content
"""

import os
import json
import openai
from typing import Dict, List, Any, Optional

from app.utils.logger import get_logger
from app.utils.error_handler import AppError
from app.models.ad_content import AdHeadline, AdPrimaryText, AdDescription

logger = get_logger(__name__)

class OpenAIService:
    """Service for generating ad content using OpenAI"""
    
    def __init__(self, api_key: str = None, model: str = "gpt-4o"):
        """Initialize the OpenAI service
        
        Args:
            api_key: OpenAI API key. If None, will try to get from environment variable.
            model: OpenAI model to use
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("OpenAI API key not provided. Some features may not work.")
        else:
            openai.api_key = self.api_key
        
        self.model = model
        
        # Define platform specifications
        self.platform_specs = {
            "facebook": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            },
            "instagram": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            },
            "meta": {
                "headline": {"min": 1, "max": 40, "recommended": 25},
                "primary_text": {"min": 1, "max": 125, "recommended": 90},
                "description": {"min": 1, "max": 30, "recommended": 20}
            }
        }
        
        # Define tone descriptions
        self.tone_descriptions = {
            "persuasive": "Convincing and compelling tone to drive action",
            "witty": "Clever and humorous tone to engage and entertain",
            "professional": "Formal and business-like tone for corporate audiences",
            "friendly": "Warm and approachable tone to build rapport",
            "urgent": "Creates a sense of urgency and FOMO (fear of missing out)"
        }
    
    def generate_headlines(
        self, 
        project_data: Dict[str, Any], 
        tone: str = "persuasive",
        platform: str = "facebook",
        num_variations: int = 3
    ) -> Dict[str, Any]:
        """Generate ad headlines
        
        Args:
            project_data: Project data containing information about the product/service
            tone: Tone of the headlines
            platform: Platform for the headlines
            num_variations: Number of headline variations to generate
            
        Returns:
            Dictionary containing the generated headlines
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate headlines.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        headline_spec = platform_spec["headline"]
        
        # Get tone description
        tone_description = self.tone_descriptions.get(tone, self.tone_descriptions["persuasive"])
        
        # Prepare the prompt
        prompt = f"""
        Generate {num_variations} compelling ad headlines for a {platform} ad with the following specifications:
        - Maximum length: {headline_spec['recommended']} characters (absolute max: {headline_spec['max']} characters)
        - Tone: {tone} ({tone_description})
        
        Product/Service Information:
        {json.dumps(project_data, indent=2)}
        
        Guidelines:
        - Headlines should be attention-grabbing and relevant to the target audience
        - Each headline should be unique and different from the others
        - Focus on benefits, not features
        - Include a clear value proposition
        - Use action-oriented language when appropriate
        - Keep headlines concise and impactful
        - Avoid clickbait or misleading claims
        
        Format your response as a JSON array of strings, with each string being a headline.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in creating high-converting ad headlines for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            headlines_data = json.loads(content)
            
            # Validate and format headlines
            headlines = []
            for headline_text in headlines_data.get("headlines", []):
                try:
                    headline = AdHeadline(headline_text)
                    headlines.append({
                        "text": headline.text,
                        "character_count": headline.character_count,
                        "within_recommended_length": headline.within_recommended_length(platform),
                        "within_max_length": headline.within_max_length(platform)
                    })
                except Exception as e:
                    logger.error(f"Error validating headline: {str(e)}")
            
            return {
                "headlines": headlines,
                "platform": platform,
                "tone": tone,
                "specifications": headline_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating headlines: {str(e)}")
            raise AppError(f"Error generating headlines: {str(e)}")
    
    def generate_primary_text(
        self, 
        project_data: Dict[str, Any], 
        tone: str = "persuasive",
        platform: str = "facebook",
        num_variations: int = 3
    ) -> Dict[str, Any]:
        """Generate ad primary text
        
        Args:
            project_data: Project data containing information about the product/service
            tone: Tone of the primary text
            platform: Platform for the primary text
            num_variations: Number of primary text variations to generate
            
        Returns:
            Dictionary containing the generated primary text
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate primary text.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        primary_text_spec = platform_spec["primary_text"]
        
        # Get tone description
        tone_description = self.tone_descriptions.get(tone, self.tone_descriptions["persuasive"])
        
        # Prepare the prompt
        prompt = f"""
        Generate {num_variations} compelling ad primary text blocks for a {platform} ad with the following specifications:
        - Recommended length: {primary_text_spec['recommended']} characters (text beyond {primary_text_spec['max']} characters will be truncated with "See more")
        - Tone: {tone} ({tone_description})
        
        Product/Service Information:
        {json.dumps(project_data, indent=2)}
        
        Guidelines:
        - Primary text should expand on the headline and provide more details
        - Each text block should be unique and different from the others
        - Focus on benefits, not features
        - Include a clear call to action
        - Use conversational language that resonates with the target audience
        - Address pain points and provide solutions
        - Avoid excessive use of emojis, all caps, or exclamation points
        
        Format your response as a JSON array of strings, with each string being a primary text block.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in creating high-converting ad copy for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            primary_texts_data = json.loads(content)
            
            # Validate and format primary texts
            primary_texts = []
            for primary_text in primary_texts_data.get("primary_texts", []):
                try:
                    ad_primary_text = AdPrimaryText(primary_text)
                    primary_texts.append({
                        "text": ad_primary_text.text,
                        "character_count": ad_primary_text.character_count,
                        "within_recommended_length": ad_primary_text.within_recommended_length(platform),
                        "within_max_length": ad_primary_text.within_max_length(platform)
                    })
                except Exception as e:
                    logger.error(f"Error validating primary text: {str(e)}")
            
            return {
                "primary_texts": primary_texts,
                "platform": platform,
                "tone": tone,
                "specifications": primary_text_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating primary text: {str(e)}")
            raise AppError(f"Error generating primary text: {str(e)}")
    
    def generate_descriptions(
        self, 
        project_data: Dict[str, Any], 
        tone: str = "persuasive",
        platform: str = "facebook",
        num_variations: int = 3
    ) -> Dict[str, Any]:
        """Generate ad descriptions
        
        Args:
            project_data: Project data containing information about the product/service
            tone: Tone of the descriptions
            platform: Platform for the descriptions
            num_variations: Number of description variations to generate
            
        Returns:
            Dictionary containing the generated descriptions
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate descriptions.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        description_spec = platform_spec["description"]
        
        # Get tone description
        tone_description = self.tone_descriptions.get(tone, self.tone_descriptions["persuasive"])
        
        # Prepare the prompt
        prompt = f"""
        Generate {num_variations} compelling ad descriptions for a {platform} ad with the following specifications:
        - Maximum length: {description_spec['recommended']} characters (absolute max: {description_spec['max']} characters)
        - Tone: {tone} ({tone_description})
        
        Product/Service Information:
        {json.dumps(project_data, indent=2)}
        
        Guidelines:
        - Descriptions should be short and complement the headline and primary text
        - Each description should be unique and different from the others
        - Focus on a key benefit or feature
        - Use concise, impactful language
        - Avoid repeating information from the headline
        
        Format your response as a JSON array of strings, with each string being a description.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in creating high-converting ad descriptions for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            descriptions_data = json.loads(content)
            
            # Validate and format descriptions
            descriptions = []
            for description_text in descriptions_data.get("descriptions", []):
                try:
                    description = AdDescription(description_text)
                    descriptions.append({
                        "text": description.text,
                        "character_count": description.character_count,
                        "within_recommended_length": description.within_recommended_length(platform),
                        "within_max_length": description.within_max_length(platform)
                    })
                except Exception as e:
                    logger.error(f"Error validating description: {str(e)}")
            
            return {
                "descriptions": descriptions,
                "platform": platform,
                "tone": tone,
                "specifications": description_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating descriptions: {str(e)}")
            raise AppError(f"Error generating descriptions: {str(e)}")
    
    def generate_ad_content(
        self, 
        project_data: Dict[str, Any], 
        tone: str = "persuasive",
        platform: str = "facebook",
        num_variations: int = 3
    ) -> Dict[str, Any]:
        """Generate complete ad content (headlines, primary text, and descriptions)
        
        Args:
            project_data: Project data containing information about the product/service
            tone: Tone of the ad content
            platform: Platform for the ad content
            num_variations: Number of content variations to generate
            
        Returns:
            Dictionary containing the generated ad content
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate ad content.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        
        # Get tone description
        tone_description = self.tone_descriptions.get(tone, self.tone_descriptions["persuasive"])
        
        # Prepare the prompt
        prompt = f"""
        Generate {num_variations} complete ad content sets for a {platform} ad with the following specifications:
        - Headline: Maximum {platform_spec['headline']['recommended']} characters (absolute max: {platform_spec['headline']['max']})
        - Primary Text: Recommended {platform_spec['primary_text']['recommended']} characters (text beyond {platform_spec['primary_text']['max']} will be truncated with "See more")
        - Description: Maximum {platform_spec['description']['recommended']} characters (absolute max: {platform_spec['description']['max']})
        - Tone: {tone} ({tone_description})
        
        Product/Service Information:
        {json.dumps(project_data, indent=2)}
        
        Guidelines:
        - Each content set should include a headline, primary text, and description that work together
        - Each set should be unique and different from the others
        - Focus on benefits, not features
        - Include a clear call to action
        - Use language that resonates with the target audience
        - Ensure all components complement each other and tell a cohesive story
        
        Format your response as a JSON array of objects, with each object containing "headline", "primary_text", and "description" fields.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in creating high-converting ad content for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            content_sets_data = json.loads(content)
            
            # Validate and format content sets
            content_sets = []
            for content_set in content_sets_data.get("content_sets", []):
                try:
                    headline = AdHeadline(content_set.get("headline", ""))
                    primary_text = AdPrimaryText(content_set.get("primary_text", ""))
                    description = AdDescription(content_set.get("description", ""))
                    
                    content_sets.append({
                        "headline": {
                            "text": headline.text,
                            "character_count": headline.character_count,
                            "within_recommended_length": headline.within_recommended_length(platform),
                            "within_max_length": headline.within_max_length(platform)
                        },
                        "primary_text": {
                            "text": primary_text.text,
                            "character_count": primary_text.character_count,
                            "within_recommended_length": primary_text.within_recommended_length(platform),
                            "within_max_length": primary_text.within_max_length(platform)
                        },
                        "description": {
                            "text": description.text,
                            "character_count": description.character_count,
                            "within_recommended_length": description.within_recommended_length(platform),
                            "within_max_length": description.within_max_length(platform)
                        }
                    })
                except Exception as e:
                    logger.error(f"Error validating content set: {str(e)}")
            
            return {
                "content_sets": content_sets,
                "platform": platform,
                "tone": tone,
                "specifications": platform_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating ad content: {str(e)}")
            raise AppError(f"Error generating ad content: {str(e)}")
    
    def optimize_ad_content(
        self, 
        content: str,
        content_type: str,
        platform: str = "facebook"
    ) -> Dict[str, Any]:
        """Optimize ad content based on Meta best practices
        
        Args:
            content: Content to optimize
            content_type: Type of content (headline, primary_text, description)
            platform: Platform for the content
            
        Returns:
            Dictionary containing the optimized content
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot optimize ad content.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        content_spec = platform_spec.get(content_type, {"max": 125, "recommended": 90})
        
        # Prepare the prompt
        prompt = f"""
        Optimize the following {content_type} for a {platform} ad based on Meta best practices:
        
        Original {content_type}: {content}
        
        Guidelines:
        - Maximum recommended length: {content_spec['recommended']} characters
        - Absolute maximum length: {content_spec['max']} characters
        - Maintain the original message and tone
        - Make the content more compelling and action-oriented
        - Improve clarity and conciseness
        - Ensure it follows Meta's best practices for high-performing ads
        
        Format your response as a JSON object with "original" and "optimized" fields.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in optimizing ad content for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content_response = response.choices[0].message.content
            optimized_data = json.loads(content_response)
            
            # Validate and format optimized content
            optimized_content = optimized_data.get("optimized", "")
            
            if content_type == "headline":
                content_obj = AdHeadline(optimized_content)
            elif content_type == "primary_text":
                content_obj = AdPrimaryText(optimized_content)
            elif content_type == "description":
                content_obj = AdDescription(optimized_content)
            else:
                raise AppError(f"Invalid content type: {content_type}")
            
            return {
                "original": content,
                "optimized": {
                    "text": content_obj.text,
                    "character_count": content_obj.character_count,
                    "within_recommended_length": content_obj.within_recommended_length(platform),
                    "within_max_length": content_obj.within_max_length(platform)
                },
                "content_type": content_type,
                "platform": platform,
                "specifications": content_spec
            }
        
        except Exception as e:
            logger.error(f"Error optimizing ad content: {str(e)}")
            raise AppError(f"Error optimizing ad content: {str(e)}")
    
    def generate_ad_variations(
        self, 
        headline: str,
        primary_text: str,
        description: str = None,
        num_variations: int = 3,
        platform: str = "facebook"
    ) -> Dict[str, Any]:
        """Generate variations of existing ad content
        
        Args:
            headline: Original headline
            primary_text: Original primary text
            description: Original description
            num_variations: Number of variations to generate
            platform: Platform for the ad content
            
        Returns:
            Dictionary containing the generated variations
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate ad variations.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        
        # Prepare the prompt
        prompt = f"""
        Generate {num_variations} variations of the following ad content for a {platform} ad:
        
        Original Headline: {headline}
        Original Primary Text: {primary_text}
        {"Original Description: " + description if description else ""}
        
        Guidelines:
        - Headline: Maximum {platform_spec['headline']['recommended']} characters (absolute max: {platform_spec['headline']['max']})
        - Primary Text: Recommended {platform_spec['primary_text']['recommended']} characters (text beyond {platform_spec['primary_text']['max']} will be truncated with "See more")
        - Description: Maximum {platform_spec['description']['recommended']} characters (absolute max: {platform_spec['description']['max']})
        - Each variation should maintain the original message but use different wording
        - Each variation should be unique and different from the others
        - Preserve the tone and style of the original content
        - Ensure all components complement each other and tell a cohesive story
        
        Format your response as a JSON array of objects, with each object containing "headline", "primary_text", and "description" fields.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in creating variations of ad content for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            variations_data = json.loads(content)
            
            # Validate and format variations
            variations = []
            for variation in variations_data.get("variations", []):
                try:
                    headline_obj = AdHeadline(variation.get("headline", ""))
                    primary_text_obj = AdPrimaryText(variation.get("primary_text", ""))
                    
                    variation_data = {
                        "headline": {
                            "text": headline_obj.text,
                            "character_count": headline_obj.character_count,
                            "within_recommended_length": headline_obj.within_recommended_length(platform),
                            "within_max_length": headline_obj.within_max_length(platform)
                        },
                        "primary_text": {
                            "text": primary_text_obj.text,
                            "character_count": primary_text_obj.character_count,
                            "within_recommended_length": primary_text_obj.within_recommended_length(platform),
                            "within_max_length": primary_text_obj.within_max_length(platform)
                        }
                    }
                    
                    if description:
                        description_obj = AdDescription(variation.get("description", ""))
                        variation_data["description"] = {
                            "text": description_obj.text,
                            "character_count": description_obj.character_count,
                            "within_recommended_length": description_obj.within_recommended_length(platform),
                            "within_max_length": description_obj.within_max_length(platform)
                        }
                    
                    variations.append(variation_data)
                except Exception as e:
                    logger.error(f"Error validating variation: {str(e)}")
            
            return {
                "original": {
                    "headline": headline,
                    "primary_text": primary_text,
                    "description": description
                },
                "variations": variations,
                "platform": platform,
                "specifications": platform_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating ad variations: {str(e)}")
            raise AppError(f"Error generating ad variations: {str(e)}")
    
    def analyze_ad_performance(
        self, 
        ad_content: Dict[str, Any],
        performance_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze ad performance and provide recommendations
        
        Args:
            ad_content: Ad content (headline, primary_text, description)
            performance_data: Performance data for the ad
            
        Returns:
            Dictionary containing the analysis and recommendations
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot analyze ad performance.")
            raise AppError("API key not provided")
        
        # Prepare the prompt
        prompt = f"""
        Analyze the performance of the following ad content based on the provided performance data:
        
        Ad Content:
        {json.dumps(ad_content, indent=2)}
        
        Performance Data:
        {json.dumps(performance_data, indent=2)}
        
        Guidelines:
        - Identify strengths and weaknesses in the ad content
        - Analyze how the content may be affecting performance metrics
        - Provide specific recommendations for improving the ad content
        - Suggest A/B testing ideas
        - Consider the target audience and platform
        
        Format your response as a JSON object with "analysis", "recommendations", and "testing_ideas" fields.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad performance analyst specializing in Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            analysis_data = json.loads(content)
            
            return {
                "ad_content": ad_content,
                "performance_data": performance_data,
                "analysis": analysis_data.get("analysis", ""),
                "recommendations": analysis_data.get("recommendations", []),
                "testing_ideas": analysis_data.get("testing_ideas", [])
            }
        
        except Exception as e:
            logger.error(f"Error analyzing ad performance: {str(e)}")
            raise AppError(f"Error analyzing ad performance: {str(e)}")
    
    def generate_ad_copy_from_template(
        self, 
        template: str,
        variables: Dict[str, Any],
        platform: str = "facebook"
    ) -> Dict[str, Any]:
        """Generate ad copy from a template
        
        Args:
            template: Template with placeholders
            variables: Variables to replace placeholders
            platform: Platform for the ad content
            
        Returns:
            Dictionary containing the generated ad copy
        """
        if not self.api_key:
            logger.error("OpenAI API key not provided. Cannot generate ad copy from template.")
            raise AppError("API key not provided")
        
        # Get platform specifications
        platform_spec = self.platform_specs.get(platform, self.platform_specs["facebook"])
        
        # Prepare the prompt
        prompt = f"""
        Generate ad copy from the following template by replacing placeholders with the provided variables:
        
        Template:
        {template}
        
        Variables:
        {json.dumps(variables, indent=2)}
        
        Guidelines:
        - Replace all placeholders in the template with the corresponding variables
        - Ensure the generated copy follows Meta's best practices
        - Headline: Maximum {platform_spec['headline']['recommended']} characters (absolute max: {platform_spec['headline']['max']})
        - Primary Text: Recommended {platform_spec['primary_text']['recommended']} characters (text beyond {platform_spec['primary_text']['max']} will be truncated with "See more")
        - Description: Maximum {platform_spec['description']['recommended']} characters (absolute max: {platform_spec['description']['max']})
        - Make adjustments as needed to ensure the copy is compelling and effective
        
        Format your response as a JSON object with "headline", "primary_text", and "description" fields.
        """
        
        try:
            # Call OpenAI API
            response = openai.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ad copywriter specializing in generating ad copy from templates for Meta platforms."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            content = response.choices[0].message.content
            copy_data = json.loads(content)
            
            # Validate and format copy
            headline = AdHeadline(copy_data.get("headline", ""))
            primary_text = AdPrimaryText(copy_data.get("primary_text", ""))
            description = AdDescription(copy_data.get("description", ""))
            
            return {
                "template": template,
                "variables": variables,
                "generated_copy": {
                    "headline": {
                        "text": headline.text,
                        "character_count": headline.character_count,
                        "within_recommended_length": headline.within_recommended_length(platform),
                        "within_max_length": headline.within_max_length(platform)
                    },
                    "primary_text": {
                        "text": primary_text.text,
                        "character_count": primary_text.character_count,
                        "within_recommended_length": primary_text.within_recommended_length(platform),
                        "within_max_length": primary_text.within_max_length(platform)
                    },
                    "description": {
                        "text": description.text,
                        "character_count": description.character_count,
                        "within_recommended_length": description.within_recommended_length(platform),
                        "within_max_length": description.within_max_length(platform)
                    }
                },
                "platform": platform,
                "specifications": platform_spec
            }
        
        except Exception as e:
            logger.error(f"Error generating ad copy from template: {str(e)}")
            raise AppError(f"Error generating ad copy from template: {str(e)}")

