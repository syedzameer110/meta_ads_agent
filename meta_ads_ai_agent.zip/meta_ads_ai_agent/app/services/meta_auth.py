"""
Meta Ads Authentication Service
"""

import os
import json
import requests
from typing import Dict, List, Any, Optional

from app.utils.logger import get_logger
from app.utils.error_handler import AppError
from config.config import config

logger = get_logger(__name__)

class MetaAuthService:
    """Service for authenticating with Meta Ads Marketing API"""
    
    def __init__(self, access_token: str = None, api_version: str = "v23.0"):
        """Initialize the Meta Auth service
        
        Args:
            access_token: Meta Ads API access token. If None, will try to get from environment variable.
            api_version: Meta Ads API version
        """
        self.access_token = access_token or os.environ.get("META_ACCESS_TOKEN") or config["api"].META_ACCESS_TOKEN
        self.api_version = api_version
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
        
        if not self.access_token:
            logger.warning("Meta Ads API access token not provided. Some features may not work.")
    
    def validate_token(self) -> Dict[str, Any]:
        """Validate the access token
        
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot validate token.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/debug_token"
        
        params = {
            "input_token": self.access_token,
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error validating token: {str(e)}")
            raise AppError(f"Error validating token: {str(e)}")
    
    def get_user_accounts(self) -> Dict[str, Any]:
        """Get user accounts
        
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get user accounts.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/me"
        
        params = {
            "fields": "id,name,accounts{id,name,business}",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting user accounts: {str(e)}")
            raise AppError(f"Error getting user accounts: {str(e)}")
    
    def get_ad_accounts(self) -> Dict[str, Any]:
        """Get ad accounts
        
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get ad accounts.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/me/adaccounts"
        
        params = {
            "fields": "id,name,account_id,account_status,business_name,currency,timezone_name",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting ad accounts: {str(e)}")
            raise AppError(f"Error getting ad accounts: {str(e)}")
    
    def get_pages(self) -> Dict[str, Any]:
        """Get Facebook pages
        
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get pages.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/me/accounts"
        
        params = {
            "fields": "id,name,access_token,category,fan_count,picture",
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting pages: {str(e)}")
            raise AppError(f"Error getting pages: {str(e)}")
    
    def get_permissions(self) -> Dict[str, Any]:
        """Get permissions for the current access token
        
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get permissions.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/me/permissions"
        
        params = {
            "access_token": self.access_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting permissions: {str(e)}")
            raise AppError(f"Error getting permissions: {str(e)}")
    
    def check_required_permissions(self, required_permissions: List[str]) -> Dict[str, Any]:
        """Check if the current access token has the required permissions
        
        Args:
            required_permissions: List of required permissions
            
        Returns:
            Dictionary containing the check results
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot check permissions.")
            raise AppError("API token not provided")
        
        if not required_permissions:
            return {"has_all_permissions": True, "missing_permissions": []}
        
        # Get current permissions
        permissions_response = self.get_permissions()
        current_permissions = {
            perm["permission"]: perm["status"] == "granted"
            for perm in permissions_response.get("data", [])
        }
        
        # Check required permissions
        missing_permissions = [
            perm for perm in required_permissions
            if not current_permissions.get(perm, False)
        ]
        
        return {
            "has_all_permissions": len(missing_permissions) == 0,
            "missing_permissions": missing_permissions,
            "current_permissions": current_permissions
        }
    
    def get_long_lived_token(self, app_id: str, app_secret: str, short_lived_token: str) -> Dict[str, Any]:
        """Exchange a short-lived token for a long-lived token
        
        Args:
            app_id: Meta App ID
            app_secret: Meta App Secret
            short_lived_token: Short-lived access token
            
        Returns:
            Response from the API
        """
        url = f"{self.base_url}/oauth/access_token"
        
        params = {
            "grant_type": "fb_exchange_token",
            "client_id": app_id,
            "client_secret": app_secret,
            "fb_exchange_token": short_lived_token
        }
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting long-lived token: {str(e)}")
            raise AppError(f"Error getting long-lived token: {str(e)}")
    
    def get_system_user_token(self, business_id: str, system_user_id: str, app_id: str, app_secret: str) -> Dict[str, Any]:
        """Get a system user token
        
        Args:
            business_id: Meta Business ID
            system_user_id: System User ID
            app_id: Meta App ID
            app_secret: Meta App Secret
            
        Returns:
            Response from the API
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get system user token.")
            raise AppError("API token not provided")
        
        url = f"{self.base_url}/{business_id}/access_token"
        
        params = {
            "access_token": self.access_token,
            "app_id": app_id,
            "app_secret": app_secret,
            "scope": "ads_management,business_management",
            "system_user_id": system_user_id
        }
        
        try:
            response = requests.post(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting system user token: {str(e)}")
            raise AppError(f"Error getting system user token: {str(e)}")
    
    def get_token_info(self) -> Dict[str, Any]:
        """Get information about the current access token
        
        Returns:
            Dictionary containing token information
        """
        if not self.access_token:
            logger.error("Meta Ads API access token not provided. Cannot get token info.")
            raise AppError("API token not provided")
        
        # Validate token
        token_info = self.validate_token()
        
        # Get user info
        user_info = self.get_user_accounts()
        
        # Get permissions
        permissions = self.get_permissions()
        
        return {
            "token_info": token_info,
            "user_info": user_info,
            "permissions": permissions
        }

