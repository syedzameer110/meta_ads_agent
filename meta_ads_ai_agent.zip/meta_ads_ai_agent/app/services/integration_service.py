"""
Integration Service for connecting with external tools
"""

import os
import csv
import json
import requests
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from pyairtable import Table
from typing import Dict, List, Any, Optional
from werkzeug.datastructures import FileStorage

from app.utils.logger import get_logger
from app.utils.error_handler import AppError
from app.services.openai_service import OpenAIService
from app.services.meta_ads_service import MetaAdsService
from config.config import config

logger = get_logger(__name__)

class IntegrationService:
    """Service for integrating with external tools"""
    
    def __init__(self):
        """Initialize the Integration service"""
        self.openai_service = OpenAIService()
        self.meta_ads_service = MetaAdsService()
    
    # Google Sheets integration
    
    def read_google_sheets(
        self, 
        credentials: Dict[str, Any], 
        spreadsheet_key: str, 
        worksheet_name: str = None, 
        range_name: str = None
    ) -> List[Dict[str, Any]]:
        """Read data from Google Sheets
        
        Args:
            credentials: Google service account credentials
            spreadsheet_key: Google Sheets spreadsheet key
            worksheet_name: Name of the worksheet to read from (defaults to first worksheet)
            range_name: Range to read from (e.g., "A1:C10")
            
        Returns:
            List of dictionaries representing the rows
        """
        try:
            # Authenticate with Google Sheets
            scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
            creds = ServiceAccountCredentials.from_json_keyfile_dict(credentials, scope)
            client = gspread.authorize(creds)
            
            # Open the spreadsheet
            spreadsheet = client.open_by_key(spreadsheet_key)
            
            # Select the worksheet
            if worksheet_name:
                worksheet = spreadsheet.worksheet(worksheet_name)
            else:
                worksheet = spreadsheet.get_worksheet(0)
            
            # Read data
            if range_name:
                data = worksheet.get(range_name)
            else:
                data = worksheet.get_all_records()
            
            return data
        
        except Exception as e:
            logger.error(f"Error reading from Google Sheets: {str(e)}")
            raise AppError(f"Error reading from Google Sheets: {str(e)}")
    
    def write_google_sheets(
        self, 
        credentials: Dict[str, Any], 
        spreadsheet_key: str, 
        data: List[Dict[str, Any]], 
        worksheet_name: str = None, 
        range_name: str = None
    ) -> Dict[str, Any]:
        """Write data to Google Sheets
        
        Args:
            credentials: Google service account credentials
            spreadsheet_key: Google Sheets spreadsheet key
            data: List of dictionaries representing the rows to write
            worksheet_name: Name of the worksheet to write to (defaults to first worksheet)
            range_name: Range to write to (e.g., "A1")
            
        Returns:
            Response from the API
        """
        try:
            # Authenticate with Google Sheets
            scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
            creds = ServiceAccountCredentials.from_json_keyfile_dict(credentials, scope)
            client = gspread.authorize(creds)
            
            # Open the spreadsheet
            spreadsheet = client.open_by_key(spreadsheet_key)
            
            # Select the worksheet
            if worksheet_name:
                worksheet = spreadsheet.worksheet(worksheet_name)
            else:
                worksheet = spreadsheet.get_worksheet(0)
            
            # Prepare data for writing
            if not data:
                raise AppError("No data provided to write")
            
            header = list(data[0].keys())
            rows = [header] + [[row.get(col, "") for col in header] for row in data]
            
            # Write data
            if range_name:
                worksheet.update(range_name, rows)
            else:
                worksheet.clear()
                worksheet.update("A1", rows)
            
            return {"success": True, "message": "Data written to Google Sheets successfully"}
        
        except Exception as e:
            logger.error(f"Error writing to Google Sheets: {str(e)}")
            raise AppError(f"Error writing to Google Sheets: {str(e)}")
    
    # Airtable integration
    
    def read_airtable(
        self, 
        api_key: str, 
        base_id: str, 
        table_name: str, 
        formula: str = None, 
        max_records: int = None
    ) -> List[Dict[str, Any]]:
        """Read data from Airtable
        
        Args:
            api_key: Airtable API key
            base_id: Airtable base ID
            table_name: Airtable table name
            formula: Airtable formula to filter records
            max_records: Maximum number of records to return
            
        Returns:
            List of dictionaries representing the records
        """
        try:
            # Initialize Airtable table
            table = Table(api_key, base_id, table_name)
            
            # Read data
            records = table.all(formula=formula, max_records=max_records)
            
            # Format records
            data = [record["fields"] for record in records]
            
            return data
        
        except Exception as e:
            logger.error(f"Error reading from Airtable: {str(e)}")
            raise AppError(f"Error reading from Airtable: {str(e)}")
    
    def write_airtable(
        self, 
        api_key: str, 
        base_id: str, 
        table_name: str, 
        data: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Write data to Airtable
        
        Args:
            api_key: Airtable API key
            base_id: Airtable base ID
            table_name: Airtable table name
            data: List of dictionaries representing the records to write
            
        Returns:
            Response from the API
        """
        try:
            # Initialize Airtable table
            table = Table(api_key, base_id, table_name)
            
            # Write data
            response = table.batch_create(data)
            
            return {"success": True, "message": "Data written to Airtable successfully", "response": response}
        
        except Exception as e:
            logger.error(f"Error writing to Airtable: {str(e)}")
            raise AppError(f"Error writing to Airtable: {str(e)}")
    
    # n8n integration
    
    def trigger_n8n_webhook(
        self, 
        webhook_url: str, 
        data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Trigger an n8n webhook
        
        Args:
            webhook_url: URL of the n8n webhook
            data: Data to send to the webhook
            
        Returns:
            Response from the webhook
        """
        try:
            # Send request to n8n webhook
            response = requests.post(webhook_url, json=data)
            response.raise_for_status()
            
            return response.json()
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error triggering n8n webhook: {str(e)}")
            raise AppError(f"Error triggering n8n webhook: {str(e)}")
    
    # CSV import/export
    
    def import_csv(self, file: FileStorage) -> List[Dict[str, Any]]:
        """Import data from CSV file
        
        Args:
            file: FileStorage object representing the uploaded CSV file
            
        Returns:
            List of dictionaries representing the rows
        """
        try:
            # Read CSV file
            data = []
            stream = file.stream.read().decode("utf-8")
            reader = csv.DictReader(stream.splitlines())
            for row in reader:
                data.append(row)
            
            return data
        
        except Exception as e:
            logger.error(f"Error importing CSV: {str(e)}")
            raise AppError(f"Error importing CSV: {str(e)}")
    
    def export_csv(self, data: List[Dict[str, Any]], filename: str) -> Dict[str, Any]:
        """Export data to CSV file
        
        Args:
            data: List of dictionaries representing the rows to export
            filename: Name of the CSV file to create
            
        Returns:
            Dictionary containing the path to the exported CSV file
        """
        try:
            if not data:
                raise AppError("No data provided to export")
            
            # Prepare file path
            export_dir = os.path.join(config["app"].UPLOAD_FOLDER, "exports")
            os.makedirs(export_dir, exist_ok=True)
            filepath = os.path.join(export_dir, filename)
            
            # Write data to CSV
            header = list(data[0].keys())
            with open(filepath, "w", newline="", encoding="utf-8") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=header)
                writer.writeheader()
                writer.writerows(data)
            
            return {"success": True, "filepath": filepath}
        
        except Exception as e:
            logger.error(f"Error exporting CSV: {str(e)}")
            raise AppError(f"Error exporting CSV: {str(e)}")
    
    # Bulk operations
    
    def process_bulk_data(
        self, 
        source_type: str, 
        source_data: Any, 
        operation: str, 
        options: Dict[str, Any] = {}
    ) -> Dict[str, Any]:
        """Process bulk data for ad creation or content generation
        
        Args:
            source_type: Type of data source (csv, google_sheets, airtable)
            source_data: Data source details (e.g., file path, spreadsheet key, base ID)
            operation: Operation to perform (generate_content, create_ads)
            options: Additional options for the operation
            
        Returns:
            Dictionary containing the results of the bulk operation
        """
        try:
            # Read data from source
            if source_type == "csv":
                data = self.import_csv(source_data)
            elif source_type == "google_sheets":
                data = self.read_google_sheets(**source_data)
            elif source_type == "airtable":
                data = self.read_airtable(**source_data)
            else:
                raise AppError(f"Invalid source type: {source_type}")
            
            # Perform operation
            results = []
            if operation == "generate_content":
                for row in data:
                    try:
                        result = self.openai_service.generate_ad_content(
                            project_data=row,
                            tone=options.get("tone", "persuasive"),
                            platform=options.get("platform", "facebook"),
                            num_variations=options.get("num_variations", 1)
                        )
                        results.append({"input": row, "output": result, "status": "success"})
                    except Exception as e:
                        logger.error(f"Error generating content for row: {str(e)}")
                        results.append({"input": row, "error": str(e), "status": "error"})
            
            elif operation == "create_ads":
                account_id = options.get("account_id")
                adset_id = options.get("adset_id")
                status = options.get("status", "PAUSED")
                
                if not account_id or not adset_id:
                    raise AppError("Missing account_id or adset_id in options")
                
                # Prepare creatives for bulk creation
                creatives_to_create = []
                for row in data:
                    try:
                        # Assuming CSV/Sheet/Table has columns: headline, primary_text, link, image_hash, page_id
                        creative_data = {
                            "page_id": row.get("page_id"),
                            "image_hash": row.get("image_hash"),
                            "headline": row.get("headline"),
                            "primary_text": row.get("primary_text"),
                            "link": row.get("link"),
                            "name": row.get("name", f"Ad for {row.get("headline", "")[:20]}..."),
                            "description": row.get("description"),
                            "call_to_action_type": row.get("call_to_action_type", "LEARN_MORE")
                        }
                        
                        # Validate required fields for creative
                        if not all([creative_data["page_id"], creative_data["image_hash"], creative_data["headline"], creative_data["primary_text"], creative_data["link"]]):
                            raise ValueError("Missing required fields for creative")
                        
                        creatives_to_create.append(creative_data)
                    except Exception as e:
                        logger.error(f"Error preparing creative for row: {str(e)}")
                        results.append({"input": row, "error": str(e), "status": "error"})
                
                # Create ads in bulk
                if creatives_to_create:
                    try:
                        bulk_result = self.meta_ads_service.create_bulk_ads(
                            account_id=account_id,
                            adset_id=adset_id,
                            creatives=creatives_to_create,
                            status=status
                        )
                        # Need to correlate results back to input rows if possible
                        # For now, just return the overall bulk result
                        results.append({"input": "bulk_creation", "output": bulk_result, "status": "success"})
                    except Exception as e:
                        logger.error(f"Error creating ads in bulk: {str(e)}")
                        results.append({"input": "bulk_creation", "error": str(e), "status": "error"})
            
            else:
                raise AppError(f"Invalid operation: {operation}")
            
            return {"results": results, "operation": operation, "source_type": source_type}
        
        except Exception as e:
            logger.error(f"Error processing bulk data: {str(e)}")
            raise AppError(f"Error processing bulk data: {str(e)}")

