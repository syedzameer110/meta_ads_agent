"""
Meta Ads AI Agent - Main Application
"""

import os
from flask import Flask, jsonify, request
from flask_cors import CORS

from app.utils.logger import get_logger
from app.utils.error_handler import api_error_handler, AppError
from config.config import config
from app.routes import register_routes

# Initialize logger
logger = get_logger(__name__)

# Create Flask application
app = Flask(__name__)
app.config['SECRET_KEY'] = config['app'].SECRET_KEY
app.config['DEBUG'] = config['app'].DEBUG

# Enable CORS
CORS(app)

# Import routes after app is created to avoid circular imports
from app.api import api_bp

# Register blueprints
app.register_blueprint(api_bp)

# Register web routes
register_routes(app)


@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "api_status": {
            "meta": bool(config['api'].META_ACCESS_TOKEN),
            "openai": bool(config['api'].OPENAI_API_KEY),
            "airtable": bool(config['api'].AIRTABLE_API_KEY),
            "google_sheets": bool(config['api'].GOOGLE_CREDENTIALS_FILE)
        }
    })


@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return jsonify({"error": "Resource not found"}), 404


@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    return jsonify({"error": "Internal server error"}), 500


if __name__ == '__main__':
    host = config['app'].HOST
    port = config['app'].PORT
    
    logger.info(f"Starting Meta Ads AI Agent on {host}:{port}")
    app.run(host=host, port=port)

