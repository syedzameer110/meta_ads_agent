# Meta Ads AI Agent - User Guide

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
   - [System Requirements](#system-requirements)
   - [Installation](#installation)
   - [Configuration](#configuration)
3. [Features](#features)
   - [Ad Content Generation](#ad-content-generation)
   - [Meta Ads Creation](#meta-ads-creation)
   - [Integrations](#integrations)
   - [Settings](#settings)
4. [Workflows](#workflows)
   - [Single Ad Creation](#single-ad-creation)
   - [Bulk Ad Creation](#bulk-ad-creation)
   - [A/B Testing](#ab-testing)
   - [Performance Reporting](#performance-reporting)
5. [Integrations](#integrations-1)
   - [Google Sheets](#google-sheets)
   - [Airtable](#airtable)
   - [n8n](#n8n)
   - [CSV Import/Export](#csv-importexport)
6. [Troubleshooting](#troubleshooting)
7. [FAQ](#faq)
8. [Support](#support)

## Introduction

Meta Ads AI Agent is a powerful tool designed to streamline the process of creating and managing Meta ads. It leverages artificial intelligence to generate compelling ad content and provides seamless integration with the Meta Ads Marketing API and various external tools.

### Key Benefits

- **Save Time**: Automate ad content generation and creation
- **Improve Performance**: Create high-quality, engaging ad content
- **Scale Easily**: Manage multiple campaigns and ads in bulk
- **Integrate Seamlessly**: Connect with your existing workflow tools

## Getting Started

### System Requirements

- Python 3.8 or higher
- Flask 2.0 or higher
- Internet connection for API access
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/meta-ads-ai-agent.git
   cd meta-ads-ai-agent
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the application:
   ```bash
   python app.py
   ```

5. Access the web interface at `http://localhost:5000`

### Configuration

Before using the Meta Ads AI Agent, you need to configure the following API keys:

1. **Meta Access Token**: Required for interacting with the Meta Ads Marketing API
2. **OpenAI API Key**: Required for AI-powered content generation
3. **Integration API Keys**: Optional, based on your integration needs

To configure these keys:

1. Go to the **Settings** page
2. Navigate to the **API Keys** tab
3. Enter your API keys in the respective fields
4. Click **Save API Keys**

## Features

### Ad Content Generation

The Ad Content Generation feature uses AI to create compelling ad headlines and primary text based on your product information and preferences.

#### How to Generate Ad Content

1. Go to the **Ad Content** page
2. Fill in the **Project Information** section:
   - Product/Service Name
   - Product/Service Description
   - Target Audience
   - Unique Selling Points
   - Call to Action
3. Configure **Generation Options**:
   - Tone (Professional, Friendly, Casual, etc.)
   - Platform (Facebook, Instagram, etc.)
   - Number of Variations
4. Click **Generate Ad Content**
5. Review the generated content
6. Click **Use This** on your preferred variation to use it in ad creation

### Meta Ads Creation

The Meta Ads Creation feature allows you to create ads on Meta platforms using your generated content or manually entered content.

#### How to Create a Single Ad

1. Go to the **Meta Ads** page
2. Fill in the **Campaign Details**:
   - Campaign Name
   - Campaign Objective
3. Fill in the **Ad Set Details**:
   - Ad Set Name
   - Daily Budget
   - Start Date
   - End Date (Optional)
   - Targeting
4. Fill in the **Ad Details**:
   - Ad Name
   - Facebook Page ID
   - Headline
   - Primary Text
   - Description (Optional)
   - Website URL
   - Call to Action
   - Ad Image
5. Review the **Ad Preview**
6. Click **Create Ad**

#### How to Create Bulk Ads

1. Go to the **Meta Ads** page
2. Click the **Bulk Ads** tab
3. Download the CSV template
4. Fill in the template with your ad details
5. Upload the completed CSV file
6. Click **Upload and Create**

### Integrations

The Integrations feature allows you to connect with external tools to enhance your workflow and automate ad creation.

#### Available Integrations

- **Google Sheets**: Import and export data to/from Google Sheets
- **Airtable**: Sync data with Airtable for collaborative workflow
- **n8n**: Trigger n8n workflows for complex automation
- **CSV Import/Export**: Import and export data using CSV files

### Settings

The Settings page allows you to configure the application and manage your API keys.

#### Available Settings

- **API Keys**: Configure Meta, OpenAI, and integration API keys
- **Preferences**: Set default values for ad content generation
- **System Info**: View system information and API status

## Workflows

### Single Ad Creation

1. Generate ad content using the Ad Content Generation feature
2. Select your preferred variation
3. Create a single ad using the Meta Ads Creation feature
4. Review and publish the ad

### Bulk Ad Creation

1. Download the bulk ads CSV template
2. Fill in the template with your ad details
3. Upload the completed CSV file
4. Review the results and fix any errors

### A/B Testing

1. Generate multiple ad content variations
2. Create ads using different variations
3. Use the same targeting and budget for all ads
4. Monitor performance and identify the winning variation

### Performance Reporting

1. Connect with Google Sheets or Airtable
2. Export performance data
3. Analyze the data to identify trends and insights
4. Make data-driven decisions for future campaigns

## Integrations

### Google Sheets

#### How to Connect

1. Go to the **Integrations** page
2. Click **Connect** under Google Sheets
3. Enter your Google Sheet ID
4. Select the action (Read, Write, Append)
5. Click **Connect**

#### Use Cases

- Import ad data from Google Sheets
- Export performance data to Google Sheets
- Collaborate with team members on ad content

### Airtable

#### How to Connect

1. Go to the **Integrations** page
2. Click **Connect** under Airtable
3. Enter your Base ID and Table Name
4. Select the action (Read Records, Create Records, Update Records)
5. Click **Connect**

#### Use Cases

- Store and organize ad content
- Track campaign performance
- Collaborate with team members

### n8n

#### How to Trigger a Webhook

1. Go to the **Integrations** page
2. Click **Trigger Webhook** under n8n
3. Enter your Webhook URL
4. Enter the payload in JSON format
5. Click **Trigger**

#### Use Cases

- Automate complex workflows
- Connect with other services
- Schedule ad creation and updates

### CSV Import/Export

#### How to Import CSV

1. Go to the **Integrations** page
2. Click **Import** under CSV Import/Export
3. Select your CSV file
4. Select the import type
5. Click **Import**

#### How to Export CSV

1. Go to the **Integrations** page
2. Click **Export** under CSV Import/Export
3. Select the export type
4. Select the date range
5. Click **Export**

#### Use Cases

- Bulk import ad data
- Export data for offline analysis
- Share data with team members

## Troubleshooting

### Common Issues

#### API Connection Errors

- **Issue**: Unable to connect to Meta Ads API
- **Solution**: Verify your access token is valid and has the necessary permissions

#### Content Generation Errors

- **Issue**: AI content generation fails
- **Solution**: Check your OpenAI API key and ensure you have sufficient credits

#### Integration Errors

- **Issue**: Unable to connect to Google Sheets
- **Solution**: Verify your credentials and ensure the sheet is accessible

### Error Messages

- **"Invalid access token"**: Your Meta access token is invalid or expired
- **"API rate limit exceeded"**: You've exceeded the rate limit for the API
- **"Invalid request"**: The request format is incorrect

## FAQ

### General Questions

**Q: How does the AI content generation work?**
A: The AI content generation uses OpenAI's GPT models to generate ad headlines and primary text based on your product information and preferences.

**Q: Can I use my own AI models?**
A: Currently, the system is designed to work with OpenAI's models. Custom model integration may be available in future updates.

**Q: Is my data secure?**
A: Yes, your data is securely transmitted and stored. We do not share your data with third parties.

### Technical Questions

**Q: What permissions does the Meta access token need?**
A: The token needs permissions for `ads_management`, `business_management`, and `pages_read_engagement`.

**Q: Can I run the application offline?**
A: The application requires internet access for API connections. Limited functionality may be available offline.

**Q: How can I backup my data?**
A: Use the CSV Export feature to export your data for backup purposes.

## Support

For additional support, please contact us at:

- **Email**: support@metaadsaiagent.com
- **Website**: https://www.metaadsaiagent.com/support
- **GitHub**: https://github.com/yourusername/meta-ads-ai-agent/issues

