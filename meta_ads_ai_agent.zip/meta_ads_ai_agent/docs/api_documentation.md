# Meta Ads AI Agent - API Documentation

## Table of Contents

1. [Introduction](#introduction)
2. [Authentication](#authentication)
3. [API Endpoints](#api-endpoints)
   - [Ad Content](#ad-content)
   - [Meta Ads](#meta-ads)
   - [Integrations](#integrations)
4. [Data Models](#data-models)
5. [Error Handling](#error-handling)
6. [Rate Limits](#rate-limits)
7. [Examples](#examples)

## Introduction

The Meta Ads AI Agent API provides programmatic access to all features of the Meta Ads AI Agent, including ad content generation, Meta ads creation, and integrations with external tools.

### Base URL

```
http://localhost:5000/api
```

### Response Format

All API responses are in JSON format and include a status code and a message. Successful responses include the requested data, while error responses include an error message.

Example success response:

```json
{
  "status": "success",
  "message": "Operation completed successfully",
  "data": {
    // Response data
  }
}
```

Example error response:

```json
{
  "status": "error",
  "message": "Invalid request parameters",
  "error": {
    "code": "INVALID_PARAMS",
    "details": "Missing required parameter: product_info"
  }
}
```

## Authentication

The API uses API key authentication. You need to include your API key in the request headers.

```
Authorization: Bearer YOUR_API_KEY
```

To obtain an API key, go to the Settings page in the web interface and generate a new API key.

## API Endpoints

### Ad Content

#### Generate Ad Content

Generates ad headlines and primary text using AI.

**Endpoint:** `POST /ad-content/generate`

**Request Body:**

```json
{
  "product_info": {
    "name": "Premium Fitness Tracker",
    "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
    "target_audience": "Health-conscious adults aged 25-45",
    "unique_selling_points": [
      "24/7 heart rate monitoring",
      "Water resistant up to 50m",
      "7-day battery life"
    ],
    "call_to_action": "Shop Now"
  },
  "tone": "professional",
  "platform": "facebook",
  "num_variations": 3
}
```

**Response:**

```json
{
  "status": "success",
  "message": "Ad content generated successfully",
  "variations": [
    {
      "headline": "Track Your Health 24/7 with Premium Fitness Tracker",
      "primary_text": "Stay on top of your fitness goals with our advanced tracker. Features 24/7 heart rate monitoring, water resistance up to 50m, and 7-day battery life. Perfect for health-conscious individuals who want to optimize their wellness journey."
    },
    {
      "headline": "Elevate Your Fitness Journey",
      "primary_text": "Introducing the Premium Fitness Tracker with 24/7 heart rate monitoring. Water resistant up to 50m and 7-day battery life. Don't miss out on achieving your health goals. Shop Now!"
    },
    {
      "headline": "Your Health Companion That Never Sleeps",
      "primary_text": "The Premium Fitness Tracker monitors your heart rate 24/7, tracks your sleep, and stays water resistant up to 50m. With 7-day battery life, it's always there when you need it. Shop Now and take control of your health."
    }
  ]
}
```

### Meta Ads

#### Create Ad

Creates a new ad on Meta platforms.

**Endpoint:** `POST /meta-ads/create-ad`

**Request Body (multipart/form-data):**

```
campaign_name: Summer Sale 2025
campaign_objective: CONVERSIONS
adset_name: US - Mobile - 25-34
daily_budget: 50.00
start_date: 2025-06-05
end_date: 2025-06-12
targeting: {"age_min":25,"age_max":34,"genders":[1,2],"geo_locations":{"countries":["US"]}}
ad_name: Summer Sale - Image 1
page_id: 123456789012345
headline: Summer Sale - Up to 50% Off
primary_text: Don't miss our biggest sale of the year! Limited time only.
description: Free shipping on all orders
website_url: https://www.example.com/summer-sale
call_to_action: SHOP_NOW
ad_image: [FILE]
```

**Response:**

```json
{
  "status": "success",
  "message": "Ad created successfully",
  "id": "23456789012345",
  "status": "ACTIVE",
  "preview_url": "https://www.facebook.com/ads/archive/render_ad/?id=23456789012345"
}
```

#### Create Bulk Ads

Creates multiple ads from a CSV file.

**Endpoint:** `POST /meta-ads/create-bulk`

**Request Body (multipart/form-data):**

```
bulk_file: [CSV FILE]
```

**Response:**

```json
{
  "status": "success",
  "message": "Bulk ads created successfully",
  "total_count": 5,
  "success_count": 4,
  "failed_count": 1,
  "errors": [
    {
      "row": 3,
      "error": "Invalid page ID"
    }
  ]
}
```

### Integrations

#### Google Sheets - Read

Reads data from a Google Sheet.

**Endpoint:** `POST /integrations/google-sheets/read`

**Request Body:**

```json
{
  "sheet_id": "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms",
  "sheet_range": "Sheet1!A1:Z100"
}
```

**Response:**

```json
{
  "status": "success",
  "message": "Data read successfully",
  "rows": [
    {
      "campaign_name": "Summer Sale",
      "adset_name": "US - Mobile",
      "ad_name": "Summer Sale - Image 1",
      "headline": "Summer Sale - Up to 50% Off",
      "primary_text": "Don't miss our biggest sale of the year! Limited time only."
    },
    // More rows...
  ]
}
```

#### Google Sheets - Write

Writes data to a Google Sheet.

**Endpoint:** `POST /integrations/google-sheets/write`

**Request Body:**

```json
{
  "sheet_id": "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms",
  "sheet_range": "Sheet1!A1",
  "data": [
    ["campaign_name", "adset_name", "ad_name", "headline", "primary_text"],
    ["Summer Sale", "US - Mobile", "Summer Sale - Image 1", "Summer Sale - Up to 50% Off", "Don't miss our biggest sale of the year! Limited time only."]
    // More rows...
  ]
}
```

**Response:**

```json
{
  "status": "success",
  "message": "Data written successfully",
  "updated_cells": 10
}
```

#### Airtable - Read Records

Reads records from an Airtable base.

**Endpoint:** `POST /integrations/airtable/read`

**Request Body:**

```json
{
  "base_id": "appXXXXXXXXXXXXXX",
  "table_name": "Ads",
  "view_name": "Grid view"
}
```

**Response:**

```json
{
  "status": "success",
  "message": "Records read successfully",
  "result": [
    {
      "id": "recXXXXXXXXXXXXXX",
      "fields": {
        "campaign_name": "Summer Sale",
        "adset_name": "US - Mobile",
        "ad_name": "Summer Sale - Image 1",
        "headline": "Summer Sale - Up to 50% Off",
        "primary_text": "Don't miss our biggest sale of the year! Limited time only."
      }
    },
    // More records...
  ]
}
```

#### n8n - Webhook

Triggers an n8n webhook.

**Endpoint:** `POST /integrations/n8n/webhook`

**Request Body:**

```json
{
  "webhook_url": "https://n8n.example.com/webhook/123456",
  "payload": {
    "event": "ad_created",
    "ad_id": "23456789012345",
    "status": "ACTIVE"
  }
}
```

**Response:**

```json
{
  "status": "success",
  "message": "Webhook triggered successfully",
  "result": {
    "status": "ok",
    "execution_id": "123456789"
  }
}
```

#### CSV - Import

Imports data from a CSV file.

**Endpoint:** `POST /integrations/csv/import`

**Request Body (multipart/form-data):**

```
csv_file: [CSV FILE]
import_type: ads
```

**Response:**

```json
{
  "status": "success",
  "message": "CSV imported successfully",
  "rows_imported": 5
}
```

#### CSV - Export

Exports data to a CSV file.

**Endpoint:** `POST /integrations/csv/export`

**Request Body:**

```json
{
  "export_type": "ads",
  "date_range": "last30days"
}
```

**Response:**

CSV file download

## Data Models

### Ad Content

```json
{
  "headline": "String (max 40 characters)",
  "primary_text": "String (max 125 characters)",
  "description": "String (max 30 characters, optional)"
}
```

### Campaign

```json
{
  "id": "String",
  "name": "String",
  "objective": "String (AWARENESS, TRAFFIC, ENGAGEMENT, LEADS, CONVERSIONS, SALES, APP_INSTALLS)",
  "status": "String (ACTIVE, PAUSED, DELETED)",
  "start_time": "ISO 8601 date string",
  "end_time": "ISO 8601 date string (optional)",
  "daily_budget": "Number",
  "lifetime_budget": "Number (optional)"
}
```

### Ad Set

```json
{
  "id": "String",
  "name": "String",
  "campaign_id": "String",
  "status": "String (ACTIVE, PAUSED, DELETED)",
  "targeting": "Object",
  "start_time": "ISO 8601 date string",
  "end_time": "ISO 8601 date string (optional)",
  "daily_budget": "Number",
  "optimization_goal": "String"
}
```

### Ad

```json
{
  "id": "String",
  "name": "String",
  "adset_id": "String",
  "status": "String (ACTIVE, PAUSED, DELETED)",
  "creative": {
    "page_id": "String",
    "headline": "String",
    "primary_text": "String",
    "description": "String (optional)",
    "image_hash": "String",
    "link": "String",
    "call_to_action": "String"
  }
}
```

## Error Handling

The API uses standard HTTP status codes to indicate the success or failure of a request.

- **200 OK**: The request was successful
- **400 Bad Request**: The request was invalid or cannot be served
- **401 Unauthorized**: Authentication failed
- **403 Forbidden**: The request is not allowed
- **404 Not Found**: The requested resource could not be found
- **429 Too Many Requests**: Rate limit exceeded
- **500 Internal Server Error**: An error occurred on the server

Error responses include a JSON object with details about the error:

```json
{
  "status": "error",
  "message": "Error message",
  "error": {
    "code": "ERROR_CODE",
    "details": "Detailed error information"
  }
}
```

## Rate Limits

The API has the following rate limits:

- **Ad Content Generation**: 10 requests per minute
- **Meta Ads Creation**: 5 requests per minute
- **Integrations**: 20 requests per minute

When a rate limit is exceeded, the API returns a 429 Too Many Requests status code.

## Examples

### Generate Ad Content and Create Ad

```python
import requests
import json

# Generate ad content
content_response = requests.post(
    "http://localhost:5000/api/ad-content/generate",
    headers={"Authorization": "Bearer YOUR_API_KEY"},
    json={
        "product_info": {
            "name": "Premium Fitness Tracker",
            "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
            "target_audience": "Health-conscious adults aged 25-45",
            "unique_selling_points": [
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            "call_to_action": "Shop Now"
        },
        "tone": "professional",
        "platform": "facebook",
        "num_variations": 1
    }
)

content_data = content_response.json()
headline = content_data["variations"][0]["headline"]
primary_text = content_data["variations"][0]["primary_text"]

# Create ad
files = {
    'ad_image': ('image.jpg', open('image.jpg', 'rb'), 'image/jpeg')
}

data = {
    'campaign_name': 'Fitness Tracker Campaign',
    'campaign_objective': 'CONVERSIONS',
    'adset_name': 'US - Mobile - 25-45',
    'daily_budget': '50.00',
    'start_date': '2025-06-05',
    'targeting': json.dumps({"age_min":25,"age_max":45,"genders":[1,2],"geo_locations":{"countries":["US"]}}),
    'ad_name': 'Fitness Tracker Ad 1',
    'page_id': '123456789012345',
    'headline': headline,
    'primary_text': primary_text,
    'website_url': 'https://www.example.com/fitness-tracker',
    'call_to_action': 'SHOP_NOW'
}

ad_response = requests.post(
    "http://localhost:5000/api/meta-ads/create-ad",
    headers={"Authorization": "Bearer YOUR_API_KEY"},
    data=data,
    files=files
)

print(ad_response.json())
```

### Import Data from Google Sheets and Create Bulk Ads

```python
import requests
import json

# Read data from Google Sheets
sheets_response = requests.post(
    "http://localhost:5000/api/integrations/google-sheets/read",
    headers={"Authorization": "Bearer YOUR_API_KEY"},
    json={
        "sheet_id": "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms",
        "sheet_range": "Sheet1!A1:Z100"
    }
)

sheets_data = sheets_response.json()
rows = sheets_data["rows"]

# Convert to CSV
import csv
import io

csv_file = io.StringIO()
writer = csv.writer(csv_file)
headers = list(rows[0].keys())
writer.writerow(headers)

for row in rows:
    writer.writerow([row[header] for header in headers])

csv_content = csv_file.getvalue()
csv_file.close()

# Create bulk ads
files = {
    'bulk_file': ('ads.csv', csv_content, 'text/csv')
}

bulk_response = requests.post(
    "http://localhost:5000/api/meta-ads/create-bulk",
    headers={"Authorization": "Bearer YOUR_API_KEY"},
    files=files
)

print(bulk_response.json())
```

