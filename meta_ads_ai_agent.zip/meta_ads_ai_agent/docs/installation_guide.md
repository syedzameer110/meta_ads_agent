# Meta Ads AI Agent - Installation Guide

This guide provides step-by-step instructions for installing and running the Meta Ads AI Agent.

## Prerequisites

Before installing the Meta Ads AI Agent, ensure you have the following:

- Python 3.8 or higher
- pip (Python package installer)
- Git (optional, for cloning the repository)
- Docker and Docker Compose (optional, for containerized deployment)

## Installation Options

You can install and run the Meta Ads AI Agent using one of the following methods:

1. [Local Installation](#local-installation)
2. [Docker Installation](#docker-installation)

## Local Installation

### 1. Clone or download the repository

```bash
git clone https://github.com/yourusername/meta-ads-ai-agent.git
cd meta-ads-ai-agent
```

Or download and extract the ZIP file from the repository.

### 2. Create a virtual environment

```bash
python -m venv venv
```

### 3. Activate the virtual environment

On Windows:
```bash
venv\Scripts\activate
```

On macOS and Linux:
```bash
source venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Create a .env file

Create a `.env` file in the root directory with the following content:

```
# Application Settings
DEBUG=False
SECRET_KEY=your_secret_key_here

# OpenAI API
OPENAI_API_KEY=your_openai_api_key_here

# Meta Ads API
META_ACCESS_TOKEN=your_meta_access_token_here
META_AD_ACCOUNT_ID=your_meta_ad_account_id_here

# Google Sheets API
GOOGLE_SHEETS_CREDENTIALS={}

# Airtable API
AIRTABLE_API_KEY=your_airtable_api_key_here
```

Replace the placeholder values with your actual API keys and credentials.

### 6. Run the application

```bash
flask run
```

The application will be available at http://localhost:5000.

## Docker Installation

### 1. Clone or download the repository

```bash
git clone https://github.com/yourusername/meta-ads-ai-agent.git
cd meta-ads-ai-agent
```

Or download and extract the ZIP file from the repository.

### 2. Create a .env file

Create a `.env` file in the root directory with the following content:

```
# Application Settings
DEBUG=False
SECRET_KEY=your_secret_key_here

# OpenAI API
OPENAI_API_KEY=your_openai_api_key_here

# Meta Ads API
META_ACCESS_TOKEN=your_meta_access_token_here
META_AD_ACCOUNT_ID=your_meta_ad_account_id_here

# Google Sheets API
GOOGLE_SHEETS_CREDENTIALS={}

# Airtable API
AIRTABLE_API_KEY=your_airtable_api_key_here
```

Replace the placeholder values with your actual API keys and credentials.

### 3. Build and run with Docker Compose

```bash
docker-compose up -d
```

The application will be available at http://localhost:5000.

## API Keys and Credentials

### OpenAI API Key

1. Sign up for an account at [OpenAI](https://platform.openai.com/)
2. Navigate to the API section
3. Create a new API key
4. Copy the API key and add it to your `.env` file

### Meta Ads API Access Token

1. Create a [Meta for Developers](https://developers.facebook.com/) account
2. Create a new app
3. Add the Marketing API product to your app
4. Generate an access token with the necessary permissions
5. Copy the access token and add it to your `.env` file

### Meta Ad Account ID

1. Log in to [Meta Business Manager](https://business.facebook.com/)
2. Navigate to Ad Accounts
3. Select your ad account
4. The ad account ID will be displayed in the format "act_XXXXXXXXXX"
5. Copy the ad account ID and add it to your `.env` file

### Google Sheets API Credentials

1. Create a [Google Cloud Platform](https://console.cloud.google.com/) account
2. Create a new project
3. Enable the Google Sheets API
4. Create a service account
5. Generate a JSON key for the service account
6. Copy the JSON key and add it to your `.env` file as a JSON string

### Airtable API Key

1. Sign up for an [Airtable](https://airtable.com/) account
2. Navigate to your account settings
3. Generate an API key
4. Copy the API key and add it to your `.env` file

## Running Tests

To run the tests, use the following command:

```bash
./run_tests.py
```

This will run all the tests and generate an HTML test report in the `test_reports` directory.

## Troubleshooting

If you encounter any issues during installation or running the application, please check the following:

1. Ensure all API keys and credentials are correctly set in the `.env` file
2. Check that all dependencies are installed correctly
3. Verify that the required ports are not being used by other applications
4. Check the application logs for error messages

If you continue to experience issues, please contact support or open an issue on the repository.

