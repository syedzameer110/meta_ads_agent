# Meta Ads AI Agent - Developer Guide

## Table of Contents

1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Development Environment Setup](#development-environment-setup)
4. [Architecture](#architecture)
5. [Core Components](#core-components)
6. [API Reference](#api-reference)
7. [Testing](#testing)
8. [Deployment](#deployment)
9. [Contributing](#contributing)
10. [Troubleshooting](#troubleshooting)

## Introduction

This developer guide provides comprehensive information for developers who want to understand, modify, or contribute to the Meta Ads AI Agent project. The guide covers the project structure, development environment setup, architecture, core components, and more.

## Project Structure

```
meta_ads_ai_agent/
├── app/                    # Main application package
│   ├── api/                # API endpoints
│   │   ├── __init__.py     # API blueprint initialization
│   │   ├── ad_content.py   # Ad content generation endpoints
│   │   ├── meta_ads.py     # Meta ads creation endpoints
│   │   └── integrations.py # Integration endpoints
│   ├── models/             # Data models
│   │   ├── __init__.py
│   │   ├── ad_content.py   # Ad content models
│   │   └── project.py      # Project models
│   ├── services/           # Business logic services
│   │   ├── __init__.py
│   │   ├── openai_service.py    # OpenAI integration
│   │   ├── meta_ads_service.py  # Meta Ads API integration
│   │   ├── meta_auth.py         # Meta authentication
│   │   └── integration_service.py # External integrations
│   ├── static/             # Static assets
│   │   ├── css/            # CSS files
│   │   ├── js/             # JavaScript files
│   │   ├── img/            # Images
│   │   └── templates/      # CSV and other templates
│   ├── templates/          # HTML templates
│   │   ├── layout.html     # Base template
│   │   ├── index.html      # Home page
│   │   ├── ad_content.html # Ad content generation page
│   │   ├── meta_ads.html   # Meta ads creation page
│   │   ├── integrations.html # Integrations page
│   │   └── settings.html   # Settings page
│   └── utils/              # Utility functions
│       ├── __init__.py
│       ├── logger.py       # Logging utilities
│       └── error_handler.py # Error handling utilities
├── config/                 # Configuration files
│   ├── __init__.py
│   ├── config.py           # Configuration module
│   ├── templates/          # Configuration templates
│   └── examples/           # Example configurations
├── data/                   # Data files
│   ├── input/              # Input data
│   └── output/             # Output data
├── docs/                   # Documentation
│   ├── user_guide.md       # User guide
│   ├── api_documentation.md # API documentation
│   └── developer_guide.md  # Developer guide
├── scripts/                # Utility scripts
├── tests/                  # Test files
│   ├── __init__.py
│   └── test_models.py      # Tests for data models
├── .env.example            # Example environment variables
├── app.py                  # Main application entry point
├── README.md               # Project README
└── requirements.txt        # Python dependencies
```

## Development Environment Setup

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Git
- Virtual environment tool (venv, virtualenv, or conda)

### Setup Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/meta-ads-ai-agent.git
   cd meta-ads-ai-agent
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file from the example:
   ```bash
   cp .env.example .env
   ```

5. Edit the `.env` file with your API keys and configuration.

6. Run the application:
   ```bash
   python app.py
   ```

7. Access the web interface at `http://localhost:5000`

### Development Tools

- **Code Editor**: Visual Studio Code, PyCharm, or any preferred editor
- **API Testing**: Postman or curl for testing API endpoints
- **Database**: SQLite for development, PostgreSQL for production
- **Version Control**: Git for source code management

## Architecture

The Meta Ads AI Agent follows a modular architecture with clear separation of concerns:

### High-Level Architecture

```
User Interface (Web Browser)
         ↑↓
Web Server (Flask)
         ↑↓
Application Layer
         ↑↓
Service Layer
         ↑↓
External APIs (Meta, OpenAI, etc.)
```

### Components

1. **User Interface**: HTML templates with CSS and JavaScript
2. **Web Server**: Flask web framework
3. **Application Layer**: API endpoints and routes
4. **Service Layer**: Business logic and external API integration
5. **Data Layer**: Data models and storage

### Design Patterns

- **Model-View-Controller (MVC)**: Separation of data models, views (templates), and controllers (routes)
- **Service Layer**: Encapsulation of business logic in service classes
- **Repository Pattern**: Data access abstraction
- **Factory Pattern**: Object creation abstraction
- **Dependency Injection**: Service dependencies are injected rather than created internally

## Core Components

### Ad Content Generation

The ad content generation component uses OpenAI's GPT models to generate ad headlines and primary text based on product information and preferences.

#### Key Files

- `app/services/openai_service.py`: OpenAI API integration
- `app/api/ad_content.py`: API endpoints for ad content generation
- `app/models/ad_content.py`: Data models for ad content

#### Flow

1. User provides product information and preferences
2. System constructs a prompt for the OpenAI API
3. OpenAI API generates ad content variations
4. System validates and formats the generated content
5. Content is returned to the user

### Meta Ads Integration

The Meta Ads integration component interacts with the Meta Ads Marketing API to create and manage ads, campaigns, and ad sets.

#### Key Files

- `app/services/meta_ads_service.py`: Meta Ads API integration
- `app/services/meta_auth.py`: Meta authentication
- `app/api/meta_ads.py`: API endpoints for Meta ads creation

#### Flow

1. User provides ad details
2. System authenticates with Meta Ads API
3. System creates campaign, ad set, and ad
4. System uploads ad creative (image)
5. System returns the created ad information

### External Integrations

The external integrations component connects with tools like Google Sheets, Airtable, and n8n for workflow automation.

#### Key Files

- `app/services/integration_service.py`: Integration with external tools
- `app/api/integrations.py`: API endpoints for integrations

#### Supported Integrations

- **Google Sheets**: Import and export data to/from Google Sheets
- **Airtable**: Sync data with Airtable for collaborative workflow
- **n8n**: Trigger n8n workflows for complex automation
- **CSV Import/Export**: Import and export data using CSV files

## API Reference

The Meta Ads AI Agent provides a comprehensive API for programmatic access to all features. See the [API Documentation](api_documentation.md) for detailed information.

### API Endpoints

- `/api/ad-content/generate`: Generate ad content using AI
- `/api/meta-ads/create-ad`: Create a new ad on Meta platforms
- `/api/meta-ads/create-bulk`: Create multiple ads from a CSV file
- `/api/integrations/google-sheets/read`: Read data from a Google Sheet
- `/api/integrations/google-sheets/write`: Write data to a Google Sheet
- `/api/integrations/airtable/read`: Read records from an Airtable base
- `/api/integrations/n8n/webhook`: Trigger an n8n webhook
- `/api/integrations/csv/import`: Import data from a CSV file
- `/api/integrations/csv/export`: Export data to a CSV file

## Testing

The Meta Ads AI Agent includes a comprehensive test suite to ensure code quality and functionality.

### Test Structure

```
tests/
├── __init__.py
├── test_models.py       # Tests for data models
├── test_services.py     # Tests for services
├── test_api.py          # Tests for API endpoints
└── test_integrations.py # Tests for integrations
```

### Running Tests

```bash
# Run all tests
python -m pytest

# Run specific test file
python -m pytest tests/test_models.py

# Run tests with coverage
python -m pytest --cov=app tests/
```

### Test Types

- **Unit Tests**: Test individual components in isolation
- **Integration Tests**: Test interactions between components
- **API Tests**: Test API endpoints
- **End-to-End Tests**: Test complete workflows

## Deployment

The Meta Ads AI Agent can be deployed in various environments, from development to production.

### Development

```bash
python app.py
```

### Production

For production deployment, we recommend using Gunicorn as the WSGI server and Nginx as the reverse proxy.

#### Gunicorn

```bash
gunicorn -w 4 -b 127.0.0.1:5000 app:app
```

#### Docker

```bash
# Build the Docker image
docker build -t meta-ads-ai-agent .

# Run the Docker container
docker run -p 5000:5000 meta-ads-ai-agent
```

#### Docker Compose

```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - META_ACCESS_TOKEN=${META_ACCESS_TOKEN}
```

## Contributing

We welcome contributions to the Meta Ads AI Agent project! Here's how you can contribute:

### Contribution Guidelines

1. Fork the repository
2. Create a new branch for your feature or bug fix
3. Make your changes
4. Write tests for your changes
5. Run the test suite to ensure all tests pass
6. Submit a pull request

### Code Style

We follow the PEP 8 style guide for Python code. Please ensure your code adheres to this style guide.

### Pull Request Process

1. Ensure your code passes all tests
2. Update the documentation if necessary
3. Add a clear description of your changes
4. Submit the pull request

## Troubleshooting

### Common Development Issues

#### API Connection Errors

- **Issue**: Unable to connect to Meta Ads API
- **Solution**: Verify your access token is valid and has the necessary permissions
- **Debug**: Check the logs for detailed error messages

#### OpenAI API Errors

- **Issue**: OpenAI API returns an error
- **Solution**: Check your API key and ensure you have sufficient credits
- **Debug**: Review the OpenAI API documentation for error codes

#### Database Errors

- **Issue**: Database connection errors
- **Solution**: Verify your database configuration
- **Debug**: Check the logs for detailed error messages

### Debugging Tools

- **Logging**: Use the built-in logging module to debug issues
- **Flask Debug Mode**: Enable Flask debug mode for detailed error messages
- **Postman**: Use Postman to test API endpoints
- **Browser Developer Tools**: Use browser developer tools to debug frontend issues

### Getting Help

If you encounter issues that are not covered in this guide, please:

1. Check the project issues on GitHub
2. Search for similar issues in the project documentation
3. Create a new issue with detailed information about the problem
4. Reach out to the project maintainers for assistance

