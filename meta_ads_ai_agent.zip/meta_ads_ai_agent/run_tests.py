#!/usr/bin/env python3
"""
Script to run all tests and generate a test report
"""

import unittest
import sys
import os
import time
import datetime
import json
from unittest import TestLoader, TextTestRunner, TestResult

class HTMLTestResult(TestResult):
    """HTML Test Result class"""

    def __init__(self):
        super(HTMLTestResult, self).__init__()
        self.start_time = time.time()
        self.test_results = []
        self.current_test = None

    def startTest(self, test):
        """Called when a test starts"""
        super(HTMLTestResult, self).startTest(test)
        self.current_test = {
            'name': test.id(),
            'start_time': time.time(),
            'end_time': None,
            'status': 'running',
            'error': None,
            'failure': None
        }

    def stopTest(self, test):
        """Called when a test stops"""
        super(HTMLTestResult, self).stopTest(test)
        if self.current_test:
            self.current_test['end_time'] = time.time()
            self.current_test['duration'] = self.current_test['end_time'] - self.current_test['start_time']
            if self.current_test['status'] == 'running':
                self.current_test['status'] = 'passed'
            self.test_results.append(self.current_test)
            self.current_test = None

    def addError(self, test, err):
        """Called when a test raises an error"""
        super(HTMLTestResult, self).addError(test, err)
        if self.current_test:
            self.current_test['status'] = 'error'
            self.current_test['error'] = str(err[1])

    def addFailure(self, test, err):
        """Called when a test fails"""
        super(HTMLTestResult, self).addFailure(test, err)
        if self.current_test:
            self.current_test['status'] = 'failure'
            self.current_test['failure'] = str(err[1])

    def addSkip(self, test, reason):
        """Called when a test is skipped"""
        super(HTMLTestResult, self).addSkip(test, reason)
        if self.current_test:
            self.current_test['status'] = 'skipped'
            self.current_test['skip_reason'] = reason

    def addSuccess(self, test):
        """Called when a test succeeds"""
        super(HTMLTestResult, self).addSuccess(test)
        if self.current_test:
            self.current_test['status'] = 'passed'

    def generate_html_report(self, output_file):
        """Generate HTML report"""
        end_time = time.time()
        duration = end_time - self.start_time
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        passed = len([t for t in self.test_results if t['status'] == 'passed'])
        failed = len([t for t in self.test_results if t['status'] == 'failure'])
        errors = len([t for t in self.test_results if t['status'] == 'error'])
        skipped = len([t for t in self.test_results if t['status'] == 'skipped'])
        total = len(self.test_results)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meta Ads AI Agent - Test Report</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        h1, h2, h3 {{
            color: #2c3e50;
        }}
        .summary {{
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }}
        .summary-item {{
            display: inline-block;
            margin-right: 20px;
            font-size: 18px;
        }}
        .passed {{
            color: #28a745;
        }}
        .failed {{
            color: #dc3545;
        }}
        .error {{
            color: #fd7e14;
        }}
        .skipped {{
            color: #6c757d;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }}
        th, td {{
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }}
        th {{
            background-color: #f8f9fa;
            font-weight: bold;
        }}
        tr:nth-child(even) {{
            background-color: #f2f2f2;
        }}
        .test-passed {{
            background-color: #d4edda;
        }}
        .test-failed {{
            background-color: #f8d7da;
        }}
        .test-error {{
            background-color: #fff3cd;
        }}
        .test-skipped {{
            background-color: #e2e3e5;
        }}
        .details {{
            margin-top: 10px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 5px;
            white-space: pre-wrap;
            font-family: monospace;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Meta Ads AI Agent - Test Report</h1>
        <div class="summary">
            <p><strong>Timestamp:</strong> {timestamp}</p>
            <p><strong>Duration:</strong> {duration:.2f} seconds</p>
            <div>
                <div class="summary-item"><strong>Total:</strong> {total}</div>
                <div class="summary-item passed"><strong>Passed:</strong> {passed}</div>
                <div class="summary-item failed"><strong>Failed:</strong> {failed}</div>
                <div class="summary-item error"><strong>Errors:</strong> {errors}</div>
                <div class="summary-item skipped"><strong>Skipped:</strong> {skipped}</div>
            </div>
        </div>

        <h2>Test Results</h2>
        <table>
            <thead>
                <tr>
                    <th>Test</th>
                    <th>Status</th>
                    <th>Duration (s)</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
"""

        for test in self.test_results:
            status_class = f"test-{test['status']}"
            details = ""
            if test['status'] == 'failure':
                details = f"<div class='details'>{test['failure']}</div>"
            elif test['status'] == 'error':
                details = f"<div class='details'>{test['error']}</div>"
            elif test['status'] == 'skipped':
                details = f"<div class='details'>{test.get('skip_reason', '')}</div>"

            html += f"""
                <tr class="{status_class}">
                    <td>{test['name']}</td>
                    <td>{test['status'].upper()}</td>
                    <td>{test['duration']:.2f}</td>
                    <td>{details}</td>
                </tr>
"""

        html += """
            </tbody>
        </table>
    </div>
</body>
</html>
"""

        with open(output_file, 'w') as f:
            f.write(html)

        return output_file

def run_tests():
    """Run all tests and generate a report"""
    # Create test directory if it doesn't exist
    reports_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_reports')
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)

    # Set up test loader and runner
    loader = TestLoader()
    tests_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests')
    suite = loader.discover(tests_dir)

    # Run tests
    result = HTMLTestResult()
    runner = TextTestRunner(verbosity=2)
    runner._makeResult = lambda: result
    runner.run(suite)

    # Generate HTML report
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    report_file = os.path.join(reports_dir, f'test_report_{timestamp}.html')
    result.generate_html_report(report_file)

    # Print summary
    print(f"\nTest Report: {report_file}")
    print(f"Total: {result.testsRun}")
    print(f"Passed: {result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped)}")
    print(f"Failed: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped)}")

    # Return exit code
    return 0 if len(result.failures) == 0 and len(result.errors) == 0 else 1

if __name__ == '__main__':
    sys.exit(run_tests())

