# Changelog

All notable changes to the Meta Ads AI Agent project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-06-06

### Added
- Initial release of Meta Ads AI Agent
- AI-powered content generation for Meta ads
- Integration with Meta Ads Marketing API
- Support for bulk ad creation
- Web interface for managing ad content and campaigns
- Integration with external tools (n8n, Airtable, Google Sheets)
- Comprehensive documentation and user guides
- Docker support for easy deployment

### Changed
- N/A (Initial release)

### Fixed
- N/A (Initial release)

