"""
Tests for ad content models
"""

import unittest
from app.models.ad_content import AdHeadline, AdPrimaryText, AdDescription

class TestAdContentModels(unittest.TestCase):
    """Test cases for ad content models"""

    def test_ad_headline_creation(self):
        """Test that an AdHeadline object can be created with valid data"""
        headline = "Test Headline for Ad"
        ad_headline = AdHeadline(headline)
        self.assertEqual(ad_headline.text, headline)
        self.assertEqual(str(ad_headline), headline)
        self.assertEqual(len(ad_headline), len(headline))

    def test_ad_headline_character_limit(self):
        """Test that AdHeadline enforces the character limit"""
        # Create a headline that exceeds the character limit (40 characters)
        long_headline = "This is a very long headline that exceeds the character limit for Meta ads and should be truncated"
        ad_headline = AdHeadline(long_headline)
        self.assertEqual(len(ad_headline.text), 40)
        self.assertEqual(ad_headline.text, long_headline[:40])

    def test_ad_primary_text_creation(self):
        """Test that an AdPrimaryText object can be created with valid data"""
        primary_text = "This is a test primary text for an ad."
        ad_primary_text = AdPrimaryText(primary_text)
        self.assertEqual(ad_primary_text.text, primary_text)
        self.assertEqual(str(ad_primary_text), primary_text)
        self.assertEqual(len(ad_primary_text), len(primary_text))

    def test_ad_primary_text_character_limit(self):
        """Test that AdPrimaryText enforces the character limit"""
        # Create a primary text that exceeds the character limit (125 characters)
        long_primary_text = "This is a very long primary text that exceeds the character limit for Meta ads and should be truncated. " \
                           "It contains a lot of information about the product or service being advertised."
        ad_primary_text = AdPrimaryText(long_primary_text)
        self.assertEqual(len(ad_primary_text.text), 125)
        self.assertEqual(ad_primary_text.text, long_primary_text[:125])

    def test_ad_description_creation(self):
        """Test that an AdDescription object can be created with valid data"""
        description = "Test description for ad."
        ad_description = AdDescription(description)
        self.assertEqual(ad_description.text, description)
        self.assertEqual(str(ad_description), description)
        self.assertEqual(len(ad_description), len(description))

    def test_ad_description_character_limit(self):
        """Test that AdDescription enforces the character limit"""
        # Create a description that exceeds the character limit (30 characters)
        long_description = "This is a very long description that exceeds the character limit for Meta ads."
        ad_description = AdDescription(long_description)
        self.assertEqual(len(ad_description.text), 30)
        self.assertEqual(ad_description.text, long_description[:30])

    def test_ad_headline_validation(self):
        """Test that AdHeadline validates input"""
        # Test with None
        with self.assertRaises(ValueError):
            AdHeadline(None)
        
        # Test with empty string
        with self.assertRaises(ValueError):
            AdHeadline("")

    def test_ad_primary_text_validation(self):
        """Test that AdPrimaryText validates input"""
        # Test with None
        with self.assertRaises(ValueError):
            AdPrimaryText(None)
        
        # Test with empty string
        with self.assertRaises(ValueError):
            AdPrimaryText("")

    def test_ad_description_validation(self):
        """Test that AdDescription validates input"""
        # Test with None
        with self.assertRaises(ValueError):
            AdDescription(None)
        
        # Test with empty string
        with self.assertRaises(ValueError):
            AdDescription("")

if __name__ == '__main__':
    unittest.main()

