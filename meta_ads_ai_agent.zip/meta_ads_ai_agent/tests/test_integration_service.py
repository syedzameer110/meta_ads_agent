"""
Tests for Integration service
"""

import unittest
from unittest.mock import patch, MagicMock, mock_open
from app.services.integration_service import IntegrationService

class TestIntegrationService(unittest.TestCase):
    """Test cases for Integration service"""

    def setUp(self):
        """Set up test fixtures"""
        self.google_sheets_credentials = {
            "type": "service_account",
            "project_id": "test-project",
            "private_key_id": "test-key-id",
            "private_key": "test-private-key",
            "client_email": "test@example.com",
            "client_id": "test-client-id",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/test%40example.com"
        }
        self.airtable_api_key = "test_airtable_api_key"
        self.n8n_webhook_url = "https://n8n.example.com/webhook/test"

    @patch('app.services.integration_service.gspread.service_account_from_dict')
    def test_connect_google_sheets(self, mock_service_account):
        """Test that connection to Google Sheets can be established"""
        # Set up mock
        mock_client = MagicMock()
        mock_service_account.return_value = mock_client

        # Create service and connect to Google Sheets
        service = IntegrationService()
        result = service.connect_google_sheets(credentials=self.google_sheets_credentials)

        # Verify that the connection was established with the correct parameters
        mock_service_account.assert_called_once_with(self.google_sheets_credentials)
        self.assertTrue(result)
        self.assertEqual(service.google_sheets_client, mock_client)

    @patch('app.services.integration_service.gspread.service_account_from_dict')
    def test_read_google_sheets(self, mock_service_account):
        """Test that data can be read from Google Sheets"""
        # Set up mock
        mock_client = MagicMock()
        mock_sheet = MagicMock()
        mock_worksheet = MagicMock()
        mock_client.open_by_key.return_value = mock_sheet
        mock_sheet.worksheet.return_value = mock_worksheet
        mock_worksheet.get_all_records.return_value = [
            {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"},
            {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}
        ]
        mock_service_account.return_value = mock_client

        # Create service and read from Google Sheets
        service = IntegrationService()
        service.connect_google_sheets(credentials=self.google_sheets_credentials)
        data = service.read_google_sheets(sheet_id="test_sheet_id", sheet_name="Sheet1")

        # Verify that the data was read with the correct parameters
        mock_client.open_by_key.assert_called_once_with("test_sheet_id")
        mock_sheet.worksheet.assert_called_once_with("Sheet1")
        mock_worksheet.get_all_records.assert_called_once()
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0]["campaign_name"], "Summer Sale")
        self.assertEqual(data[1]["campaign_name"], "Winter Collection")

    @patch('app.services.integration_service.gspread.service_account_from_dict')
    def test_write_google_sheets(self, mock_service_account):
        """Test that data can be written to Google Sheets"""
        # Set up mock
        mock_client = MagicMock()
        mock_sheet = MagicMock()
        mock_worksheet = MagicMock()
        mock_client.open_by_key.return_value = mock_sheet
        mock_sheet.worksheet.return_value = mock_worksheet
        mock_service_account.return_value = mock_client

        # Create service and write to Google Sheets
        service = IntegrationService()
        service.connect_google_sheets(credentials=self.google_sheets_credentials)
        data = [
            ["campaign_name", "adset_name", "ad_name"],
            ["Summer Sale", "US - Mobile", "Summer Sale - Image 1"],
            ["Winter Collection", "EU - Desktop", "Winter Collection - Video 1"]
        ]
        result = service.write_google_sheets(sheet_id="test_sheet_id", sheet_name="Sheet1", data=data)

        # Verify that the data was written with the correct parameters
        mock_client.open_by_key.assert_called_once_with("test_sheet_id")
        mock_sheet.worksheet.assert_called_once_with("Sheet1")
        mock_worksheet.update.assert_called_once()
        args, kwargs = mock_worksheet.update.call_args
        self.assertEqual(args[0], "A1")
        self.assertEqual(args[1], data)
        self.assertTrue(result)

    @patch('app.services.integration_service.Airtable')
    def test_connect_airtable(self, mock_airtable):
        """Test that connection to Airtable can be established"""
        # Set up mock
        mock_client = MagicMock()
        mock_airtable.return_value = mock_client

        # Create service and connect to Airtable
        service = IntegrationService()
        result = service.connect_airtable(base_id="test_base_id", api_key=self.airtable_api_key)

        # Verify that the connection was established with the correct parameters
        mock_airtable.assert_called_once_with(self.airtable_api_key, "test_base_id")
        self.assertTrue(result)
        self.assertEqual(service.airtable_client, mock_client)

    @patch('app.services.integration_service.Airtable')
    def test_read_airtable(self, mock_airtable):
        """Test that data can be read from Airtable"""
        # Set up mock
        mock_client = MagicMock()
        mock_table = MagicMock()
        mock_client.__getitem__.return_value = mock_table
        mock_table.all.return_value = [
            {"id": "rec123", "fields": {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"}},
            {"id": "rec456", "fields": {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}}
        ]
        mock_airtable.return_value = mock_client

        # Create service and read from Airtable
        service = IntegrationService()
        service.connect_airtable(base_id="test_base_id", api_key=self.airtable_api_key)
        data = service.read_airtable(table_name="Ads")

        # Verify that the data was read with the correct parameters
        mock_client.__getitem__.assert_called_once_with("Ads")
        mock_table.all.assert_called_once()
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0]["fields"]["campaign_name"], "Summer Sale")
        self.assertEqual(data[1]["fields"]["campaign_name"], "Winter Collection")

    @patch('app.services.integration_service.Airtable')
    def test_create_airtable_records(self, mock_airtable):
        """Test that records can be created in Airtable"""
        # Set up mock
        mock_client = MagicMock()
        mock_table = MagicMock()
        mock_client.__getitem__.return_value = mock_table
        mock_table.batch_create.return_value = [
            {"id": "rec123", "fields": {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"}},
            {"id": "rec456", "fields": {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}}
        ]
        mock_airtable.return_value = mock_client

        # Create service and create records in Airtable
        service = IntegrationService()
        service.connect_airtable(base_id="test_base_id", api_key=self.airtable_api_key)
        records = [
            {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"},
            {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}
        ]
        result = service.create_airtable_records(table_name="Ads", records=records)

        # Verify that the records were created with the correct parameters
        mock_client.__getitem__.assert_called_once_with("Ads")
        mock_table.batch_create.assert_called_once_with(records)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["id"], "rec123")
        self.assertEqual(result[1]["id"], "rec456")

    @patch('app.services.integration_service.requests.post')
    def test_trigger_n8n_webhook(self, mock_post):
        """Test that n8n webhook can be triggered"""
        # Set up mock
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "execution_id": "test_execution_id"}
        mock_post.return_value = mock_response

        # Create service and trigger n8n webhook
        service = IntegrationService()
        payload = {"event": "ad_created", "ad_id": "23123456789012345"}
        result = service.trigger_n8n_webhook(webhook_url=self.n8n_webhook_url, payload=payload)

        # Verify that the webhook was triggered with the correct parameters
        mock_post.assert_called_once_with(self.n8n_webhook_url, json=payload)
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["execution_id"], "test_execution_id")

    @patch('builtins.open', new_callable=mock_open, read_data='campaign_name,adset_name,ad_name\nSummer Sale,US - Mobile,Summer Sale - Image 1\nWinter Collection,EU - Desktop,Winter Collection - Video 1')
    def test_import_csv(self, mock_file):
        """Test that data can be imported from a CSV file"""
        # Create service and import CSV
        service = IntegrationService()
        result = service.import_csv(file_path="/path/to/file.csv", import_type="ads")

        # Verify that the file was opened and data was imported
        mock_file.assert_called_once_with("/path/to/file.csv", "r", encoding="utf-8")
        self.assertEqual(result["rows_imported"], 2)
        self.assertEqual(len(service.imported_data["ads"]), 2)
        self.assertEqual(service.imported_data["ads"][0]["campaign_name"], "Summer Sale")
        self.assertEqual(service.imported_data["ads"][1]["campaign_name"], "Winter Collection")

    def test_export_csv(self):
        """Test that data can be exported to a CSV file"""
        # Create service and set up data
        service = IntegrationService()
        service.imported_data["ads"] = [
            {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"},
            {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}
        ]

        # Export CSV
        result = service.export_csv(export_type="ads")

        # Verify that the data was exported correctly
        self.assertIn("campaign_name,adset_name,ad_name", result)
        self.assertIn("Summer Sale,US - Mobile,Summer Sale - Image 1", result)
        self.assertIn("Winter Collection,EU - Desktop,Winter Collection - Video 1", result)

    @patch('app.services.integration_service.gspread.service_account_from_dict')
    def test_error_handling_google_sheets(self, mock_service_account):
        """Test that errors are handled properly for Google Sheets"""
        # Set up mock to raise an exception
        mock_service_account.side_effect = Exception("API Error")

        # Create service and try to connect to Google Sheets
        service = IntegrationService()
        
        # Verify that the error is caught and False is returned
        result = service.connect_google_sheets(credentials=self.google_sheets_credentials)
        self.assertFalse(result)

    @patch('app.services.integration_service.Airtable')
    def test_error_handling_airtable(self, mock_airtable):
        """Test that errors are handled properly for Airtable"""
        # Set up mock to raise an exception
        mock_airtable.side_effect = Exception("API Error")

        # Create service and try to connect to Airtable
        service = IntegrationService()
        
        # Verify that the error is caught and False is returned
        result = service.connect_airtable(base_id="test_base_id", api_key=self.airtable_api_key)
        self.assertFalse(result)

    @patch('app.services.integration_service.requests.post')
    def test_error_handling_n8n_webhook(self, mock_post):
        """Test that errors are handled properly for n8n webhook"""
        # Set up mock to raise an exception
        mock_post.side_effect = Exception("API Error")

        # Create service and try to trigger n8n webhook
        service = IntegrationService()
        payload = {"event": "ad_created", "ad_id": "23123456789012345"}
        
        # Verify that the error is caught and None is returned
        result = service.trigger_n8n_webhook(webhook_url=self.n8n_webhook_url, payload=payload)
        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()

