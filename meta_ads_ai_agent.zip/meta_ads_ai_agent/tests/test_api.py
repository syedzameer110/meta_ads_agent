"""
Tests for API endpoints
"""

import unittest
import json
from unittest.mock import patch, MagicMock
from app import app
from app.services.openai_service import OpenAIService
from app.services.meta_ads_service import MetaAdsService
from app.services.integration_service import IntegrationService
from tests.mocks.mock_openai_service import MockOpenAIService
from tests.mocks.mock_meta_ads_service import MockMetaAdsService
from tests.mocks.mock_integration_service import MockIntegrationService

class TestAPI(unittest.TestCase):
    """Test cases for API endpoints"""

    def setUp(self):
        """Set up test fixtures"""
        self.app = app.test_client()
        self.app.testing = True

    @patch('app.api.ad_content.OpenAIService')
    def test_generate_headlines(self, mock_openai_service):
        """Test that headlines can be generated via API"""
        # Set up mock
        mock_instance = MockOpenAIService()
        mock_openai_service.return_value = mock_instance

        # Make request
        product_info = {
            "name": "Premium Fitness Tracker",
            "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
            "target_audience": "Health-conscious adults aged 25-45",
            "unique_selling_points": [
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            "call_to_action": "Shop Now"
        }
        response = self.app.post('/api/ad-content/generate-headlines',
                                json={
                                    "product_info": product_info,
                                    "tone": "professional",
                                    "platform": "facebook",
                                    "num_variations": 3
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('headlines', data)
        self.assertEqual(len(data['headlines']), 3)
        self.assertEqual(data['headlines'][0], "Introducing the New Premium Fitness Tracker")

    @patch('app.api.ad_content.OpenAIService')
    def test_generate_primary_text(self, mock_openai_service):
        """Test that primary text can be generated via API"""
        # Set up mock
        mock_instance = MockOpenAIService()
        mock_openai_service.return_value = mock_instance

        # Make request
        product_info = {
            "name": "Premium Fitness Tracker",
            "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
            "target_audience": "Health-conscious adults aged 25-45",
            "unique_selling_points": [
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            "call_to_action": "Shop Now"
        }
        response = self.app.post('/api/ad-content/generate-primary-text',
                                json={
                                    "product_info": product_info,
                                    "tone": "professional",
                                    "platform": "facebook",
                                    "num_variations": 3
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('primary_texts', data)
        self.assertEqual(len(data['primary_texts']), 3)
        self.assertIn("Advanced fitness tracker with heart rate monitoring and sleep tracking", data['primary_texts'][0])

    @patch('app.api.ad_content.OpenAIService')
    def test_generate_descriptions(self, mock_openai_service):
        """Test that descriptions can be generated via API"""
        # Set up mock
        mock_instance = MockOpenAIService()
        mock_openai_service.return_value = mock_instance

        # Make request
        product_info = {
            "name": "Premium Fitness Tracker",
            "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
            "target_audience": "Health-conscious adults aged 25-45",
            "unique_selling_points": [
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            "call_to_action": "Shop Now"
        }
        response = self.app.post('/api/ad-content/generate-descriptions',
                                json={
                                    "product_info": product_info,
                                    "tone": "professional",
                                    "platform": "facebook",
                                    "num_variations": 3
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('descriptions', data)
        self.assertEqual(len(data['descriptions']), 3)
        self.assertEqual(data['descriptions'][0], "Quality Premium Fitness Tracker for professionals")

    @patch('app.api.ad_content.OpenAIService')
    def test_generate_all(self, mock_openai_service):
        """Test that all ad content can be generated via API"""
        # Set up mock
        mock_instance = MockOpenAIService()
        mock_openai_service.return_value = mock_instance

        # Make request
        product_info = {
            "name": "Premium Fitness Tracker",
            "description": "Advanced fitness tracker with heart rate monitoring and sleep tracking",
            "target_audience": "Health-conscious adults aged 25-45",
            "unique_selling_points": [
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            "call_to_action": "Shop Now"
        }
        response = self.app.post('/api/ad-content/generate-all',
                                json={
                                    "product_info": product_info,
                                    "tone": "professional",
                                    "platform": "facebook",
                                    "num_variations": 3
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('headlines', data)
        self.assertIn('primary_texts', data)
        self.assertIn('descriptions', data)
        self.assertEqual(len(data['headlines']), 3)
        self.assertEqual(len(data['primary_texts']), 3)
        self.assertEqual(len(data['descriptions']), 3)

    @patch('app.api.meta_ads.MetaAdsService')
    def test_create_campaign(self, mock_meta_ads_service):
        """Test that a campaign can be created via API"""
        # Set up mock
        mock_instance = MockMetaAdsService()
        mock_meta_ads_service.return_value = mock_instance

        # Make request
        response = self.app.post('/api/meta-ads/create-campaign',
                                json={
                                    "name": "Test Campaign",
                                    "objective": "CONVERSIONS",
                                    "status": "ACTIVE",
                                    "daily_budget": 50.00
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('id', data)
        self.assertIn('name', data)
        self.assertEqual(data['name'], "Test Campaign")
        self.assertEqual(data['objective'], "CONVERSIONS")
        self.assertEqual(data['status'], "ACTIVE")

    @patch('app.api.meta_ads.MetaAdsService')
    def test_create_adset(self, mock_meta_ads_service):
        """Test that an ad set can be created via API"""
        # Set up mock
        mock_instance = MockMetaAdsService()
        mock_meta_ads_service.return_value = mock_instance

        # Create a campaign first
        campaign = mock_instance.create_campaign(
            name="Test Campaign",
            objective="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )

        # Make request
        targeting = {
            "age_min": 25,
            "age_max": 45,
            "genders": [1, 2],
            "geo_locations": {
                "countries": ["US"]
            },
            "interests": [
                {"id": "6003139266461", "name": "Fitness"}
            ]
        }
        response = self.app.post('/api/meta-ads/create-adset',
                                json={
                                    "campaign_id": campaign["id"],
                                    "name": "Test Ad Set",
                                    "targeting": targeting,
                                    "optimization_goal": "CONVERSIONS",
                                    "status": "ACTIVE",
                                    "daily_budget": 50.00
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('id', data)
        self.assertIn('name', data)
        self.assertEqual(data['name'], "Test Ad Set")
        self.assertEqual(data['campaign_id'], campaign["id"])
        self.assertEqual(data['optimization_goal'], "CONVERSIONS")
        self.assertEqual(data['status'], "ACTIVE")

    @patch('app.api.meta_ads.MetaAdsService')
    def test_create_ad(self, mock_meta_ads_service):
        """Test that an ad can be created via API"""
        # Set up mock
        mock_instance = MockMetaAdsService()
        mock_meta_ads_service.return_value = mock_instance

        # Create a campaign and ad set first
        campaign = mock_instance.create_campaign(
            name="Test Campaign",
            objective="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )
        targeting = {
            "age_min": 25,
            "age_max": 45,
            "genders": [1, 2],
            "geo_locations": {
                "countries": ["US"]
            }
        }
        adset = mock_instance.create_adset(
            campaign_id=campaign["id"],
            name="Test Ad Set",
            targeting=targeting,
            optimization_goal="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )

        # Make request
        creative = {
            "title": "Test Ad",
            "body": "This is a test ad",
            "image_hash": "image_hash_12345678",
            "link_url": "https://www.example.com",
            "call_to_action_type": "SHOP_NOW"
        }
        response = self.app.post('/api/meta-ads/create-ad',
                                json={
                                    "adset_id": adset["id"],
                                    "name": "Test Ad",
                                    "creative": creative,
                                    "status": "ACTIVE"
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('id', data)
        self.assertIn('name', data)
        self.assertEqual(data['name'], "Test Ad")
        self.assertEqual(data['adset_id'], adset["id"])
        self.assertEqual(data['status'], "ACTIVE")

    @patch('app.api.meta_ads.MetaAdsService')
    def test_create_bulk_ads(self, mock_meta_ads_service):
        """Test that multiple ads can be created in bulk via API"""
        # Set up mock
        mock_instance = MockMetaAdsService()
        mock_meta_ads_service.return_value = mock_instance

        # Make request
        ads_data = [
            {
                "campaign": {
                    "name": "Summer Sale",
                    "objective": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 50.00
                },
                "adset": {
                    "name": "US - Mobile",
                    "targeting": {
                        "age_min": 25,
                        "age_max": 45,
                        "genders": [1, 2],
                        "geo_locations": {
                            "countries": ["US"]
                        }
                    },
                    "optimization_goal": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 50.00
                },
                "name": "Summer Sale - Image 1",
                "creative": {
                    "title": "Summer Sale - Up to 50% Off",
                    "body": "Don't miss our biggest sale of the year! Limited time only.",
                    "image_hash": "image_hash_12345678",
                    "link_url": "https://www.example.com/summer-sale",
                    "call_to_action_type": "SHOP_NOW"
                },
                "status": "ACTIVE"
            },
            {
                "campaign": {
                    "name": "Winter Collection",
                    "objective": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 75.00
                },
                "adset": {
                    "name": "EU - Desktop",
                    "targeting": {
                        "age_min": 25,
                        "age_max": 45,
                        "genders": [1, 2],
                        "geo_locations": {
                            "countries": ["GB", "DE", "FR"]
                        }
                    },
                    "optimization_goal": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 75.00
                },
                "name": "Winter Collection - Video 1",
                "creative": {
                    "title": "New Winter Collection Available Now",
                    "body": "Stay warm and stylish with our new winter collection. Premium quality at affordable prices.",
                    "image_hash": "image_hash_87654321",
                    "link_url": "https://www.example.com/winter-collection",
                    "call_to_action_type": "LEARN_MORE"
                },
                "status": "ACTIVE"
            }
        ]
        response = self.app.post('/api/meta-ads/create-bulk',
                                json={"ads_data": ads_data},
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('total_count', data)
        self.assertIn('success_count', data)
        self.assertIn('failed_count', data)
        self.assertIn('successful_ads', data)
        self.assertIn('failed_ads', data)
        self.assertEqual(data['total_count'], 2)
        self.assertEqual(data['success_count'], 2)
        self.assertEqual(data['failed_count'], 0)
        self.assertEqual(len(data['successful_ads']), 2)
        self.assertEqual(len(data['failed_ads']), 0)

    @patch('app.api.integrations.IntegrationService')
    def test_google_sheets_read(self, mock_integration_service):
        """Test that data can be read from Google Sheets via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Connect to Google Sheets
        mock_instance.connect_google_sheets("test_sheet_id")

        # Make request
        response = self.app.post('/api/integrations/google-sheets/read',
                                json={
                                    "sheet_id": "test_sheet_id",
                                    "sheet_range": "Sheet1!A1:Z100"
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('data', data)
        self.assertEqual(len(data['data']), 2)
        self.assertEqual(data['data'][0]['campaign_name'], "Summer Sale")
        self.assertEqual(data['data'][1]['campaign_name'], "Winter Collection")

    @patch('app.api.integrations.IntegrationService')
    def test_google_sheets_write(self, mock_integration_service):
        """Test that data can be written to Google Sheets via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Connect to Google Sheets
        mock_instance.connect_google_sheets("test_sheet_id")

        # Make request
        data = [
            ["campaign_name", "adset_name", "ad_name"],
            ["Summer Sale", "US - Mobile", "Summer Sale - Image 1"],
            ["Winter Collection", "EU - Desktop", "Winter Collection - Video 1"]
        ]
        response = self.app.post('/api/integrations/google-sheets/write',
                                json={
                                    "sheet_id": "test_sheet_id",
                                    "sheet_range": "Sheet1!A1",
                                    "data": data
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('success', data)
        self.assertTrue(data['success'])

    @patch('app.api.integrations.IntegrationService')
    def test_airtable_read(self, mock_integration_service):
        """Test that data can be read from Airtable via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Connect to Airtable
        mock_instance.connect_airtable("test_base_id")

        # Make request
        response = self.app.post('/api/integrations/airtable/read',
                                json={
                                    "base_id": "test_base_id",
                                    "table_name": "Ads"
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('records', data)
        self.assertEqual(len(data['records']), 2)
        self.assertEqual(data['records'][0]['fields']['campaign_name'], "Summer Sale")
        self.assertEqual(data['records'][1]['fields']['campaign_name'], "Winter Collection")

    @patch('app.api.integrations.IntegrationService')
    def test_airtable_create(self, mock_integration_service):
        """Test that records can be created in Airtable via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Connect to Airtable
        mock_instance.connect_airtable("test_base_id")

        # Make request
        records = [
            {"campaign_name": "Summer Sale", "adset_name": "US - Mobile", "ad_name": "Summer Sale - Image 1"},
            {"campaign_name": "Winter Collection", "adset_name": "EU - Desktop", "ad_name": "Winter Collection - Video 1"}
        ]
        response = self.app.post('/api/integrations/airtable/create',
                                json={
                                    "base_id": "test_base_id",
                                    "table_name": "Ads",
                                    "records": records
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('records', data)
        self.assertEqual(len(data['records']), 2)
        self.assertIn('id', data['records'][0])
        self.assertIn('fields', data['records'][0])
        self.assertEqual(data['records'][0]['fields']['campaign_name'], "Summer Sale")
        self.assertEqual(data['records'][1]['fields']['campaign_name'], "Winter Collection")

    @patch('app.api.integrations.IntegrationService')
    def test_n8n_webhook(self, mock_integration_service):
        """Test that n8n webhook can be triggered via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request
        payload = {"event": "ad_created", "ad_id": "23123456789012345"}
        response = self.app.post('/api/integrations/n8n/webhook',
                                json={
                                    "webhook_url": "https://n8n.example.com/webhook/test",
                                    "payload": payload
                                },
                                content_type='application/json')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('status', data)
        self.assertEqual(data['status'], "ok")
        self.assertIn('execution_id', data)
        self.assertIn('message', data)

    @patch('app.api.integrations.IntegrationService')
    def test_csv_import(self, mock_integration_service):
        """Test that data can be imported from a CSV file via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request with CSV data as string (for testing)
        csv_data = 'campaign_name,adset_name,ad_name\nSummer Sale,US - Mobile,Summer Sale - Image 1\nWinter Collection,EU - Desktop,Winter Collection - Video 1'
        response = self.app.post('/api/integrations/csv/import',
                                data={
                                    'file': (csv_data, 'test.csv'),
                                    'import_type': 'ads'
                                },
                                content_type='multipart/form-data')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('rows_imported', data)
        self.assertEqual(data['rows_imported'], 2)
        self.assertIn('message', data)

    @patch('app.api.integrations.IntegrationService')
    def test_csv_export(self, mock_integration_service):
        """Test that data can be exported to a CSV file via API"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request
        response = self.app.get('/api/integrations/csv/export?export_type=ads')
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'text/csv')
        self.assertIn('campaign_name,adset_name,ad_name', response.data.decode('utf-8'))
        self.assertIn('Summer Sale,US - Mobile,Summer Sale - Image 1', response.data.decode('utf-8'))
        self.assertIn('Winter Collection,EU - Desktop,Winter Collection - Video 1', response.data.decode('utf-8'))

if __name__ == '__main__':
    unittest.main()

