"""
Tests for Meta Ads service
"""

import unittest
from unittest.mock import patch, MagicMock
from app.services.meta_ads_service import MetaAdsService

class TestMetaAdsService(unittest.TestCase):
    """Test cases for Meta Ads service"""

    def setUp(self):
        """Set up test fixtures"""
        self.access_token = "test_access_token"
        self.ad_account_id = "act_123456789"

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    def test_initialization(self, mock_api):
        """Test that the service can be initialized with valid access token"""
        # Create service
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        
        # Verify that the API was initialized with the correct parameters
        mock_api.init.assert_called_once_with(access_token=self.access_token)
        self.assertEqual(service.ad_account_id, self.ad_account_id)

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_create_campaign(self, mock_ad_account, mock_api):
        """Test that a campaign can be created"""
        # Set up mock response
        mock_campaign = MagicMock()
        mock_campaign.api_create.return_value = {"id": "23123456789012345"}
        mock_ad_account.return_value.create_campaign.return_value = mock_campaign

        # Create service and campaign
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        campaign = service.create_campaign(
            name="Test Campaign",
            objective="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )

        # Verify that the campaign was created with the correct parameters
        mock_ad_account.assert_called_once_with(self.ad_account_id)
        mock_ad_account.return_value.create_campaign.assert_called_once()
        args, kwargs = mock_ad_account.return_value.create_campaign.call_args
        self.assertEqual(kwargs['fields'], ['id', 'name', 'objective', 'status'])
        self.assertEqual(kwargs['params']['name'], "Test Campaign")
        self.assertEqual(kwargs['params']['objective'], "CONVERSIONS")
        self.assertEqual(kwargs['params']['status'], "ACTIVE")
        self.assertEqual(kwargs['params']['daily_budget'], 5000)  # In cents

        # Verify that the campaign ID was returned
        self.assertEqual(campaign["id"], "23123456789012345")

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_create_adset(self, mock_ad_account, mock_api):
        """Test that an ad set can be created"""
        # Set up mock response
        mock_adset = MagicMock()
        mock_adset.api_create.return_value = {"id": "23123456789012345"}
        mock_ad_account.return_value.create_ad_set.return_value = mock_adset

        # Create service and ad set
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        targeting = {
            "age_min": 25,
            "age_max": 45,
            "genders": [1, 2],
            "geo_locations": {
                "countries": ["US"]
            },
            "interests": [
                {"id": "6003139266461", "name": "Fitness"}
            ]
        }
        adset = service.create_adset(
            campaign_id="23123456789012345",
            name="Test Ad Set",
            targeting=targeting,
            optimization_goal="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )

        # Verify that the ad set was created with the correct parameters
        mock_ad_account.assert_called_once_with(self.ad_account_id)
        mock_ad_account.return_value.create_ad_set.assert_called_once()
        args, kwargs = mock_ad_account.return_value.create_ad_set.call_args
        self.assertEqual(kwargs['fields'], ['id', 'name', 'campaign_id', 'targeting', 'optimization_goal', 'status'])
        self.assertEqual(kwargs['params']['name'], "Test Ad Set")
        self.assertEqual(kwargs['params']['campaign_id'], "23123456789012345")
        self.assertEqual(kwargs['params']['targeting'], targeting)
        self.assertEqual(kwargs['params']['optimization_goal'], "CONVERSIONS")
        self.assertEqual(kwargs['params']['status'], "ACTIVE")
        self.assertEqual(kwargs['params']['daily_budget'], 5000)  # In cents

        # Verify that the ad set ID was returned
        self.assertEqual(adset["id"], "23123456789012345")

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_create_ad(self, mock_ad_account, mock_api):
        """Test that an ad can be created"""
        # Set up mock response
        mock_ad = MagicMock()
        mock_ad.api_create.return_value = {"id": "23123456789012345"}
        mock_ad_account.return_value.create_ad.return_value = mock_ad

        # Create service and ad
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        creative = {
            "title": "Test Ad",
            "body": "This is a test ad",
            "image_hash": "image_hash_12345678",
            "link_url": "https://www.example.com",
            "call_to_action_type": "SHOP_NOW"
        }
        ad = service.create_ad(
            adset_id="23123456789012345",
            name="Test Ad",
            creative=creative,
            status="ACTIVE"
        )

        # Verify that the ad was created with the correct parameters
        mock_ad_account.assert_called_once_with(self.ad_account_id)
        mock_ad_account.return_value.create_ad.assert_called_once()
        args, kwargs = mock_ad_account.return_value.create_ad.call_args
        self.assertEqual(kwargs['fields'], ['id', 'name', 'adset_id', 'status'])
        self.assertEqual(kwargs['params']['name'], "Test Ad")
        self.assertEqual(kwargs['params']['adset_id'], "23123456789012345")
        self.assertEqual(kwargs['params']['status'], "ACTIVE")
        self.assertIn('creative', kwargs['params'])

        # Verify that the ad ID was returned
        self.assertEqual(ad["id"], "23123456789012345")

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_upload_image(self, mock_ad_account, mock_api):
        """Test that an image can be uploaded"""
        # Set up mock response
        mock_image = MagicMock()
        mock_image.api_create.return_value = {"hash": "image_hash_12345678", "url": "https://www.facebook.com/images/image_hash_12345678.jpg"}
        mock_ad_account.return_value.create_ad_image.return_value = mock_image

        # Create service and upload image
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        image_result = service.upload_image("/path/to/image.jpg")

        # Verify that the image was uploaded with the correct parameters
        mock_ad_account.assert_called_once_with(self.ad_account_id)
        mock_ad_account.return_value.create_ad_image.assert_called_once()
        args, kwargs = mock_ad_account.return_value.create_ad_image.call_args
        self.assertEqual(kwargs['fields'], ['hash', 'url'])
        self.assertIn('filename', kwargs['params'])

        # Verify that the image hash and URL were returned
        self.assertEqual(image_result["hash"], "image_hash_12345678")
        self.assertEqual(image_result["url"], "https://www.facebook.com/images/image_hash_12345678.jpg")

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_create_bulk_ads(self, mock_ad_account, mock_api):
        """Test that multiple ads can be created in bulk"""
        # Set up mock responses
        mock_campaign = MagicMock()
        mock_campaign.api_create.return_value = {"id": "23123456789012345"}
        mock_ad_account.return_value.create_campaign.return_value = mock_campaign

        mock_adset = MagicMock()
        mock_adset.api_create.return_value = {"id": "23234567890123456"}
        mock_ad_account.return_value.create_ad_set.return_value = mock_adset

        mock_ad = MagicMock()
        mock_ad.api_create.return_value = {"id": "23345678901234567"}
        mock_ad_account.return_value.create_ad.return_value = mock_ad

        # Create service and bulk ads
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        ads_data = [
            {
                "campaign": {
                    "name": "Summer Sale",
                    "objective": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 50.00
                },
                "adset": {
                    "name": "US - Mobile",
                    "targeting": {
                        "age_min": 25,
                        "age_max": 45,
                        "genders": [1, 2],
                        "geo_locations": {
                            "countries": ["US"]
                        }
                    },
                    "optimization_goal": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 50.00
                },
                "name": "Summer Sale - Image 1",
                "creative": {
                    "title": "Summer Sale - Up to 50% Off",
                    "body": "Don't miss our biggest sale of the year! Limited time only.",
                    "image_hash": "image_hash_12345678",
                    "link_url": "https://www.example.com/summer-sale",
                    "call_to_action_type": "SHOP_NOW"
                },
                "status": "ACTIVE"
            },
            {
                "campaign": {
                    "name": "Winter Collection",
                    "objective": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 75.00
                },
                "adset": {
                    "name": "EU - Desktop",
                    "targeting": {
                        "age_min": 25,
                        "age_max": 45,
                        "genders": [1, 2],
                        "geo_locations": {
                            "countries": ["GB", "DE", "FR"]
                        }
                    },
                    "optimization_goal": "CONVERSIONS",
                    "status": "ACTIVE",
                    "daily_budget": 75.00
                },
                "name": "Winter Collection - Video 1",
                "creative": {
                    "title": "New Winter Collection Available Now",
                    "body": "Stay warm and stylish with our new winter collection. Premium quality at affordable prices.",
                    "image_hash": "image_hash_87654321",
                    "link_url": "https://www.example.com/winter-collection",
                    "call_to_action_type": "LEARN_MORE"
                },
                "status": "ACTIVE"
            }
        ]
        results = service.create_bulk_ads(ads_data)

        # Verify that the campaigns, ad sets, and ads were created
        self.assertEqual(mock_ad_account.return_value.create_campaign.call_count, 2)
        self.assertEqual(mock_ad_account.return_value.create_ad_set.call_count, 2)
        self.assertEqual(mock_ad_account.return_value.create_ad.call_count, 2)

        # Verify that the results were returned correctly
        self.assertEqual(results["total_count"], 2)
        self.assertEqual(results["success_count"], 2)
        self.assertEqual(results["failed_count"], 0)
        self.assertEqual(len(results["successful_ads"]), 2)
        self.assertEqual(len(results["failed_ads"]), 0)

    @patch('app.services.meta_ads_service.facebook_business.api.FacebookAdsApi')
    @patch('app.services.meta_ads_service.AdAccount')
    def test_error_handling(self, mock_ad_account, mock_api):
        """Test that errors are handled properly"""
        # Set up mock to raise an exception
        mock_ad_account.return_value.create_campaign.side_effect = Exception("API Error")

        # Create service and try to create a campaign
        service = MetaAdsService(access_token=self.access_token, ad_account_id=self.ad_account_id)
        
        # Verify that the error is caught and None is returned
        campaign = service.create_campaign(
            name="Test Campaign",
            objective="CONVERSIONS",
            status="ACTIVE",
            daily_budget=50.00
        )
        self.assertIsNone(campaign)

if __name__ == '__main__':
    unittest.main()

