"""
Mock OpenAI service for testing
"""

class MockOpenAIService:
    """Mock implementation of the OpenAIService for testing"""

    def __init__(self, api_key=None):
        """Initialize the mock service"""
        self.api_key = api_key or "mock_api_key"
        self.calls = []

    def generate_headlines(self, product_info, tone="professional", platform="facebook", num_variations=3):
        """
        Mock method to generate ad headlines
        
        Args:
            product_info (dict): Information about the product
            tone (str): Tone of the headlines
            platform (str): Platform for the headlines
            num_variations (int): Number of headline variations to generate
            
        Returns:
            list: List of generated headlines
        """
        self.calls.append({
            "method": "generate_headlines",
            "product_info": product_info,
            "tone": tone,
            "platform": platform,
            "num_variations": num_variations
        })
        
        # Return mock headlines based on the product name
        product_name = product_info.get("name", "Product")
        headlines = []
        
        for i in range(num_variations):
            if tone == "professional":
                headlines.append(f"Introducing the New {product_name}")
            elif tone == "friendly":
                headlines.append(f"Meet Your New Favorite {product_name}")
            elif tone == "casual":
                headlines.append(f"Check Out This Amazing {product_name}")
            elif tone == "humorous":
                headlines.append(f"You Won't Believe This {product_name}")
            elif tone == "urgent":
                headlines.append(f"Limited Time Offer: {product_name}")
            elif tone == "inspirational":
                headlines.append(f"Transform Your Life with {product_name}")
            else:
                headlines.append(f"New {product_name} Available Now")
        
        return headlines

    def generate_primary_text(self, product_info, tone="professional", platform="facebook", num_variations=3):
        """
        Mock method to generate ad primary text
        
        Args:
            product_info (dict): Information about the product
            tone (str): Tone of the primary text
            platform (str): Platform for the primary text
            num_variations (int): Number of primary text variations to generate
            
        Returns:
            list: List of generated primary text
        """
        self.calls.append({
            "method": "generate_primary_text",
            "product_info": product_info,
            "tone": tone,
            "platform": platform,
            "num_variations": num_variations
        })
        
        # Return mock primary text based on the product description and USPs
        product_name = product_info.get("name", "Product")
        product_description = product_info.get("description", "A great product")
        usps = product_info.get("unique_selling_points", [])
        cta = product_info.get("call_to_action", "Buy Now")
        
        primary_texts = []
        
        for i in range(num_variations):
            usp_text = ""
            if usps and i < len(usps):
                usp_text = f" {usps[i]}."
            
            if tone == "professional":
                primary_texts.append(f"{product_description}.{usp_text} {cta} today and experience the difference.")
            elif tone == "friendly":
                primary_texts.append(f"We think you'll love our {product_name}! {product_description}.{usp_text} {cta} and see for yourself!")
            elif tone == "casual":
                primary_texts.append(f"Hey there! Check out our {product_name}. {product_description}.{usp_text} Why not {cta.lower()} today?")
            elif tone == "humorous":
                primary_texts.append(f"Life's too short for boring products! Our {product_name} is different. {product_description}.{usp_text} {cta} before they're gone!")
            elif tone == "urgent":
                primary_texts.append(f"Don't miss out! {product_description}.{usp_text} Limited stock available. {cta} now!")
            elif tone == "inspirational":
                primary_texts.append(f"Imagine a better way. {product_description}.{usp_text} Start your journey today. {cta}.")
            else:
                primary_texts.append(f"{product_description}.{usp_text} {cta}.")
        
        return primary_texts

    def generate_descriptions(self, product_info, tone="professional", platform="facebook", num_variations=3):
        """
        Mock method to generate ad descriptions
        
        Args:
            product_info (dict): Information about the product
            tone (str): Tone of the descriptions
            platform (str): Platform for the descriptions
            num_variations (int): Number of description variations to generate
            
        Returns:
            list: List of generated descriptions
        """
        self.calls.append({
            "method": "generate_descriptions",
            "product_info": product_info,
            "tone": tone,
            "platform": platform,
            "num_variations": num_variations
        })
        
        # Return mock descriptions based on the product name
        product_name = product_info.get("name", "Product")
        descriptions = []
        
        for i in range(num_variations):
            if tone == "professional":
                descriptions.append(f"Quality {product_name} for professionals")
            elif tone == "friendly":
                descriptions.append(f"Your favorite new {product_name}")
            elif tone == "casual":
                descriptions.append(f"Cool {product_name} for everyone")
            elif tone == "humorous":
                descriptions.append(f"The {product_name} you'll love")
            elif tone == "urgent":
                descriptions.append(f"Limited offer on {product_name}")
            elif tone == "inspirational":
                descriptions.append(f"Transform with {product_name}")
            else:
                descriptions.append(f"New {product_name}")
        
        return descriptions

