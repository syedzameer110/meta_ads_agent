"""
Mock Meta Ads service for testing
"""

import uuid
import time

class MockMetaAdsService:
    """Mock implementation of the MetaAdsService for testing"""

    def __init__(self, access_token=None):
        """Initialize the mock service"""
        self.access_token = access_token or "mock_access_token"
        self.calls = []
        self.campaigns = {}
        self.adsets = {}
        self.ads = {}

    def create_campaign(self, name, objective, status="ACTIVE", daily_budget=None, lifetime_budget=None, start_time=None, end_time=None):
        """
        Mock method to create a campaign
        
        Args:
            name (str): Campaign name
            objective (str): Campaign objective
            status (str): Campaign status
            daily_budget (float): Daily budget in USD
            lifetime_budget (float): Lifetime budget in USD
            start_time (str): Start time in ISO format
            end_time (str): End time in ISO format
            
        Returns:
            dict: Created campaign object
        """
        self.calls.append({
            "method": "create_campaign",
            "name": name,
            "objective": objective,
            "status": status,
            "daily_budget": daily_budget,
            "lifetime_budget": lifetime_budget,
            "start_time": start_time,
            "end_time": end_time
        })
        
        # Generate a mock campaign ID
        campaign_id = f"23{uuid.uuid4().hex[:16]}"
        
        # Create a mock campaign object
        campaign = {
            "id": campaign_id,
            "name": name,
            "objective": objective,
            "status": status,
            "created_time": time.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "start_time": start_time or time.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "end_time": end_time,
            "daily_budget": daily_budget,
            "lifetime_budget": lifetime_budget
        }
        
        # Store the campaign
        self.campaigns[campaign_id] = campaign
        
        return campaign

    def create_adset(self, campaign_id, name, targeting, optimization_goal="CONVERSIONS", status="ACTIVE", daily_budget=None, lifetime_budget=None, start_time=None, end_time=None):
        """
        Mock method to create an ad set
        
        Args:
            campaign_id (str): Campaign ID
            name (str): Ad set name
            targeting (dict): Targeting specifications
            optimization_goal (str): Optimization goal
            status (str): Ad set status
            daily_budget (float): Daily budget in USD
            lifetime_budget (float): Lifetime budget in USD
            start_time (str): Start time in ISO format
            end_time (str): End time in ISO format
            
        Returns:
            dict: Created ad set object
        """
        self.calls.append({
            "method": "create_adset",
            "campaign_id": campaign_id,
            "name": name,
            "targeting": targeting,
            "optimization_goal": optimization_goal,
            "status": status,
            "daily_budget": daily_budget,
            "lifetime_budget": lifetime_budget,
            "start_time": start_time,
            "end_time": end_time
        })
        
        # Check if the campaign exists
        if campaign_id not in self.campaigns:
            raise ValueError(f"Campaign with ID {campaign_id} not found")
        
        # Generate a mock ad set ID
        adset_id = f"23{uuid.uuid4().hex[:16]}"
        
        # Create a mock ad set object
        adset = {
            "id": adset_id,
            "name": name,
            "campaign_id": campaign_id,
            "targeting": targeting,
            "optimization_goal": optimization_goal,
            "status": status,
            "created_time": time.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "start_time": start_time or time.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "end_time": end_time,
            "daily_budget": daily_budget,
            "lifetime_budget": lifetime_budget
        }
        
        # Store the ad set
        self.adsets[adset_id] = adset
        
        return adset

    def create_ad(self, adset_id, name, creative, status="ACTIVE"):
        """
        Mock method to create an ad
        
        Args:
            adset_id (str): Ad set ID
            name (str): Ad name
            creative (dict): Ad creative
            status (str): Ad status
            
        Returns:
            dict: Created ad object
        """
        self.calls.append({
            "method": "create_ad",
            "adset_id": adset_id,
            "name": name,
            "creative": creative,
            "status": status
        })
        
        # Check if the ad set exists
        if adset_id not in self.adsets:
            raise ValueError(f"Ad set with ID {adset_id} not found")
        
        # Generate a mock ad ID
        ad_id = f"23{uuid.uuid4().hex[:16]}"
        
        # Create a mock ad object
        ad = {
            "id": ad_id,
            "name": name,
            "adset_id": adset_id,
            "creative": creative,
            "status": status,
            "created_time": time.strftime("%Y-%m-%dT%H:%M:%S+0000"),
            "preview_url": f"https://www.facebook.com/ads/archive/render_ad/?id={ad_id}"
        }
        
        # Store the ad
        self.ads[ad_id] = ad
        
        return ad

    def upload_image(self, image_path):
        """
        Mock method to upload an image
        
        Args:
            image_path (str): Path to the image file
            
        Returns:
            dict: Image hash and URL
        """
        self.calls.append({
            "method": "upload_image",
            "image_path": image_path
        })
        
        # Generate a mock image hash
        image_hash = f"image_hash_{uuid.uuid4().hex[:8]}"
        
        return {
            "hash": image_hash,
            "url": f"https://www.facebook.com/images/{image_hash}.jpg"
        }

    def get_campaign(self, campaign_id):
        """
        Mock method to get a campaign
        
        Args:
            campaign_id (str): Campaign ID
            
        Returns:
            dict: Campaign object
        """
        self.calls.append({
            "method": "get_campaign",
            "campaign_id": campaign_id
        })
        
        if campaign_id not in self.campaigns:
            raise ValueError(f"Campaign with ID {campaign_id} not found")
        
        return self.campaigns[campaign_id]

    def get_adset(self, adset_id):
        """
        Mock method to get an ad set
        
        Args:
            adset_id (str): Ad set ID
            
        Returns:
            dict: Ad set object
        """
        self.calls.append({
            "method": "get_adset",
            "adset_id": adset_id
        })
        
        if adset_id not in self.adsets:
            raise ValueError(f"Ad set with ID {adset_id} not found")
        
        return self.adsets[adset_id]

    def get_ad(self, ad_id):
        """
        Mock method to get an ad
        
        Args:
            ad_id (str): Ad ID
            
        Returns:
            dict: Ad object
        """
        self.calls.append({
            "method": "get_ad",
            "ad_id": ad_id
        })
        
        if ad_id not in self.ads:
            raise ValueError(f"Ad with ID {ad_id} not found")
        
        return self.ads[ad_id]

    def create_bulk_ads(self, ads_data):
        """
        Mock method to create multiple ads in bulk
        
        Args:
            ads_data (list): List of ad data objects
            
        Returns:
            dict: Results of bulk creation
        """
        self.calls.append({
            "method": "create_bulk_ads",
            "ads_data": ads_data
        })
        
        results = {
            "total_count": len(ads_data),
            "success_count": 0,
            "failed_count": 0,
            "successful_ads": [],
            "failed_ads": []
        }
        
        for i, ad_data in enumerate(ads_data):
            try:
                # Create campaign if needed
                if "campaign" in ad_data:
                    campaign = self.create_campaign(
                        name=ad_data["campaign"]["name"],
                        objective=ad_data["campaign"]["objective"],
                        status=ad_data["campaign"].get("status", "ACTIVE"),
                        daily_budget=ad_data["campaign"].get("daily_budget"),
                        lifetime_budget=ad_data["campaign"].get("lifetime_budget"),
                        start_time=ad_data["campaign"].get("start_time"),
                        end_time=ad_data["campaign"].get("end_time")
                    )
                    campaign_id = campaign["id"]
                else:
                    campaign_id = ad_data["campaign_id"]
                
                # Create ad set if needed
                if "adset" in ad_data:
                    adset = self.create_adset(
                        campaign_id=campaign_id,
                        name=ad_data["adset"]["name"],
                        targeting=ad_data["adset"]["targeting"],
                        optimization_goal=ad_data["adset"].get("optimization_goal", "CONVERSIONS"),
                        status=ad_data["adset"].get("status", "ACTIVE"),
                        daily_budget=ad_data["adset"].get("daily_budget"),
                        lifetime_budget=ad_data["adset"].get("lifetime_budget"),
                        start_time=ad_data["adset"].get("start_time"),
                        end_time=ad_data["adset"].get("end_time")
                    )
                    adset_id = adset["id"]
                else:
                    adset_id = ad_data["adset_id"]
                
                # Create ad
                ad = self.create_ad(
                    adset_id=adset_id,
                    name=ad_data["name"],
                    creative=ad_data["creative"],
                    status=ad_data.get("status", "ACTIVE")
                )
                
                results["success_count"] += 1
                results["successful_ads"].append({
                    "index": i,
                    "ad_id": ad["id"],
                    "name": ad["name"]
                })
            except Exception as e:
                results["failed_count"] += 1
                results["failed_ads"].append({
                    "index": i,
                    "error": str(e)
                })
        
        return results

