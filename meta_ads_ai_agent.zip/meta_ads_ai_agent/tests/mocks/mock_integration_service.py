"""
Mock Integration service for testing
"""

import uuid
import time
import json
import csv
import io

class MockIntegrationService:
    """Mock implementation of the IntegrationService for testing"""

    def __init__(self):
        """Initialize the mock service"""
        self.calls = []
        self.google_sheets_data = {}
        self.airtable_data = {}
        self.n8n_webhooks = {}
        self.csv_data = {}

    def connect_google_sheets(self, sheet_id, credentials=None):
        """
        Mock method to connect to Google Sheets
        
        Args:
            sheet_id (str): Google Sheet ID
            credentials (dict): Google API credentials
            
        Returns:
            bool: True if connection is successful
        """
        self.calls.append({
            "method": "connect_google_sheets",
            "sheet_id": sheet_id,
            "credentials": credentials
        })
        
        # Initialize sheet data if it doesn't exist
        if sheet_id not in self.google_sheets_data:
            self.google_sheets_data[sheet_id] = {
                "Sheet1": [
                    ["campaign_name", "adset_name", "ad_name", "headline", "primary_text", "description", "website_url", "call_to_action"],
                    ["Summer Sale", "US - Mobile", "Summer Sale - Image 1", "Summer Sale - Up to 50% Off", "Don't miss our biggest sale of the year! Limited time only.", "Free shipping on all orders", "https://www.example.com/summer-sale", "SHOP_NOW"],
                    ["Winter Collection", "EU - Desktop", "Winter Collection - Video 1", "New Winter Collection Available Now", "Stay warm and stylish with our new winter collection. Premium quality at affordable prices.", "Free returns within 30 days", "https://www.example.com/winter-collection", "LEARN_MORE"]
                ]
            }
        
        return True

    def read_google_sheets(self, sheet_id, sheet_range):
        """
        Mock method to read data from Google Sheets
        
        Args:
            sheet_id (str): Google Sheet ID
            sheet_range (str): Range to read (e.g., "Sheet1!A1:Z100")
            
        Returns:
            list: List of rows
        """
        self.calls.append({
            "method": "read_google_sheets",
            "sheet_id": sheet_id,
            "sheet_range": sheet_range
        })
        
        # Check if sheet exists
        if sheet_id not in self.google_sheets_data:
            raise ValueError(f"Sheet with ID {sheet_id} not found")
        
        # Parse sheet range
        sheet_name = "Sheet1"
        if "!" in sheet_range:
            sheet_name, cell_range = sheet_range.split("!")
        
        # Check if sheet name exists
        if sheet_name not in self.google_sheets_data[sheet_id]:
            raise ValueError(f"Sheet {sheet_name} not found in sheet with ID {sheet_id}")
        
        # Get data
        data = self.google_sheets_data[sheet_id][sheet_name]
        
        # Convert to list of dictionaries
        if len(data) > 1:
            headers = data[0]
            rows = []
            for row_data in data[1:]:
                row = {}
                for i, header in enumerate(headers):
                    if i < len(row_data):
                        row[header] = row_data[i]
                    else:
                        row[header] = ""
                rows.append(row)
            return rows
        
        return []

    def write_google_sheets(self, sheet_id, sheet_range, data):
        """
        Mock method to write data to Google Sheets
        
        Args:
            sheet_id (str): Google Sheet ID
            sheet_range (str): Range to write (e.g., "Sheet1!A1")
            data (list): List of rows to write
            
        Returns:
            dict: Result of the write operation
        """
        self.calls.append({
            "method": "write_google_sheets",
            "sheet_id": sheet_id,
            "sheet_range": sheet_range,
            "data": data
        })
        
        # Initialize sheet data if it doesn't exist
        if sheet_id not in self.google_sheets_data:
            self.google_sheets_data[sheet_id] = {}
        
        # Parse sheet range
        sheet_name = "Sheet1"
        if "!" in sheet_range:
            sheet_name, cell_range = sheet_range.split("!")
        
        # Initialize sheet if it doesn't exist
        if sheet_name not in self.google_sheets_data[sheet_id]:
            self.google_sheets_data[sheet_id][sheet_name] = []
        
        # Write data
        self.google_sheets_data[sheet_id][sheet_name] = data
        
        return {
            "spreadsheetId": sheet_id,
            "updatedRange": sheet_range,
            "updatedRows": len(data),
            "updatedColumns": len(data[0]) if data else 0,
            "updatedCells": len(data) * len(data[0]) if data else 0
        }

    def append_google_sheets(self, sheet_id, sheet_range, data):
        """
        Mock method to append data to Google Sheets
        
        Args:
            sheet_id (str): Google Sheet ID
            sheet_range (str): Range to append (e.g., "Sheet1!A1")
            data (list): List of rows to append
            
        Returns:
            dict: Result of the append operation
        """
        self.calls.append({
            "method": "append_google_sheets",
            "sheet_id": sheet_id,
            "sheet_range": sheet_range,
            "data": data
        })
        
        # Initialize sheet data if it doesn't exist
        if sheet_id not in self.google_sheets_data:
            self.google_sheets_data[sheet_id] = {}
        
        # Parse sheet range
        sheet_name = "Sheet1"
        if "!" in sheet_range:
            sheet_name, cell_range = sheet_range.split("!")
        
        # Initialize sheet if it doesn't exist
        if sheet_name not in self.google_sheets_data[sheet_id]:
            self.google_sheets_data[sheet_id][sheet_name] = []
        
        # Append data
        self.google_sheets_data[sheet_id][sheet_name].extend(data)
        
        return {
            "spreadsheetId": sheet_id,
            "updatedRange": sheet_range,
            "updatedRows": len(data),
            "updatedColumns": len(data[0]) if data else 0,
            "updatedCells": len(data) * len(data[0]) if data else 0
        }

    def connect_airtable(self, base_id, api_key=None):
        """
        Mock method to connect to Airtable
        
        Args:
            base_id (str): Airtable base ID
            api_key (str): Airtable API key
            
        Returns:
            bool: True if connection is successful
        """
        self.calls.append({
            "method": "connect_airtable",
            "base_id": base_id,
            "api_key": api_key
        })
        
        # Initialize base data if it doesn't exist
        if base_id not in self.airtable_data:
            self.airtable_data[base_id] = {
                "Ads": [
                    {
                        "id": f"rec{uuid.uuid4().hex[:14]}",
                        "fields": {
                            "campaign_name": "Summer Sale",
                            "adset_name": "US - Mobile",
                            "ad_name": "Summer Sale - Image 1",
                            "headline": "Summer Sale - Up to 50% Off",
                            "primary_text": "Don't miss our biggest sale of the year! Limited time only.",
                            "description": "Free shipping on all orders",
                            "website_url": "https://www.example.com/summer-sale",
                            "call_to_action": "SHOP_NOW"
                        }
                    },
                    {
                        "id": f"rec{uuid.uuid4().hex[:14]}",
                        "fields": {
                            "campaign_name": "Winter Collection",
                            "adset_name": "EU - Desktop",
                            "ad_name": "Winter Collection - Video 1",
                            "headline": "New Winter Collection Available Now",
                            "primary_text": "Stay warm and stylish with our new winter collection. Premium quality at affordable prices.",
                            "description": "Free returns within 30 days",
                            "website_url": "https://www.example.com/winter-collection",
                            "call_to_action": "LEARN_MORE"
                        }
                    }
                ]
            }
        
        return True

    def read_airtable(self, base_id, table_name, view_name=None):
        """
        Mock method to read records from Airtable
        
        Args:
            base_id (str): Airtable base ID
            table_name (str): Table name
            view_name (str): View name
            
        Returns:
            list: List of records
        """
        self.calls.append({
            "method": "read_airtable",
            "base_id": base_id,
            "table_name": table_name,
            "view_name": view_name
        })
        
        # Check if base exists
        if base_id not in self.airtable_data:
            raise ValueError(f"Base with ID {base_id} not found")
        
        # Check if table exists
        if table_name not in self.airtable_data[base_id]:
            raise ValueError(f"Table {table_name} not found in base with ID {base_id}")
        
        # Get records
        records = self.airtable_data[base_id][table_name]
        
        return records

    def create_airtable_records(self, base_id, table_name, records):
        """
        Mock method to create records in Airtable
        
        Args:
            base_id (str): Airtable base ID
            table_name (str): Table name
            records (list): List of records to create
            
        Returns:
            list: List of created records
        """
        self.calls.append({
            "method": "create_airtable_records",
            "base_id": base_id,
            "table_name": table_name,
            "records": records
        })
        
        # Initialize base data if it doesn't exist
        if base_id not in self.airtable_data:
            self.airtable_data[base_id] = {}
        
        # Initialize table if it doesn't exist
        if table_name not in self.airtable_data[base_id]:
            self.airtable_data[base_id][table_name] = []
        
        # Create records
        created_records = []
        for record in records:
            record_id = f"rec{uuid.uuid4().hex[:14]}"
            created_record = {
                "id": record_id,
                "fields": record
            }
            self.airtable_data[base_id][table_name].append(created_record)
            created_records.append(created_record)
        
        return created_records

    def update_airtable_records(self, base_id, table_name, records):
        """
        Mock method to update records in Airtable
        
        Args:
            base_id (str): Airtable base ID
            table_name (str): Table name
            records (list): List of records to update
            
        Returns:
            list: List of updated records
        """
        self.calls.append({
            "method": "update_airtable_records",
            "base_id": base_id,
            "table_name": table_name,
            "records": records
        })
        
        # Check if base exists
        if base_id not in self.airtable_data:
            raise ValueError(f"Base with ID {base_id} not found")
        
        # Check if table exists
        if table_name not in self.airtable_data[base_id]:
            raise ValueError(f"Table {table_name} not found in base with ID {base_id}")
        
        # Update records
        updated_records = []
        for record in records:
            record_id = record.get("id")
            if not record_id:
                raise ValueError("Record ID is required for update")
            
            # Find the record
            found = False
            for i, existing_record in enumerate(self.airtable_data[base_id][table_name]):
                if existing_record["id"] == record_id:
                    # Update the record
                    self.airtable_data[base_id][table_name][i]["fields"].update(record["fields"])
                    updated_records.append(self.airtable_data[base_id][table_name][i])
                    found = True
                    break
            
            if not found:
                raise ValueError(f"Record with ID {record_id} not found")
        
        return updated_records

    def trigger_n8n_webhook(self, webhook_url, payload):
        """
        Mock method to trigger an n8n webhook
        
        Args:
            webhook_url (str): Webhook URL
            payload (dict): Payload to send
            
        Returns:
            dict: Response from the webhook
        """
        self.calls.append({
            "method": "trigger_n8n_webhook",
            "webhook_url": webhook_url,
            "payload": payload
        })
        
        # Store the webhook call
        webhook_id = f"webhook_{uuid.uuid4().hex[:8]}"
        self.n8n_webhooks[webhook_id] = {
            "url": webhook_url,
            "payload": payload,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S+0000")
        }
        
        return {
            "status": "ok",
            "execution_id": webhook_id,
            "message": "Webhook triggered successfully"
        }

    def import_csv(self, csv_file, import_type):
        """
        Mock method to import data from a CSV file
        
        Args:
            csv_file: CSV file object
            import_type (str): Type of data to import
            
        Returns:
            dict: Result of the import operation
        """
        self.calls.append({
            "method": "import_csv",
            "import_type": import_type
        })
        
        # Read CSV data
        if isinstance(csv_file, str):
            # For testing, allow passing a string directly
            csv_data = csv_file
        else:
            # Read from file object
            csv_data = csv_file.read().decode("utf-8")
        
        # Parse CSV
        reader = csv.reader(io.StringIO(csv_data))
        rows = list(reader)
        
        # Store the data
        self.csv_data[import_type] = rows
        
        return {
            "rows_imported": len(rows) - 1 if len(rows) > 0 else 0,
            "message": f"Successfully imported {len(rows) - 1 if len(rows) > 0 else 0} rows"
        }

    def export_csv(self, export_type, date_range=None):
        """
        Mock method to export data to a CSV file
        
        Args:
            export_type (str): Type of data to export
            date_range (str): Date range for the export
            
        Returns:
            str: CSV data
        """
        self.calls.append({
            "method": "export_csv",
            "export_type": export_type,
            "date_range": date_range
        })
        
        # Generate mock data based on export type
        if export_type == "ads":
            data = [
                ["ad_id", "ad_name", "adset_id", "adset_name", "campaign_id", "campaign_name", "status", "created_time"],
                ["23123456789012345", "Summer Sale - Image 1", "23234567890123456", "US - Mobile", "23345678901234567", "Summer Sale", "ACTIVE", "2025-06-01T12:00:00+0000"],
                ["23123456789012346", "Winter Collection - Video 1", "23234567890123457", "EU - Desktop", "23345678901234568", "Winter Collection", "ACTIVE", "2025-06-02T12:00:00+0000"]
            ]
        elif export_type == "campaigns":
            data = [
                ["campaign_id", "campaign_name", "objective", "status", "daily_budget", "lifetime_budget", "start_time", "end_time"],
                ["23345678901234567", "Summer Sale", "CONVERSIONS", "ACTIVE", "50.00", "", "2025-06-01T00:00:00+0000", "2025-06-30T23:59:59+0000"],
                ["23345678901234568", "Winter Collection", "CONVERSIONS", "ACTIVE", "75.00", "", "2025-06-02T00:00:00+0000", "2025-07-02T23:59:59+0000"]
            ]
        elif export_type == "adsets":
            data = [
                ["adset_id", "adset_name", "campaign_id", "campaign_name", "status", "daily_budget", "lifetime_budget", "start_time", "end_time"],
                ["23234567890123456", "US - Mobile", "23345678901234567", "Summer Sale", "ACTIVE", "50.00", "", "2025-06-01T00:00:00+0000", "2025-06-30T23:59:59+0000"],
                ["23234567890123457", "EU - Desktop", "23345678901234568", "Winter Collection", "ACTIVE", "75.00", "", "2025-06-02T00:00:00+0000", "2025-07-02T23:59:59+0000"]
            ]
        elif export_type == "content":
            data = [
                ["headline", "primary_text", "description", "call_to_action"],
                ["Summer Sale - Up to 50% Off", "Don't miss our biggest sale of the year! Limited time only.", "Free shipping on all orders", "SHOP_NOW"],
                ["New Winter Collection Available Now", "Stay warm and stylish with our new winter collection. Premium quality at affordable prices.", "Free returns within 30 days", "LEARN_MORE"]
            ]
        elif export_type == "performance":
            data = [
                ["date", "campaign_id", "campaign_name", "adset_id", "adset_name", "ad_id", "ad_name", "impressions", "clicks", "spend", "conversions"],
                ["2025-06-01", "23345678901234567", "Summer Sale", "23234567890123456", "US - Mobile", "23123456789012345", "Summer Sale - Image 1", "1000", "50", "25.00", "5"],
                ["2025-06-02", "23345678901234567", "Summer Sale", "23234567890123456", "US - Mobile", "23123456789012345", "Summer Sale - Image 1", "1200", "60", "30.00", "6"],
                ["2025-06-01", "23345678901234568", "Winter Collection", "23234567890123457", "EU - Desktop", "23123456789012346", "Winter Collection - Video 1", "800", "40", "20.00", "4"],
                ["2025-06-02", "23345678901234568", "Winter Collection", "23234567890123457", "EU - Desktop", "23123456789012346", "Winter Collection - Video 1", "900", "45", "22.50", "5"]
            ]
        else:
            data = [["No data available for this export type"]]
        
        # Convert to CSV
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerows(data)
        
        return output.getvalue()

