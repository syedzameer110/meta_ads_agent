"""
Tests for project models
"""

import unittest
from app.models.project import Project, ProductInfo

class TestProjectModels(unittest.TestCase):
    """Test cases for project models"""

    def test_product_info_creation(self):
        """Test that a ProductInfo object can be created with valid data"""
        name = "Premium Fitness Tracker"
        description = "Advanced fitness tracker with heart rate monitoring and sleep tracking"
        target_audience = "Health-conscious adults aged 25-45"
        unique_selling_points = [
            "24/7 heart rate monitoring",
            "Water resistant up to 50m",
            "7-day battery life"
        ]
        call_to_action = "Shop Now"

        product_info = ProductInfo(
            name=name,
            description=description,
            target_audience=target_audience,
            unique_selling_points=unique_selling_points,
            call_to_action=call_to_action
        )

        self.assertEqual(product_info.name, name)
        self.assertEqual(product_info.description, description)
        self.assertEqual(product_info.target_audience, target_audience)
        self.assertEqual(product_info.unique_selling_points, unique_selling_points)
        self.assertEqual(product_info.call_to_action, call_to_action)

    def test_product_info_validation(self):
        """Test that ProductInfo validates required fields"""
        # Test with missing name
        with self.assertRaises(ValueError):
            ProductInfo(
                name=None,
                description="Description",
                target_audience="Audience",
                unique_selling_points=["USP1", "USP2"],
                call_to_action="CTA"
            )

        # Test with missing description
        with self.assertRaises(ValueError):
            ProductInfo(
                name="Name",
                description=None,
                target_audience="Audience",
                unique_selling_points=["USP1", "USP2"],
                call_to_action="CTA"
            )

        # Test with missing target_audience
        with self.assertRaises(ValueError):
            ProductInfo(
                name="Name",
                description="Description",
                target_audience=None,
                unique_selling_points=["USP1", "USP2"],
                call_to_action="CTA"
            )

        # Test with missing unique_selling_points
        with self.assertRaises(ValueError):
            ProductInfo(
                name="Name",
                description="Description",
                target_audience="Audience",
                unique_selling_points=None,
                call_to_action="CTA"
            )

        # Test with empty unique_selling_points
        with self.assertRaises(ValueError):
            ProductInfo(
                name="Name",
                description="Description",
                target_audience="Audience",
                unique_selling_points=[],
                call_to_action="CTA"
            )

        # Test with missing call_to_action
        with self.assertRaises(ValueError):
            ProductInfo(
                name="Name",
                description="Description",
                target_audience="Audience",
                unique_selling_points=["USP1", "USP2"],
                call_to_action=None
            )

    def test_project_creation(self):
        """Test that a Project object can be created with valid data"""
        name = "Fitness Tracker Campaign"
        product_info = ProductInfo(
            name="Premium Fitness Tracker",
            description="Advanced fitness tracker with heart rate monitoring and sleep tracking",
            target_audience="Health-conscious adults aged 25-45",
            unique_selling_points=[
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            call_to_action="Shop Now"
        )
        tone = "professional"
        platform = "facebook"
        num_variations = 3

        project = Project(
            name=name,
            product_info=product_info,
            tone=tone,
            platform=platform,
            num_variations=num_variations
        )

        self.assertEqual(project.name, name)
        self.assertEqual(project.product_info, product_info)
        self.assertEqual(project.tone, tone)
        self.assertEqual(project.platform, platform)
        self.assertEqual(project.num_variations, num_variations)

    def test_project_validation(self):
        """Test that Project validates required fields"""
        product_info = ProductInfo(
            name="Premium Fitness Tracker",
            description="Advanced fitness tracker with heart rate monitoring and sleep tracking",
            target_audience="Health-conscious adults aged 25-45",
            unique_selling_points=[
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            call_to_action="Shop Now"
        )

        # Test with missing name
        with self.assertRaises(ValueError):
            Project(
                name=None,
                product_info=product_info,
                tone="professional",
                platform="facebook",
                num_variations=3
            )

        # Test with missing product_info
        with self.assertRaises(ValueError):
            Project(
                name="Name",
                product_info=None,
                tone="professional",
                platform="facebook",
                num_variations=3
            )

        # Test with invalid tone
        with self.assertRaises(ValueError):
            Project(
                name="Name",
                product_info=product_info,
                tone="invalid_tone",
                platform="facebook",
                num_variations=3
            )

        # Test with invalid platform
        with self.assertRaises(ValueError):
            Project(
                name="Name",
                product_info=product_info,
                tone="professional",
                platform="invalid_platform",
                num_variations=3
            )

        # Test with invalid num_variations
        with self.assertRaises(ValueError):
            Project(
                name="Name",
                product_info=product_info,
                tone="professional",
                platform="facebook",
                num_variations=0
            )

        with self.assertRaises(ValueError):
            Project(
                name="Name",
                product_info=product_info,
                tone="professional",
                platform="facebook",
                num_variations=11
            )

    def test_project_to_dict(self):
        """Test that Project can be converted to a dictionary"""
        product_info = ProductInfo(
            name="Premium Fitness Tracker",
            description="Advanced fitness tracker with heart rate monitoring and sleep tracking",
            target_audience="Health-conscious adults aged 25-45",
            unique_selling_points=[
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            call_to_action="Shop Now"
        )

        project = Project(
            name="Fitness Tracker Campaign",
            product_info=product_info,
            tone="professional",
            platform="facebook",
            num_variations=3
        )

        project_dict = project.to_dict()
        self.assertEqual(project_dict["name"], "Fitness Tracker Campaign")
        self.assertEqual(project_dict["tone"], "professional")
        self.assertEqual(project_dict["platform"], "facebook")
        self.assertEqual(project_dict["num_variations"], 3)
        self.assertEqual(project_dict["product_info"]["name"], "Premium Fitness Tracker")
        self.assertEqual(project_dict["product_info"]["description"], "Advanced fitness tracker with heart rate monitoring and sleep tracking")
        self.assertEqual(project_dict["product_info"]["target_audience"], "Health-conscious adults aged 25-45")
        self.assertEqual(project_dict["product_info"]["unique_selling_points"], [
            "24/7 heart rate monitoring",
            "Water resistant up to 50m",
            "7-day battery life"
        ])
        self.assertEqual(project_dict["product_info"]["call_to_action"], "Shop Now")

if __name__ == '__main__':
    unittest.main()

