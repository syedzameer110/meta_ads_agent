"""
Tests for web routes
"""

import unittest
from unittest.mock import patch, MagicMock
from app import app
from app.services.openai_service import OpenAIService
from app.services.meta_ads_service import MetaAdsService
from app.services.integration_service import IntegrationService
from tests.mocks.mock_openai_service import MockOpenAIService
from tests.mocks.mock_meta_ads_service import MockMetaAdsService
from tests.mocks.mock_integration_service import MockIntegrationService

class TestRoutes(unittest.TestCase):
    """Test cases for web routes"""

    def setUp(self):
        """Set up test fixtures"""
        self.app = app.test_client()
        self.app.testing = True

    def test_index(self):
        """Test that the index page loads"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Meta Ads AI Agent', response.data)

    def test_ad_content(self):
        """Test that the ad content page loads"""
        response = self.app.get('/ad-content')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Ad Content Generation', response.data)

    def test_meta_ads(self):
        """Test that the Meta ads page loads"""
        response = self.app.get('/meta-ads')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Meta Ads Creation', response.data)

    def test_integrations(self):
        """Test that the integrations page loads"""
        response = self.app.get('/integrations')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Integrations', response.data)

    def test_settings(self):
        """Test that the settings page loads"""
        response = self.app.get('/settings')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Settings', response.data)

    @patch('app.routes.OpenAIService')
    def test_generate_ad_content_form(self, mock_openai_service):
        """Test that the ad content form works"""
        # Set up mock
        mock_instance = MockOpenAIService()
        mock_openai_service.return_value = mock_instance

        # Make request
        response = self.app.post('/ad-content',
                                data={
                                    'product_name': 'Premium Fitness Tracker',
                                    'product_description': 'Advanced fitness tracker with heart rate monitoring and sleep tracking',
                                    'target_audience': 'Health-conscious adults aged 25-45',
                                    'unique_selling_points': '24/7 heart rate monitoring, Water resistant up to 50m, 7-day battery life',
                                    'call_to_action': 'Shop Now',
                                    'tone': 'professional',
                                    'platform': 'facebook',
                                    'num_variations': '3'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Ad Content Results', response.data)
        self.assertIn(b'Introducing the New Premium Fitness Tracker', response.data)

    @patch('app.routes.MetaAdsService')
    def test_create_ad_form(self, mock_meta_ads_service):
        """Test that the create ad form works"""
        # Set up mock
        mock_instance = MockMetaAdsService()
        mock_meta_ads_service.return_value = mock_instance

        # Make request
        response = self.app.post('/meta-ads',
                                data={
                                    'campaign_name': 'Test Campaign',
                                    'campaign_objective': 'CONVERSIONS',
                                    'campaign_status': 'ACTIVE',
                                    'daily_budget': '50.00',
                                    'adset_name': 'Test Ad Set',
                                    'age_min': '25',
                                    'age_max': '45',
                                    'genders': '1,2',
                                    'countries': 'US',
                                    'optimization_goal': 'CONVERSIONS',
                                    'ad_name': 'Test Ad',
                                    'headline': 'Test Headline',
                                    'primary_text': 'Test Primary Text',
                                    'description': 'Test Description',
                                    'website_url': 'https://www.example.com',
                                    'call_to_action_type': 'SHOP_NOW'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Ad Created Successfully', response.data)
        self.assertIn(b'Test Campaign', response.data)
        self.assertIn(b'Test Ad Set', response.data)
        self.assertIn(b'Test Ad', response.data)

    @patch('app.routes.IntegrationService')
    def test_google_sheets_integration_form(self, mock_integration_service):
        """Test that the Google Sheets integration form works"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request
        response = self.app.post('/integrations/google-sheets',
                                data={
                                    'sheet_id': 'test_sheet_id',
                                    'sheet_range': 'Sheet1!A1:Z100',
                                    'action': 'read'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Google Sheets Integration Results', response.data)
        self.assertIn(b'Summer Sale', response.data)
        self.assertIn(b'Winter Collection', response.data)

    @patch('app.routes.IntegrationService')
    def test_airtable_integration_form(self, mock_integration_service):
        """Test that the Airtable integration form works"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request
        response = self.app.post('/integrations/airtable',
                                data={
                                    'base_id': 'test_base_id',
                                    'table_name': 'Ads',
                                    'api_key': 'test_api_key',
                                    'action': 'read'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Airtable Integration Results', response.data)
        self.assertIn(b'Summer Sale', response.data)
        self.assertIn(b'Winter Collection', response.data)

    @patch('app.routes.IntegrationService')
    def test_n8n_integration_form(self, mock_integration_service):
        """Test that the n8n integration form works"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request
        response = self.app.post('/integrations/n8n',
                                data={
                                    'webhook_url': 'https://n8n.example.com/webhook/test',
                                    'event_type': 'ad_created',
                                    'payload': '{"ad_id": "23123456789012345"}'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'n8n Integration Results', response.data)
        self.assertIn(b'Webhook triggered successfully', response.data)

    @patch('app.routes.IntegrationService')
    def test_csv_import_form(self, mock_integration_service):
        """Test that the CSV import form works"""
        # Set up mock
        mock_instance = MockIntegrationService()
        mock_integration_service.return_value = mock_instance

        # Make request with CSV data as string (for testing)
        csv_data = 'campaign_name,adset_name,ad_name\nSummer Sale,US - Mobile,Summer Sale - Image 1\nWinter Collection,EU - Desktop,Winter Collection - Video 1'
        response = self.app.post('/integrations/csv/import',
                                data={
                                    'file': (csv_data, 'test.csv'),
                                    'import_type': 'ads'
                                },
                                content_type='multipart/form-data',
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'CSV Import Results', response.data)
        self.assertIn(b'Successfully imported 2 rows', response.data)

    def test_settings_form(self):
        """Test that the settings form works"""
        # Make request
        response = self.app.post('/settings',
                                data={
                                    'openai_api_key': 'test_openai_api_key',
                                    'meta_access_token': 'test_meta_access_token',
                                    'meta_ad_account_id': 'act_123456789',
                                    'google_sheets_credentials': '{"type": "service_account"}',
                                    'airtable_api_key': 'test_airtable_api_key'
                                },
                                follow_redirects=True)
        
        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Settings Updated Successfully', response.data)

    def test_static_files(self):
        """Test that static files are served correctly"""
        # Test CSS
        response = self.app.get('/static/css/style.css')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'text/css; charset=utf-8')

        # Test JavaScript
        response = self.app.get('/static/js/main.js')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'application/javascript')

        # Test image
        response = self.app.get('/static/img/logo.png')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'image/png')

    def test_error_handling(self):
        """Test that errors are handled properly"""
        # Test 404 error
        response = self.app.get('/nonexistent-page')
        self.assertEqual(response.status_code, 404)
        self.assertIn(b'Page Not Found', response.data)

if __name__ == '__main__':
    unittest.main()

