"""
Tests for OpenAI service
"""

import unittest
from unittest.mock import patch, MagicMock
from app.services.openai_service import OpenAIService
from app.models.project import ProductInfo

class TestOpenAIService(unittest.TestCase):
    """Test cases for OpenAI service"""

    def setUp(self):
        """Set up test fixtures"""
        self.api_key = "test_api_key"
        self.product_info = ProductInfo(
            name="Premium Fitness Tracker",
            description="Advanced fitness tracker with heart rate monitoring and sleep tracking",
            target_audience="Health-conscious adults aged 25-45",
            unique_selling_points=[
                "24/7 heart rate monitoring",
                "Water resistant up to 50m",
                "7-day battery life"
            ],
            call_to_action="Shop Now"
        )

    @patch('app.services.openai_service.openai')
    def test_generate_headlines(self, mock_openai):
        """Test that headlines can be generated"""
        # Set up mock response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = """
        1. "Track Your Health 24/7 with Premium Fitness Tracker"
        2. "Upgrade Your Fitness Journey with Premium Tracker"
        3. "Water-Resistant Fitness Tracker with 7-Day Battery"
        """
        mock_openai.ChatCompletion.create.return_value = mock_completion

        # Create service and generate headlines
        service = OpenAIService(api_key=self.api_key)
        headlines = service.generate_headlines(self.product_info.to_dict())

        # Verify that the OpenAI API was called with the correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        args, kwargs = mock_openai.ChatCompletion.create.call_args
        self.assertEqual(kwargs['model'], 'gpt-4')
        self.assertEqual(len(kwargs['messages']), 2)
        self.assertEqual(kwargs['messages'][0]['role'], 'system')
        self.assertEqual(kwargs['messages'][1]['role'], 'user')
        self.assertIn('Premium Fitness Tracker', kwargs['messages'][1]['content'])

        # Verify that headlines were parsed correctly
        self.assertEqual(len(headlines), 3)
        self.assertEqual(headlines[0], "Track Your Health 24/7 with Premium Fitness Tracker")
        self.assertEqual(headlines[1], "Upgrade Your Fitness Journey with Premium Tracker")
        self.assertEqual(headlines[2], "Water-Resistant Fitness Tracker with 7-Day Battery")

    @patch('app.services.openai_service.openai')
    def test_generate_primary_text(self, mock_openai):
        """Test that primary text can be generated"""
        # Set up mock response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = """
        1. "Our advanced fitness tracker monitors your heart rate 24/7, is water resistant up to 50m, and has a 7-day battery life. Perfect for health-conscious adults who want to track their fitness journey. Shop Now!"
        2. "Take control of your health with our Premium Fitness Tracker. With 24/7 heart rate monitoring, water resistance, and a week-long battery, you'll never miss a beat. Shop Now and start your fitness journey today."
        3. "Designed for health-conscious adults, our Premium Fitness Tracker offers continuous heart rate monitoring, water resistance for swimming, and a battery that lasts all week. Shop Now and elevate your fitness routine."
        """
        mock_openai.ChatCompletion.create.return_value = mock_completion

        # Create service and generate primary text
        service = OpenAIService(api_key=self.api_key)
        primary_texts = service.generate_primary_text(self.product_info.to_dict())

        # Verify that the OpenAI API was called with the correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        args, kwargs = mock_openai.ChatCompletion.create.call_args
        self.assertEqual(kwargs['model'], 'gpt-4')
        self.assertEqual(len(kwargs['messages']), 2)
        self.assertEqual(kwargs['messages'][0]['role'], 'system')
        self.assertEqual(kwargs['messages'][1]['role'], 'user')
        self.assertIn('Premium Fitness Tracker', kwargs['messages'][1]['content'])

        # Verify that primary texts were parsed correctly
        self.assertEqual(len(primary_texts), 3)
        self.assertIn("advanced fitness tracker", primary_texts[0])
        self.assertIn("Take control of your health", primary_texts[1])
        self.assertIn("Designed for health-conscious adults", primary_texts[2])

    @patch('app.services.openai_service.openai')
    def test_generate_descriptions(self, mock_openai):
        """Test that descriptions can be generated"""
        # Set up mock response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = """
        1. "24/7 Heart Rate Monitoring"
        2. "Water Resistant Fitness Tracker"
        3. "7-Day Battery Life"
        """
        mock_openai.ChatCompletion.create.return_value = mock_completion

        # Create service and generate descriptions
        service = OpenAIService(api_key=self.api_key)
        descriptions = service.generate_descriptions(self.product_info.to_dict())

        # Verify that the OpenAI API was called with the correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        args, kwargs = mock_openai.ChatCompletion.create.call_args
        self.assertEqual(kwargs['model'], 'gpt-4')
        self.assertEqual(len(kwargs['messages']), 2)
        self.assertEqual(kwargs['messages'][0]['role'], 'system')
        self.assertEqual(kwargs['messages'][1]['role'], 'user')
        self.assertIn('Premium Fitness Tracker', kwargs['messages'][1]['content'])

        # Verify that descriptions were parsed correctly
        self.assertEqual(len(descriptions), 3)
        self.assertEqual(descriptions[0], "24/7 Heart Rate Monitoring")
        self.assertEqual(descriptions[1], "Water Resistant Fitness Tracker")
        self.assertEqual(descriptions[2], "7-Day Battery Life")

    @patch('app.services.openai_service.openai')
    def test_generate_with_tone(self, mock_openai):
        """Test that content can be generated with different tones"""
        # Set up mock response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = """
        1. "Get Fit with Premium Tracker - Fun & Easy!"
        2. "Your Fitness Journey Just Got More Fun!"
        3. "Splash, Track, Repeat - Fitness Made Fun!"
        """
        mock_openai.ChatCompletion.create.return_value = mock_completion

        # Create service and generate headlines with friendly tone
        service = OpenAIService(api_key=self.api_key)
        headlines = service.generate_headlines(self.product_info.to_dict(), tone="friendly")

        # Verify that the OpenAI API was called with the correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        args, kwargs = mock_openai.ChatCompletion.create.call_args
        self.assertEqual(kwargs['model'], 'gpt-4')
        self.assertIn('friendly', kwargs['messages'][1]['content'])

        # Verify that headlines were parsed correctly
        self.assertEqual(len(headlines), 3)
        self.assertIn("Fun", headlines[0])
        self.assertIn("Fun", headlines[1])
        self.assertIn("Fun", headlines[2])

    @patch('app.services.openai_service.openai')
    def test_generate_with_platform(self, mock_openai):
        """Test that content can be generated for different platforms"""
        # Set up mock response
        mock_completion = MagicMock()
        mock_completion.choices[0].message.content = """
        1. "Swipe Up to Shop Premium Fitness Trackers"
        2. "Double Tap if You Love Fitness #PremiumTracker"
        3. "Story-Worthy Fitness Tracker - 24/7 Monitoring"
        """
        mock_openai.ChatCompletion.create.return_value = mock_completion

        # Create service and generate headlines for Instagram
        service = OpenAIService(api_key=self.api_key)
        headlines = service.generate_headlines(self.product_info.to_dict(), platform="instagram")

        # Verify that the OpenAI API was called with the correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        args, kwargs = mock_openai.ChatCompletion.create.call_args
        self.assertEqual(kwargs['model'], 'gpt-4')
        self.assertIn('Instagram', kwargs['messages'][1]['content'])

        # Verify that headlines were parsed correctly
        self.assertEqual(len(headlines), 3)
        self.assertIn("Swipe Up", headlines[0])
        self.assertIn("Double Tap", headlines[1])
        self.assertIn("Story-Worthy", headlines[2])

    @patch('app.services.openai_service.openai')
    def test_error_handling(self, mock_openai):
        """Test that errors are handled properly"""
        # Set up mock to raise an exception
        mock_openai.ChatCompletion.create.side_effect = Exception("API Error")

        # Create service and try to generate headlines
        service = OpenAIService(api_key=self.api_key)
        
        # Verify that the error is caught and an empty list is returned
        headlines = service.generate_headlines(self.product_info.to_dict())
        self.assertEqual(headlines, [])

if __name__ == '__main__':
    unittest.main()

