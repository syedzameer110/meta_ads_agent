# Meta Ads AI Agent - Test Cases

## Unit Tests

### Ad Content Models

1. **Test Ad Headline Creation**
   - **Description**: Verify that an AdHeadline object can be created with valid data
   - **Steps**:
     1. Create an AdHeadline object with a valid headline
     2. Verify that the object is created successfully
   - **Expected Result**: Object is created with the correct headline text

2. **Test Ad Headline Character Limit**
   - **Description**: Verify that AdHeadline enforces the character limit
   - **Steps**:
     1. Create an AdHeadline object with a headline exceeding the character limit
     2. Verify that the headline is truncated or an error is raised
   - **Expected Result**: Headline is truncated to the maximum allowed length or an error is raised

3. **Test Ad Primary Text Creation**
   - **Description**: Verify that an AdPrimaryText object can be created with valid data
   - **Steps**:
     1. Create an AdPrimaryText object with valid text
     2. Verify that the object is created successfully
   - **Expected Result**: Object is created with the correct primary text

4. **Test Ad Primary Text Character Limit**
   - **Description**: Verify that AdPrimaryText enforces the character limit
   - **Steps**:
     1. Create an AdPrimaryText object with text exceeding the character limit
     2. Verify that the text is truncated or an error is raised
   - **Expected Result**: Primary text is truncated to the maximum allowed length or an error is raised

5. **Test Ad Description Creation**
   - **Description**: Verify that an AdDescription object can be created with valid data
   - **Steps**:
     1. Create an AdDescription object with valid description
     2. Verify that the object is created successfully
   - **Expected Result**: Object is created with the correct description text

6. **Test Ad Description Character Limit**
   - **Description**: Verify that AdDescription enforces the character limit
   - **Steps**:
     1. Create an AdDescription object with a description exceeding the character limit
     2. Verify that the description is truncated or an error is raised
   - **Expected Result**: Description is truncated to the maximum allowed length or an error is raised

### Project Models

7. **Test Project Creation**
   - **Description**: Verify that a Project object can be created with valid data
   - **Steps**:
     1. Create a Project object with valid data
     2. Verify that the object is created successfully
   - **Expected Result**: Object is created with the correct project data

8. **Test Project Validation**
   - **Description**: Verify that Project validates required fields
   - **Steps**:
     1. Create a Project object with missing required fields
     2. Verify that an error is raised
   - **Expected Result**: Error is raised for missing required fields

### OpenAI Service

9. **Test OpenAI Service Initialization**
   - **Description**: Verify that the OpenAIService can be initialized with valid API key
   - **Steps**:
     1. Initialize OpenAIService with a valid API key
     2. Verify that the service is initialized successfully
   - **Expected Result**: Service is initialized without errors

10. **Test Generate Ad Headlines**
    - **Description**: Verify that the OpenAIService can generate ad headlines
    - **Steps**:
      1. Call the generate_headlines method with valid product information
      2. Verify that headlines are generated
    - **Expected Result**: A list of valid headlines is returned

11. **Test Generate Primary Text**
    - **Description**: Verify that the OpenAIService can generate primary text
    - **Steps**:
      1. Call the generate_primary_text method with valid product information
      2. Verify that primary text is generated
    - **Expected Result**: A list of valid primary text variations is returned

12. **Test Error Handling for Invalid API Key**
    - **Description**: Verify that the OpenAIService handles invalid API key errors
    - **Steps**:
      1. Initialize OpenAIService with an invalid API key
      2. Call a generation method
      3. Verify that an appropriate error is raised
    - **Expected Result**: Error is raised with a clear message about the invalid API key

### Meta Ads Service

13. **Test Meta Ads Service Initialization**
    - **Description**: Verify that the MetaAdsService can be initialized with valid access token
    - **Steps**:
      1. Initialize MetaAdsService with a valid access token
      2. Verify that the service is initialized successfully
    - **Expected Result**: Service is initialized without errors

14. **Test Create Campaign**
    - **Description**: Verify that the MetaAdsService can create a campaign
    - **Steps**:
      1. Call the create_campaign method with valid campaign data
      2. Verify that a campaign is created
    - **Expected Result**: A campaign object with a valid ID is returned

15. **Test Create Ad Set**
    - **Description**: Verify that the MetaAdsService can create an ad set
    - **Steps**:
      1. Call the create_adset method with valid ad set data
      2. Verify that an ad set is created
    - **Expected Result**: An ad set object with a valid ID is returned

16. **Test Create Ad**
    - **Description**: Verify that the MetaAdsService can create an ad
    - **Steps**:
      1. Call the create_ad method with valid ad data
      2. Verify that an ad is created
    - **Expected Result**: An ad object with a valid ID is returned

17. **Test Error Handling for Invalid Access Token**
    - **Description**: Verify that the MetaAdsService handles invalid access token errors
    - **Steps**:
      1. Initialize MetaAdsService with an invalid access token
      2. Call a creation method
      3. Verify that an appropriate error is raised
    - **Expected Result**: Error is raised with a clear message about the invalid access token

### Integration Service

18. **Test Google Sheets Integration**
    - **Description**: Verify that the IntegrationService can connect to Google Sheets
    - **Steps**:
      1. Call the connect_google_sheets method with valid credentials
      2. Verify that a connection is established
    - **Expected Result**: Connection is established without errors

19. **Test Airtable Integration**
    - **Description**: Verify that the IntegrationService can connect to Airtable
    - **Steps**:
      1. Call the connect_airtable method with valid credentials
      2. Verify that a connection is established
    - **Expected Result**: Connection is established without errors

20. **Test n8n Integration**
    - **Description**: Verify that the IntegrationService can trigger n8n webhooks
    - **Steps**:
      1. Call the trigger_n8n_webhook method with a valid webhook URL
      2. Verify that the webhook is triggered
    - **Expected Result**: Webhook is triggered without errors

## Integration Tests

### Ad Content Generation

21. **Test End-to-End Ad Content Generation**
    - **Description**: Verify that the ad content generation workflow works end-to-end
    - **Steps**:
      1. Submit a request to the ad content generation endpoint
      2. Verify that the OpenAI service is called
      3. Verify that valid ad content is returned
    - **Expected Result**: Valid ad content is returned in the response

22. **Test Ad Content Generation with Different Tones**
    - **Description**: Verify that ad content can be generated with different tones
    - **Steps**:
      1. Submit requests with different tone settings
      2. Verify that the generated content reflects the specified tone
    - **Expected Result**: Content tone varies according to the specified setting

23. **Test Ad Content Generation with Different Platforms**
    - **Description**: Verify that ad content can be generated for different platforms
    - **Steps**:
      1. Submit requests with different platform settings
      2. Verify that the generated content is appropriate for the specified platform
    - **Expected Result**: Content is tailored to the specified platform

### Meta Ads Creation

24. **Test End-to-End Ad Creation**
    - **Description**: Verify that the ad creation workflow works end-to-end
    - **Steps**:
      1. Submit a request to create an ad
      2. Verify that the Meta Ads service is called
      3. Verify that a valid ad is created
    - **Expected Result**: Valid ad is created and returned in the response

25. **Test Bulk Ad Creation**
    - **Description**: Verify that multiple ads can be created in bulk
    - **Steps**:
      1. Submit a request to create multiple ads
      2. Verify that the Meta Ads service is called for each ad
      3. Verify that valid ads are created
    - **Expected Result**: Multiple valid ads are created and returned in the response

26. **Test Ad Creation with Generated Content**
    - **Description**: Verify that ads can be created with AI-generated content
    - **Steps**:
      1. Generate ad content
      2. Use the generated content to create an ad
      3. Verify that the ad is created successfully
    - **Expected Result**: Ad is created with the AI-generated content

### External Integrations

27. **Test Google Sheets Data Import**
    - **Description**: Verify that data can be imported from Google Sheets
    - **Steps**:
      1. Submit a request to import data from Google Sheets
      2. Verify that the data is imported correctly
    - **Expected Result**: Data is imported and available in the application

28. **Test Google Sheets Data Export**
    - **Description**: Verify that data can be exported to Google Sheets
    - **Steps**:
      1. Submit a request to export data to Google Sheets
      2. Verify that the data is exported correctly
    - **Expected Result**: Data is exported to Google Sheets

29. **Test Airtable Data Sync**
    - **Description**: Verify that data can be synchronized with Airtable
    - **Steps**:
      1. Submit a request to sync data with Airtable
      2. Verify that the data is synchronized correctly
    - **Expected Result**: Data is synchronized between the application and Airtable

30. **Test n8n Webhook Trigger**
    - **Description**: Verify that n8n webhooks can be triggered
    - **Steps**:
      1. Submit a request to trigger an n8n webhook
      2. Verify that the webhook is triggered correctly
    - **Expected Result**: Webhook is triggered and n8n workflow is executed

## End-to-End Tests

31. **Test Complete Ad Creation Workflow**
    - **Description**: Verify the complete workflow from content generation to ad creation
    - **Steps**:
      1. Generate ad content
      2. Create an ad with the generated content
      3. Verify that the ad is created successfully
    - **Expected Result**: Ad is created with the AI-generated content

32. **Test Complete Bulk Ad Creation Workflow**
    - **Description**: Verify the complete workflow for bulk ad creation
    - **Steps**:
      1. Import data from a CSV file
      2. Create multiple ads from the imported data
      3. Verify that the ads are created successfully
    - **Expected Result**: Multiple ads are created from the imported data

33. **Test Complete Integration Workflow**
    - **Description**: Verify the complete workflow with external integrations
    - **Steps**:
      1. Import data from Google Sheets
      2. Generate ad content based on the imported data
      3. Create ads with the generated content
      4. Export the results to Airtable
      5. Trigger an n8n webhook to notify about the completed process
    - **Expected Result**: Complete workflow executes successfully

## UI Tests

34. **Test Ad Content Generation Form**
    - **Description**: Verify that the ad content generation form works correctly
    - **Steps**:
      1. Fill out the ad content generation form
      2. Submit the form
      3. Verify that the form submission is processed correctly
    - **Expected Result**: Form is submitted and ad content is generated

35. **Test Meta Ads Creation Form**
    - **Description**: Verify that the Meta ads creation form works correctly
    - **Steps**:
      1. Fill out the Meta ads creation form
      2. Submit the form
      3. Verify that the form submission is processed correctly
    - **Expected Result**: Form is submitted and ad is created

36. **Test Integrations Forms**
    - **Description**: Verify that the integrations forms work correctly
    - **Steps**:
      1. Fill out an integration form (e.g., Google Sheets connection)
      2. Submit the form
      3. Verify that the form submission is processed correctly
    - **Expected Result**: Form is submitted and integration is established

37. **Test Settings Forms**
    - **Description**: Verify that the settings forms work correctly
    - **Steps**:
      1. Fill out a settings form (e.g., API keys)
      2. Submit the form
      3. Verify that the form submission is processed correctly
    - **Expected Result**: Form is submitted and settings are updated

38. **Test Responsive Design**
    - **Description**: Verify that the UI is responsive and works on different screen sizes
    - **Steps**:
      1. Access the application on different devices or with different viewport sizes
      2. Verify that the UI adapts correctly
    - **Expected Result**: UI is usable and looks good on all tested screen sizes

## Performance Tests

39. **Test Ad Content Generation Performance**
    - **Description**: Verify that ad content generation performs within acceptable limits
    - **Steps**:
      1. Generate ad content multiple times
      2. Measure the response time
    - **Expected Result**: Response time is within acceptable limits

40. **Test Bulk Ad Creation Performance**
    - **Description**: Verify that bulk ad creation performs within acceptable limits
    - **Steps**:
      1. Create a large number of ads in bulk
      2. Measure the response time
    - **Expected Result**: Response time is within acceptable limits

## Security Tests

41. **Test API Authentication**
    - **Description**: Verify that API endpoints require authentication
    - **Steps**:
      1. Access API endpoints without authentication
      2. Verify that access is denied
    - **Expected Result**: Access is denied with an appropriate error message

42. **Test Input Validation**
    - **Description**: Verify that input validation prevents malicious input
    - **Steps**:
      1. Submit requests with malicious input
      2. Verify that the input is rejected
    - **Expected Result**: Input is rejected with an appropriate error message

## Accessibility Tests

43. **Test Keyboard Navigation**
    - **Description**: Verify that the application can be navigated using only the keyboard
    - **Steps**:
      1. Navigate through the application using only the keyboard
      2. Verify that all interactive elements can be accessed
    - **Expected Result**: All interactive elements can be accessed using the keyboard

44. **Test Screen Reader Compatibility**
    - **Description**: Verify that the application is compatible with screen readers
    - **Steps**:
      1. Access the application with a screen reader
      2. Verify that all content is accessible
    - **Expected Result**: All content is accessible to screen readers

