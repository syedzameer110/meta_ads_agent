"""
Tests for data models
"""

import unittest
from app.models.ad_content import AdHeadline, AdPrimaryText, AdDescription, AdContent


class TestAdContentModels(unittest.TestCase):
    """Test ad content models"""
    
    def test_ad_headline(self):
        """Test AdHeadline model"""
        headline = AdHeadline(text="Test Headline for Meta Ads")
        self.assertEqual(headline.text, "Test Headline for Meta Ads")
        self.assertEqual(headline.character_count, 26)
        self.assertTrue(headline.is_valid())
        
        long_headline = AdHeadline(text="This is a very long headline that exceeds the character limit for Meta ads and should be considered invalid")
        self.assertEqual(long_headline.character_count, 107)
        self.assertFalse(long_headline.is_valid())
    
    def test_ad_primary_text(self):
        """Test AdPrimaryText model"""
        primary_text = AdPrimaryText(text="This is a test primary text for Meta ads.")
        self.assertEqual(primary_text.text, "This is a test primary text for Meta ads.")
        self.assertEqual(primary_text.character_count, 41)
        self.assertTrue(primary_text.is_valid())
    
    def test_ad_description(self):
        """Test AdDescription model"""
        description = AdDescription(text="Short description")
        self.assertEqual(description.text, "Short description")
        self.assertEqual(description.character_count, 17)
        self.assertTrue(description.is_valid())
        
        long_description = AdDescription(text="This description is too long for Meta ads and should be invalid")
        self.assertEqual(long_description.character_count, 63)
        self.assertFalse(long_description.is_valid())
    
    def test_ad_content(self):
        """Test AdContent model"""
        headline = AdHeadline(text="Test Headline")
        primary_text = AdPrimaryText(text="Test primary text")
        description = AdDescription(text="Test description")
        
        ad_content = AdContent(
            headline=headline,
            primary_text=primary_text,
            description=description,
            call_to_action="Shop Now",
            url="https://example.com"
        )
        
        self.assertEqual(ad_content.headline, headline)
        self.assertEqual(ad_content.primary_text, primary_text)
        self.assertEqual(ad_content.description, description)
        self.assertEqual(ad_content.call_to_action, "Shop Now")
        self.assertEqual(ad_content.url, "https://example.com")
        
        # Test to_dict method
        ad_dict = ad_content.to_dict()
        self.assertEqual(ad_dict["headline"], "Test Headline")
        self.assertEqual(ad_dict["primary_text"], "Test primary text")
        self.assertEqual(ad_dict["description"], "Test description")
        self.assertEqual(ad_dict["call_to_action"], "Shop Now")
        self.assertEqual(ad_dict["url"], "https://example.com")
        
        # Test from_dict method
        new_ad_content = AdContent.from_dict(ad_dict)
        self.assertEqual(new_ad_content.headline.text, "Test Headline")
        self.assertEqual(new_ad_content.primary_text.text, "Test primary text")
        self.assertEqual(new_ad_content.description.text, "Test description")
        self.assertEqual(new_ad_content.call_to_action, "Shop Now")
        self.assertEqual(new_ad_content.url, "https://example.com")


if __name__ == "__main__":
    unittest.main()

