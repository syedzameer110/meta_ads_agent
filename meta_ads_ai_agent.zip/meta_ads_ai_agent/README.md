# Meta Ads AI Agent

An AI-powered agent for creating and managing Meta (Facebook/Instagram) ads at scale. This tool helps generate compelling ad headlines, primary text variations, and facilitates bulk ad creation through the Meta Ads Marketing API.

## Features

- **AI-Powered Content Generation**: Create compelling ad headlines and primary text variations tailored to your product and audience
- **Meta Ads API Integration**: Seamlessly create and manage ads through the Meta Ads Marketing API
- **Bulk Ad Creation**: Generate and publish multiple ad variations at once
- **Integration Options**: Connect with n8n, Airtable, or Google Sheets for workflow automation
- **Performance Tracking**: Monitor ad performance and get insights

## System Requirements

- Python 3.11+
- Virtual environment (recommended)
- Meta Business Account with API access
- OpenAI API key (for content generation)

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/meta-ads-ai-agent.git
   cd meta-ads-ai-agent
   ```

2. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Create a `.env` file based on `.env.example`:
   ```
   cp .env.example .env
   ```

5. Edit the `.env` file with your API keys and configuration.

## Configuration

The application uses environment variables for configuration. The main settings are:

- **Meta API**: Credentials for accessing the Meta Ads Marketing API
- **OpenAI API**: API key for content generation
- **Integration APIs**: Credentials for n8n, Airtable, or Google Sheets
- **Application Settings**: Host, port, debug mode, etc.

See `.env.example` for all available configuration options.

## Usage

1. Start the application:
   ```
   python app.py
   ```

2. Access the web interface at `http://localhost:5000`

3. Create a new project with your product information and target audience

4. Generate ad content variations

5. Review and select preferred variations

6. Create ads in bulk through the Meta Ads API

## Integration Options

### n8n

The application can integrate with n8n for workflow automation. Use the Facebook Graph API node in n8n to connect to the Meta Ads API.

### Airtable

Store and manage your ad content in Airtable. The application can read from and write to Airtable bases.

### Google Sheets

Use Google Sheets for collaborative ad content creation and management. The application can import/export data from Google Sheets.

## Development

### Project Structure

```
meta_ads_ai_agent/
├── app/                    # Application code
│   ├── api/                # API endpoints
│   ├── models/             # Data models
│   ├── services/           # Business logic
│   └── utils/              # Utility functions
├── config/                 # Configuration
│   ├── templates/          # Content templates
│   └── examples/           # Example configurations
├── data/                   # Data storage
│   ├── input/              # Input data
│   └── output/             # Output data
├── scripts/                # Utility scripts
├── tests/                  # Test suite
├── .env.example            # Example environment variables
├── app.py                  # Main application entry point
├── requirements.txt        # Python dependencies
└── README.md               # This file
```

### Running Tests

```
pytest
```

## License

[MIT License](LICENSE)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

