# Contributing to Meta Ads AI Agent

Thank you for considering contributing to the Meta Ads AI Agent! This document provides guidelines and instructions for contributing to this project.

## Code of Conduct

By participating in this project, you agree to abide by our [Code of Conduct](CODE_OF_CONDUCT.md). Please read it before contributing.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the issue list to avoid duplicates. When you create a bug report, include as many details as possible:

- Use a clear and descriptive title
- Describe the exact steps to reproduce the problem
- Describe the behavior you observed and what you expected to see
- Include screenshots if possible
- Include details about your environment (OS, Python version, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- Use a clear and descriptive title
- Provide a detailed description of the proposed enhancement
- Explain why this enhancement would be useful
- Include examples of how the feature would be used

### Pull Requests

- Fill in the required template
- Follow the Python style guide (PEP 8)
- Include tests for new features or bug fixes
- Update documentation as needed
- End all files with a newline

## Development Process

### Setting Up Development Environment

1. Fork the repository
2. Clone your fork:
   ```
   git clone https://github.com/your-username/meta-ads-ai-agent.git
   cd meta-ads-ai-agent
   ```
3. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
5. Create a `.env` file based on `.env.example`

### Testing

Run tests with pytest:
```
pytest
```

### Coding Style

Follow PEP 8 for Python code. Use meaningful variable names and include docstrings for functions and classes.

## Git Workflow

1. Create a branch for your work:
   ```
   git checkout -b feature/your-feature-name
   ```
2. Make your changes
3. Run tests to ensure they pass
4. Commit your changes with a descriptive message
5. Push to your fork
6. Create a pull request

## Documentation

Update documentation when necessary, including:
- README.md
- Docstrings
- Comments for complex code
- User guides in the docs directory

## Questions?

If you have any questions, feel free to create an issue with the "question" label or contact the maintainers directly.

Thank you for contributing to Meta Ads AI Agent!

